# Promo report (data)

Run `gemini-batch-v3` · model `gemini:gemini-3.5-flash (effort=low)` · prompts v2026-11-08.3 · 50 episodes

**48 promos passed** out of 109 candidates (61 rejected).

## Publishing plan

The strategy prioritizes high-score, high-clarity promos first (P001, P002) to capture immediate interest, while weaving in early-episode promos (P038, P035) to minimize context requirements for new arrivals. We stagger narrative themes—alternating between visceral physical action, high-society betrayal, and medical urgency—to prevent viewer fatigue. Late-story spoilers (P015, P017) are pushed toward the middle of the cycle to target users already showing high retention, while high-episode count promos are front-loaded to maximize LTV. The sequence concludes with niche genre tropes like psychological horror and slow-burn revenge to maintain a long-tail discovery phase.

## Ranked promos

### 1. P001 · 98/100 · 39.0s · High · review: recommended

- **Cut:** E13 00:47.00–01:26.00
- **Hook:** Alexander screams in panic as Juliana crawls into razor-sharp thorns.  
  `ALEXANDER: "Juliana, stop!"`
- **Cliffhanger:** Juliana screams in agony as thorns tear her flesh while her husband watches helplessly in chains.  
  `JULIANA: "Ahhh!"`
- **Why it works:** Visceral, high-stakes physical suffering combined with a clear 'save the hero' motivation.
- **Rank:** Highest overall score with near-perfect cliffhanger and hook metrics, providing an immediate emotional anchor for new users.
- Scores: hook 24/25 · clarity 19/20 · cliff 25/25 · emotion 15/15 · coherence 10/10 · duration 5/5
- Critic notes a new viewer may not understand: None; the stakes and actions are painfully clear.

<details><summary>Clip as the viewer sees it</summary>

```
--- CUT 1: episode 13 (source 00:47.00-01:26.00) ---
[00:00.00-00:03.00] CAMERA: Medium shot of Alexander lunging forward with chained hands raised high, roaring in fury as the Constable grabs him.
[00:00.20-00:01.80] ALEXANDER (Screaming, Panicked): "Juliana, stop!"
[00:00.80-00:02.20] SFX: Rattling of heavy iron chains.
[00:03.00-00:06.00] ACTION: Juliana crawls forward on all fours, lowering her head under the jagged, arching thorns.
[00:03.00-00:05.00] CAMERA: Eye-level shot looking through the thorny thicket at Juliana crawling deeper into the briars.
[00:04.50-00:05.60] ALEXANDER (Strangled, Weeping): "Please..."
[00:05.00-00:06.50] CAMERA: Extreme close-up of Alexander's anguished face as he strains furiously against his handcuffs.
[00:06.50-00:09.00] CAMERA: Ground-level shot of Juliana's bare hands reaching out onto the cracked, frozen ground.
[00:07.00-00:09.50] ACTION: Sharp blackthorn spines rake across Juliana's fingers and knuckles, carving bloody gashes across her skin.
[00:07.50-00:08.80] JULIANA (Gasping in Pain): "No..."
[00:09.00-00:11.20] CAMERA: Extreme close-up of Juliana's hand scraping against the frost-covered stone, bright red blood welling from deep puncture wounds.
[00:10.20-00:11.60] CLARISSA (O.S.) (Gleeful, Derisive): "Look at her hands."
[00:11.20-00:15.00] CAMERA: Medium shot on the balcony as Clarissa gleefully points down at Juliana, Gerald chuckling beside her.
[00:11.80-00:14.80] CLARISSA (Mocking, Spiteful): "The lady has finally found something worthy of her."
[00:15.00-00:17.00] ACTION: Gerald leans his hands on the terrace railing, sneering callously.
[00:15.00-00:20.50] CAMERA: Low-angle medium close-up of Gerald shouting down into the garden.
[00:15.20-00:20.00] GERALD (Taunting, Cruel): "Keep searching, Juliana. Your husband's freedom is somewhere in that garden."
[00:20.50-00:24.20] CAMERA: Macro close-up of a massive blackthorn needle stabbing deep into the back of Juliana's bleeding hand.
[00:21.50-00:23.20] SFX: Sickening crunch and scrape of thorns slicing through flesh.
[00:24.20-00:27.00] CAMERA: Close-up of Alexander struggling in agony, tears forming in his eyes.
[00:24.40-00:26.80] ALEXANDER (Desperate, Choked): "Please... enough!"
[00:27.00-00:31.00] CAMERA: Wide tunnel shot through the briars as Juliana crawls deeper into the dark, frozen tangle.
[00:27.50-00:31.00] ACTION: Juliana drags her body across the frozen, cracked soil beneath the dense roof of briars.
[00:31.00-00:33.50] CAMERA: Close-up of Juliana's hand getting snagged between two vicious thorns, tearing her sleeve and flesh.
[00:31.50-00:33.50] JULIANA (Screaming in Pain): "Ah!"
[00:33.50-00:36.00] ACTION: Alexander loses control, violently lunging past the Constable toward the briars.
[00:33.50-00:36.00] CAMERA: Medium tracking shot of Alexander breaking into a desperate charge.
[00:33.80-00:35.20] ALEXANDER (Furious, Booming): "Stop!"
[00:36.00-00:39.00] ACTION: Juliana continues clawing forward, branches lacerating her arm and cheek.
[00:36.00-00:39.00] CAMERA: Close-up of Juliana wincing in agony and screaming through clenched teeth.
[00:36.80-00:38.80] JULIANA (Agonized Scream): "Ahhh!"
```
</details>

### 2. P002 · 95/100 · 43.2s · High · review: needs_review

- **Cut:** E23 01:28.00–02:11.20
- **Hook:** The Duchess violently chokes as Juliana rushes to mix an emergency antidote.  
  `CAMERA: Medium shot as the Duchess chokes and spasms on the bed; Juliana whips around immediately.`
- **Cliffhanger:** The door handle rotates downward and cracks open while Juliana is trapped mid-cure.  
  `CAMERA: Close-up on the brass door lever as it slowly rotates downward, and the heavy door cracks open inward into the room—cutting to an intense, heart-stoppin`
- **Why it works:** Classic suspense scenario with a race against the clock and imminent capture.
- **Rank:** Combines a top-tier score with a clear race-against-the-clock hook that requires zero prior context.
- Scores: hook 24/25 · clarity 16/20 · cliff 25/25 · emotion 15/15 · coherence 10/10 · duration 5/5
- Critic notes a new viewer may not understand: None—the stakes are crystal clear.

<details><summary>Clip as the viewer sees it</summary>

```
--- CUT 1: episode 23 (source 01:28.00-02:11.20) ---
[00:00.00-00:03.00] CAMERA: Medium shot as the Duchess chokes and spasms on the bed; Juliana whips around immediately.
[00:03.00-00:06.50] CAMERA: Medium tracking shot of Juliana rushing to the side table by the window, opening her satchel and setting out glass vials, a bowl, and dried herbal bundles.
[00:06.50-00:09.50] CAMERA: Close-up of Prudence pleading desperately, tears flowing down her cheeks.
[00:06.50-00:09.00] PRUDENCE (Desperate, Begging): "Can you save her?"
[00:09.50-00:12.50] CAMERA: Medium shot of Juliana uncorking a glass apothecary bottle as the Duchess rests behind her.
[00:09.50-00:12.00] LADY JULIANA (Focused, Resolute): "I can try."
[00:12.50-00:16.50] CAMERA: Top-down close-up of Juliana's soot-smudged hands pouring powdered activated charcoal from a vial into a stone mortar, then tossing in a pinch of crushed dried leaves.
[00:16.50-00:19.00] CAMERA: Close-up of Juliana's hands vigorously grinding the pestle inside the stone mortar.
[00:16.50-00:24.00] SFX: Heavy, rhythmic scraping of stone pestle grinding charcoal and dried herbs.
[00:19.00-00:24.50] CAMERA: Medium close-up of Juliana grinding intensely, her brow furrowed as she speaks with urgent authority.
[00:19.50-00:24.00] LADY JULIANA (Urgent, Focused): "The charcoal may help remove what is still inside her. We must act quickly."
[00:24.20-00:26.00] SFX: Sudden muffled thump and heavy footsteps echoing from the hallway outside the door!
[00:24.50-00:27.00] CAMERA: Wide shot of the bedroom door framed through the bed curtains as the Duchess gasps in the bed.
[00:27.00-00:28.50] CAMERA: Medium shot of Juliana freezing mid-motion, turning her head sharply toward the chamber door.
[00:28.50-00:30.50] CAMERA: Close-up of the ornate brass door handle on the dark carved wooden door.
[00:30.50-00:36.50] CAMERA: Close-up of Prudence staring at the door in utter terror, her face drained of all color.
[00:30.80-00:36.00] PRUDENCE (Terrified, Hoarse Whisper): "Juliana... someone is coming."
[00:36.50-00:39.50] CAMERA: Quick cut to Juliana looking back toward the bed and then toward the door, trapped with an unfinished cure.
[00:39.50-00:41.50] CAMERA: Tight close-up of Juliana's charcoal-blackened hand clutching the glass medicine vial firmly.
[00:41.20-00:43.20] SFX: Loud, metallic clack of the door latch turning, followed by the slow creak of wood hinges.
[00:41.50-00:43.20] CAMERA: Close-up on the brass door lever as it slowly rotates downward, and the heavy door cracks open inward into the room—cutting to an intense, heart-stopping cliffhanger.
```
</details>

### 3. P003 · 95/100 · 41.4s · High · review: needs_review

- **Cut:** E41 00:00.00–00:28.40 → E41 01:20.50–01:33.50
- **Hook:** Catherine halts her wedding to demand everyone watch a chained woman brought in.  
  `CATHERINE: "Wait."`
- **Cliffhanger:** An explosive blast shatters the cathedral entrance and silhouetted figures emerge as Juliana realizes who arrived.  
  `CAMERA: Extreme close-up pushing in on Juliana's bruised face. Her expression shifts from grim resolve into awe, breathless realization, and blooming hope as th`
- **Why it works:** It combines high-society melodrama with sudden, violent action and a clear reversal of power.
- **Rank:** High episode count and high score justify its early placement to drive deep-session engagement through late-story power reversals.
- Scores: hook 22/25 · clarity 18/20 · cliff 25/25 · emotion 15/15 · coherence 10/10 · duration 5/5
- Critic notes a new viewer may not understand: The specific relationship between the bride and the prisoner.

<details><summary>Clip as the viewer sees it</summary>

```
--- CUT 1: episode 41 (source 00:00.00-00:28.40) ---
[00:00.00-00:01.80] CAMERA: Wide symmetrical shot looking down the candlelit, flower-strewn aisle toward the altar where Rupert, Catherine, and the Priest stand.
[00:01.80-00:04.50] ACTION: Catherine abruptly pulls away from Rupert and raises her white-gloved hand high, commanding silence from the congregation.
[00:01.80-00:02.80] CATHERINE (Imperious, Commanding): "Wait."
[00:04.50-00:08.50] CAMERA: Medium shot tracking Catherine as she pivots toward the seated aristocracy, her veil floating gracefully behind her.
[00:04.90-00:08.20] CATHERINE (Haughty, Loud): "Before I become Duchess of Ashburgh..."
[00:08.50-00:13.00] CAMERA: Close-up of Catherine's face, her lips curling into a sadistic, triumphant sneer.
[00:08.50-00:12.70] CATHERINE (Cruel, Resonant): "...I want everyone to see what happens to a woman who dares defy this family."
[00:13.00-00:15.50] CAMERA: Two-shot profile of Rupert and Catherine. Rupert turns to her with mild caution.
[00:13.20-00:14.00] BLOND NOBLEMAN (Subdued, Inquiring): "Catherine..."
[00:14.00-00:15.30] CATHERINE (Callous, Projecting): "Bring her in."
[00:15.50-00:17.50] SFX: Heavy wooden creak of the cathedral double doors swinging open.
[00:15.50-00:20.00] CAMERA: Wide shot from behind the altar down the aisle as the great church doors slowly open, revealing the silhouette of three figures against the daylight.
[00:17.50-00:20.00] ACTION: Juliana, dressed in a coarse drab prison dress with a numbered identification badge, is marched forward by two armed constables holding her by the arms.
[00:20.00-00:22.80] CAMERA: Extreme close-up of Juliana's scarred, dirtied wrists bound tight in heavy iron shackles.
[00:22.80-00:26.00] CAMERA: Intense close-up of Juliana's bruised, dirt-streaked face. Her piercing blue eyes burn with fierce dignity despite her captive state.
[00:26.00-00:28.40] CAMERA: Medium shot of Catherine standing beside the altar, watching Juliana's entrance with gloating satisfaction.
[00:26.80-00:28.40] CATHERINE (Smug, Taunting): "There she is."
--- CUT 2: episode 41 (source 01:20.50-01:33.50) ---
[00:28.40-00:29.70] CAMERA: Wide shot centered down the aisle toward the massive closed entrance doors.
[00:28.90-00:33.40] SFX: Ear-splitting detonation, shattering stone, wood splintering violently into kindling, followed by terrified screams of the congregation.
[00:29.70-00:31.90] ACTION: A violent fireball bursts inward as the entire cathedral entrance explodes, blasting the massive double doors and masonry into flying shrapnel and billowing smoke.
[00:29.70-00:32.40] CAMERA: Rapid series of panic shots: aristocratic guests ducking behind pews, covering their heads in terror, women shrieking as plaster rains down.
[00:32.40-00:36.40] CAMERA: Medium shot of Catherine and Rupert at the altar. Catherine gasps in horror, clutching her veil as debris rains over her bridal gown while Rupert spins around in shock.
[00:36.40-00:39.90] CAMERA: Medium wide shot of Juliana standing motionless in the middle of the aisle while thick smoke and dust billow from the demolished archway behind her.
[00:36.90-00:41.40] ACTION: Silhouetted armed figures emerge through the smoke and rubble of the breached doorway. Juliana slowly turns her head, glancing back toward the light.
[00:39.90-00:41.40] CAMERA: Extreme close-up pushing in on Juliana's bruised face. Her expression shifts from grim resolve into awe, breathless realization, and blooming hope as the orchestral score swells into an abrupt cliffhanger.
```
</details>

### 4. P004 · 91/100 · 34.9s · High · review: recommended

- **Cut:** E32 01:59.50–02:34.38
- **Hook:** Catherine snaps completely, screaming and raising a glowing branding poker like a weapon.  
  `CAMERA: Medium shot of Catherine snapping entirely, raising the branding poker like a weapon and screaming.`
- **Cliffhanger:** Catherine plunges the burning branding tip straight at Juliana's eye, holding millimeters away on an unblinking close-up.  
  `CAMERA: Extreme close-up of Juliana's wide, unblinking blue eye. The intense, fiery orange glow of the iron poker radiates inches from her cornea, holding on th`
- **Why it works:** The psychological warfare between the two women is as compelling as the physical threat.
- **Rank:** Strong psychological warfare offers variety against the physical action of higher-ranked promos.
- Scores: hook 19/25 · clarity 17/20 · cliff 25/25 · emotion 15/15 · coherence 10/10 · duration 5/5
- Critic notes a new viewer may not understand: What title Catherine 'always wanted'.

<details><summary>Clip as the viewer sees it</summary>

```
--- CUT 1: episode 32 (source 01:59.50-02:34.38) ---
[00:00.00-00:02.30] CAMERA: Medium shot of Catherine snapping entirely, raising the branding poker like a weapon and screaming.
[00:00.10-00:02.30] CATHERINE (Hysterical, Screaming): "Silence! Silence!"
[00:02.30-00:03.50] CAMERA: Close-up of Catherine's crazed, gasping face.
[00:02.30-00:03.30] CATHERINE (Shrieking): "Why?!"
[00:03.30-00:05.50] CAMERA: Close-up of Juliana crying out her defiance.
[00:03.50-00:05.70] JULIANA (Forceful): "Because I am right!"
[00:05.50-00:09.00] CAMERA: Low-angle tracking shot of the red-hot branding tip trailing across the wet dungeon floor, steaming.
[00:05.90-00:09.30] JULIANA (Scathing, Direct): "You want everyone to believe you are powerful."
[00:09.00-00:12.30] CAMERA: Medium shot of Juliana sitting under the cold skylight bars, her posture majestic despite her imprisonment.
[00:09.50-00:12.10] JULIANA (Continuing): "You want everyone to fear you."
[00:12.30-00:15.30] CAMERA: Medium shot of Juliana looking directly at Catherine, gestures restrained by the heavy iron chains.
[00:12.50-00:14.50] JULIANA (Mocking, Direct): "But look at you."
[00:15.30-00:19.00] CAMERA: Close-up of Juliana, her eyes burning with fiery contempt.
[00:15.50-00:19.10] JULIANA (Stripping Her Bare): "You have to threaten a chained woman to feel powerful!"
[00:19.00-00:20.90] CAMERA: Close-up of Catherine trembling with uncontrollable rage, teeth bared.
[00:19.10-00:20.70] CATHERINE (Choking with Rage): "You insolent—!"
[00:20.90-00:22.90] CAMERA: Medium shot of Catherine gripping the glowing tongs as Juliana continues speaking over her.
[00:20.90-00:22.80] JULIANA (Steely, Triumphant): "You may have the title you have always wanted..."
[00:22.90-00:27.00] CAMERA: Close-up of Juliana delivering the final emotional blow.
[00:22.90-00:27.00] JULIANA (Final, Condemning): "...but you will never have the courage to earn what you demand from everyone else."
[00:27.00-00:28.50] CAMERA: Close-up of Catherine's face twitching with sheer murderous madness.
[00:27.10-00:28.60] CATHERINE (Enraged, Shouting): "You think you can lecture me?!"
[00:28.50-00:31.30] CAMERA: Medium shot of Catherine raising the branding iron high above her head with both hands.
[00:28.50-00:31.30] ACTION: Catherine hoists the searing branding rod over Juliana with frantic fury.
[00:28.60-00:31.70] CATHERINE (Screaming, Maniacal): "Then let's see how brave you are when it touches your skin!"
[00:31.30-00:32.50] CAMERA: Medium shot of Catherine plunging the glowing orange poker straight toward Juliana's face.
[00:31.70-00:34.88] ACTION: Juliana gasps, freezing as the glowing tip of the iron thrusts forward, stopping mere millimeters from her right eye.
[00:32.50-00:34.88] CAMERA: Extreme close-up of Juliana's wide, unblinking blue eye. The intense, fiery orange glow of the iron poker radiates inches from her cornea, holding on the heart-stopping cliffhanger as the frame cuts to black.
```
</details>

### 5. P005 · 90/100 · 40.1s · High · review: needs_review

- **Cut:** E16 00:14.30–00:54.40
- **Hook:** A thug swings a heavy weapon down, but Alexander catches it mid-air in his bare hand.  
  `ACTION: The thug swings the club down with full force, but Alexander catches the weapon mid-air in his bare hand with chilling ease.`
- **Cliffhanger:** Lifting the thug by his throat, Alexander forces him to confess that Gerald paid them.  
  `THUG WITH CAP: "Harrington! Gerald Harrington paid us!"`
- **Why it works:** Badass action sequence ending with a plot reveal confession.
- **Rank:** A strong action-reveal hybrid that functions well as a standalone hook despite being mid-series.
- Scores: hook 22/25 · clarity 18/20 · cliff 21/25 · emotion 14/15 · coherence 10/10 · duration 5/5
- Critic notes a new viewer may not understand: Who Gerald Harrington is to the couple.

<details><summary>Clip as the viewer sees it</summary>

```
--- CUT 1: episode 16 (source 00:14.30-00:54.40) ---
[00:00.00-00:01.70] CAMERA: Medium action shot as the Thug with Cap lunges forward with his weapon raised high.
[00:00.10-00:01.20] THUG WITH CAP (Roaring): "Aaargh!"
[00:00.10-00:02.50] ACTION: The thug swings the club down with full force, but Alexander catches the weapon mid-air in his bare hand with chilling ease.
[00:01.50-00:02.20] SFX: Heavy blunt impact of a solid hand gripping wood.
[00:02.50-00:05.20] CAMERA: Close-up of the Thug with Cap staring in wide-eyed terror as Alexander grips the bar and wrenches it away effortlessly.
[00:04.90-00:07.50] ACTION: Alexander strikes the thug across the chest and slams him violently into the muddy ground beside the stone wall.
[00:05.50-00:06.90] SFX: Heavy thud of a body crashing into soil and wood.
[00:07.50-00:08.70] CAMERA: Close-up of Juliana watching in breathless astonishment.
[00:08.70-00:11.50] CAMERA: Medium tracking shot as the Bald Thug charges in with a shout, only for Alexander to pivot and seize him by the neck, hurling him across the garden path.
[00:08.70-00:09.50] BALD THUG (Yelling): "Aaargh!"
[00:09.90-00:11.20] SFX: Loud wooden scrape and crunch as the Bald Thug slides across the planks into the fence.
[00:11.50-00:14.20] CAMERA: Medium shot of the Third Thug backing away nervously, raising a blunt rod with trembling arms before lunging.
[00:11.50-00:12.80] THIRD THUG (Desperate, Shouting): "Stay back!"
[00:12.20-00:14.20] ACTION: Alexander deflects the strike with his forearm, drives a swift counter-blow into the thug's torso, and spins him violently to the ground.
[00:12.70-00:13.90] SFX: Solid bone-and-fist impact followed by a groaning thud.
[00:14.20-00:16.70] CAMERA: Wide cinematic shot under the full moon. Alexander towers over the three writhing thugs groaning in the mud as Juliana looks up from her knees.
[00:16.70-00:20.20] CAMERA: Low-angle close-up of Juliana looking up at Alexander, tears glistening on her mud-splattered cheeks in profound relief.
[00:17.70-00:19.50] JULIANA (Breathless, Overwhelmed): "Alexander..."
[00:20.20-00:23.90] CAMERA: Medium shot over Juliana's shoulder as Alexander turns his gaze toward her, his stern demeanor softening with concern.
[00:21.90-00:23.50] ALEXANDER (Gentle, Concerned): "Are you hurt?"
[00:23.90-00:26.50] CAMERA: Close-up of Juliana's trembling, soil-stained hands wrapped in blood-soaked bandages.
[00:23.90-00:25.70] JULIANA (Fragile, Pain-filled): "Only my hands."
[00:26.50-00:29.90] CAMERA: Medium shot as Alexander suddenly wheels around, strides to the groaning Thug with Cap, and yanks him straight off the ground by his coat collar with one arm.
[00:26.90-00:29.70] ACTION: Alexander lifts the thug onto his tiptoes against the cottage wall, glaring with lethal intensity.
[00:28.20-00:29.70] ALEXANDER (Demanding, Threatening): "Who sent you?"
[00:29.90-00:31.90] CAMERA: Close-up of the Thug with Cap gagging under Alexander's iron fist.
[00:29.90-00:31.00] THUG WITH CAP (Choking, Defiant): "No one!"
[00:31.90-00:34.20] CAMERA: Close-up of Alexander, his eyes darkening with lethal fury.
[00:32.00-00:33.10] ALEXANDER (Cold, Ominous): "Wrong answer."
[00:33.70-00:35.70] ACTION: Alexander tightens his grip on the thug's throat, lifting him higher against the stone wall.
[00:34.50-00:35.30] ALEXANDER (Roaring): "Who?!"
[00:35.50-00:38.50] CAMERA: Extreme close-up of the terrified thug gasping for air, his eyes bulging.
[00:35.50-00:37.90] THUG WITH CAP (Screaming, Panicked): "Harrington! Gerald Harrington paid us!"
[00:38.50-00:40.10] CAMERA: Close-up of Juliana on the ground, reeling in devastated disbelief as the betrayal hits her.
[00:38.90-00:40.10] JULIANA (Shaken, Heartbroken): "Gerald..."
```
</details>

### 6. P006 · 89/100 · 47.2s · Medium · review: recommended

- **Cut:** E45 01:14.50–02:01.75
- **Hook:** Alexander hoists Juliana's hand, proclaiming her the Duchess of Ashburton!  
  `ALEXANDER: "Lady Juliana Ashcroft is my lawful wife... and the Duchess of Ashburton!"`
- **Cliffhanger:** A High Priest crashes the hall, invalidating their marriage, making Catherine smile vindictively.  
  `ACTION: Catherine raises her chin, a vindictive smirk spreading across her lips as she realizes her rival's claim has just been torn to pieces.`
- **Why it works:** It uses a classic 'double reversal'—victory followed by immediate, crushing defeat.
- **Rank:** The double reversal is a powerful hook for high-episode series, keeping veteran users engaged.
- Scores: hook 20/25 · clarity 15/20 · cliff 25/25 · emotion 14/15 · coherence 10/10 · duration 5/5
- Critic notes a new viewer may not understand: The legal specifics of why a priest wouldn't have authority.

<details><summary>Clip as the viewer sees it</summary>

```
--- CUT 1: episode 45 (source 01:14.50-02:01.75) ---
[00:00.00-00:06.00] CAMERA: Medium shot as Alexander stops in the center of the nave and raises Juliana's hand high above their heads.
[00:00.10-00:05.50] ACTION: Alexander hoists Juliana's hand triumphantly into the air, presenting her to the nobility.
[00:00.30-00:05.90] ALEXANDER (Proclaiming, Powerful): "Lady Juliana Ashcroft is my lawful wife... and the Duchess of Ashburton!"
[00:06.00-00:09.00] CAMERA: Close-up on Rupert and Mary standing in the pews, their eyes wide with horrified disbelief.
[00:07.00-00:08.50] RUPERT (Gasping, Shellshocked): "Juliana?!"
[00:09.00-00:12.00] CAMERA: Wide shot of Alexander and Juliana standing proudly together, exchanging a loving gaze amid the awestruck crowd.
[00:12.00-00:16.00] CAMERA: Wide tracking shot down the cathedral aisle as the massive wooden entrance doors slam open, framed by blinding daylight and mist.
[00:12.00-00:13.70] SFX: Loud, echoing thud of cathedral doors swinging open violently.
[00:13.00-00:16.50] ACTION: A Catholic Bishop in dark vestments steps through the cathedral doors accompanied by an armed Crown officer.
[00:13.90-00:16.30] HIGH PRIEST (Booming, Stern): "No one will bow yet!"
[00:16.30-00:18.50] CAMERA: Low-angle shot on Alexander and Juliana turning in alarm toward the rear of the cathedral.
[00:18.50-00:26.70] CAMERA: Medium shot of the High Priest striding down the aisle, holding up an official royal parchment bearing red wax seals.
[00:18.70-00:26.50] ACTION: The Priest holds up the sealed royal proclamation, holding his rosary beads as he marches forward.
[00:18.70-00:26.60] HIGH PRIEST (Commanding, Severe): "This ceremony was performed without a Crown marriage license, by a priest without authority to sanctify a ducal union."
[00:26.70-00:31.30] CAMERA: Close-up on the High Priest unfolding the document, reading aloud to the congregation.
[00:27.00-00:31.00] HIGH PRIEST (Stern, Official): "These vows were never entered into the Royal Matrimonial Register."
[00:31.30-00:34.30] CAMERA: Medium shot of Alexander shielding Juliana behind him as the Crown officer approaches with drawn sword.
[00:31.70-00:34.30] HIGH PRIEST (O.S.) (Harsh, Resolute): "Before the Crown, you are not Duchess of Ashburton."
[00:34.30-00:38.70] CAMERA: Close-up of the High Priest scowling directly at Juliana with unyielding authority.
[00:34.50-00:38.50] HIGH PRIEST (Unyielding, Condemning): "You are not Alexander Ashburton's lawful wife."
[00:38.70-00:43.00] CAMERA: Close-up two-shot of Juliana gasping in terror, clutching Alexander's hand tightly as Alexander glares at the Priest.
[00:39.00-00:42.70] ACTION: Juliana looks up at Alexander in sudden panic, her fingers gripping his leather-gloved hand.
[00:43.00-00:47.25] CAMERA: Slow push-in close-up on Catherine beneath her veil, her initial despair morphing into a cold, venomous, triumphant smile as the episode cuts.
[00:43.50-00:47.25] ACTION: Catherine raises her chin, a vindictive smirk spreading across her lips as she realizes her rival's claim has just been torn to pieces.
```
</details>

### 7. P007 · 88/100 · 40.8s · Medium · review: needs_review

- **Cut:** E36 02:40.00–03:20.75
- **Hook:** Alexander growls with murderous wrath: 'They are marrying in two days... and killing my wife afterward.'  
  `ALEXANDER: "...and killing my wife afterward."`
- **Cliffhanger:** Alexander promises vengeance into the blizzard: 'Because before that wedding begins... their dead Duke is coming home.'  
  `ALEXANDER: "...their dead Duke is coming home."`
- **Why it works:** It's pure 'epic revenge' fuel. The dialogue is punchy and the visual of him stepping into the blizzard is cinematic.
- **Rank:** Cinematic 'epic revenge' fuel that appeals to a specific male-gaze demographic to broaden the top-of-funnel reach.
- Scores: hook 22/25 · clarity 14/20 · cliff 22/25 · emotion 15/15 · coherence 10/10 · duration 5/5
- Critic warnings (flag raised, but the matching score is still acceptable): critic flagged missing context but scored standalone_clarity 14/20
- Critic notes a new viewer may not understand: Who 'they' are and why he was in hiding.

<details><summary>Clip as the viewer sees it</summary>

```
--- CUT 1: episode 36 (source 02:40.00-03:20.75) ---
[00:00.00-00:03.00] CAMERA: Tight, terrifying close-up on Alexander's eyes flashing with murderous wrath.
[00:00.50-00:03.00] ALEXANDER (Deadly, Throaty): "...and killing my wife afterward."
[00:03.00-00:07.00] CAMERA: Medium shot as his mother urgently grabs Alexander's coat, pleading with him.
[00:03.20-00:06.80] ALEXANDER'S MOTHER (Pleading, Terrified): "Alexander, you cannot go back there alone!"
[00:07.00-00:11.00] CAMERA: Close-up on Alexander, towering over her, immovable and consumed by purpose.
[00:08.50-00:10.80] ALEXANDER (Grave, Seething): "They already took my name."
[00:11.00-00:14.00] CAMERA: Close-up on Alexander stepping forward, his voice rising with lethal thunder.
[00:11.60-00:13.60] ALEXANDER (Roaring with Conviction): "They stole my home!"
[00:14.00-00:17.00] CAMERA: Tight close-up on his furious, bared teeth and wild eyes.
[00:14.20-00:16.80] ALEXANDER (Venomous): "And now they have taken Juliana!"
[00:17.00-00:19.50] ACTION: Close-up of Alexander's gloved hand clenching into a tight, leather-creaking fist.
[00:17.50-00:19.20] SFX: The sharp, taut creak of leather straining under monstrous grip strength.
[00:19.50-00:24.00] CAMERA: Tracking shot following Alexander as he turns his back on the warmth of the cabin and walks boldly toward the open double barn doors.
[00:20.00-00:24.00] ACTION: Alexander stands framed in the doorway, staring out into the vast, snow-covered pine forest under the cold moonlight.
[00:22.00-00:23.50] ALEXANDER (Calm, Chilling): "Two days."
[00:24.00-00:28.00] CAMERA: Medium shot from inside the cabin, showing his mother clutching her chest, looking after Alexander's imposing silhouette standing at the threshold of the blizzard.
[00:24.50-00:27.80] ALEXANDER (Vow of Vengeance): "Then they have two days to celebrate."
[00:28.00-00:32.50] CAMERA: Side profile close-up on Alexander as his breath fogs into the icy winter night air, his jaw clenched tight.
[00:29.50-00:32.20] ALEXANDER (Low, Menacing Promise): "Because before that wedding begins..."
[00:32.50-00:40.75] CAMERA: Tight side profile close-up of Alexander's battle-scarred cheek and burning gaze as he makes his final declaration.
[00:33.00-00:36.80] ALEXANDER (Cold, Thunderous Finale): "...their dead Duke is coming home."
[00:37.00-00:40.75] ACTION: Alexander stares resolutely ahead into the dark, snowy woods as the camera holds on his grim, determined expression before cutting to black.
[00:37.00-00:40.75] SFX: A heavy, ominous orchestral swell builds to a thunderous cliffhanger sting and reverberates into silence.
```
</details>

### 8. P008 · 87/100 · 42.5s · Medium · review: recommended

- **Cut:** E36 01:39.00–02:21.50
- **Hook:** A mother wails in horror: 'They arrested her! Rupert and Catherine accused her of poisoning me!'  
  `ALEXANDER'S MOTHER: "They arrested her!"`
- **Cliffhanger:** The mother delivers the terrible news: 'She is to be executed.'  
  `ALEXANDER'S MOTHER: "She is to be executed."`
- **Why it works:** Information is delivered rapidly through high-emotion dialogue, making the stakes crystal clear immediately.
- **Rank:** High clarity and rapid information delivery make it a perfect mid-list 'reset' to regain user attention.
- Scores: hook 19/25 · clarity 18/20 · cliff 20/25 · emotion 15/15 · coherence 10/10 · duration 5/5
- Critic notes a new viewer may not understand: How Alexander got his facial scars.

<details><summary>Clip as the viewer sees it</summary>

```
--- CUT 1: episode 36 (source 01:39.00-02:21.50) ---
[00:00.00-00:04.50] CAMERA: Tight close-up on Alexander's mother crying out in wretched guilt and horror.
[00:00.50-00:04.20] ALEXANDER'S MOTHER (Wailing): "They arrested her!"
[00:04.50-00:06.80] CAMERA: Close-up on Alexander, his expression freezing in complete shock.
[00:05.00-00:06.50] ALEXANDER (Stunned): "Arrested?"
[00:06.80-00:11.00] CAMERA: Medium close-up as his mother clutches Alexander's forearms with desperate, pleading hands.
[00:06.90-00:10.80] ALEXANDER'S MOTHER (Despairing): "Rupert and Catherine accused her of poisoning me!"
[00:11.00-00:15.00] CAMERA: Close-up on Alexander, absolute fury erupting across his scarred face.
[00:12.80-00:14.80] ALEXANDER (Shouting, Incredulous): "But she saved you!"
[00:15.00-00:18.00] CAMERA: Close-up on his mother, clutching her chest in grief.
[00:15.20-00:17.50] ALEXANDER'S MOTHER (Weeping): "I told them!"
[00:18.00-00:20.50] CAMERA: Medium shot of Alexander clenching his fists at his sides, trembling with rage.
[00:18.50-00:20.30] ALEXANDER (Furious): "You told them the truth!"
[00:20.50-00:24.00] CAMERA: Close-up on his mother as she cries out, devastated by the memory of the kangaroo court.
[00:20.80-00:23.50] ALEXANDER'S MOTHER (Agonized): "They called her a witch!"
[00:24.00-00:28.50] CAMERA: Frontal medium shot of Alexander standing frozen, the weight of the realization crashing down on him.
[00:24.80-00:27.80] ALEXANDER (Horrified): "Juliana... is in a cell?"
[00:28.50-00:31.80] CAMERA: Close-up of his mother clutching her temple, reeling in remembered trauma.
[00:28.80-00:31.50] ALEXANDER'S MOTHER (Weak, Trembling): "She was taken before a magistrate."
[00:31.80-00:33.00] CAMERA: Tight shot of Alexander, his eyes wild with terror for his wife.
[00:31.90-00:32.80] ALEXANDER (Barking): "And?!"
[00:33.00-00:36.00] CAMERA: Close-up on his mother breaking down into inconsolable sobs.
[00:33.20-00:35.40] ALEXANDER'S MOTHER (Weeping): "They condemned her."
[00:35.50-00:36.20] ALEXANDER (O.S.) (Gasping): "No."
[00:36.00-00:40.00] CAMERA: Close-up on his mother looking up through her tears, delivering the horrifying reality.
[00:37.00-00:39.80] ALEXANDER'S MOTHER (Solemn, Shattered): "She is to be executed."
[00:40.00-00:42.50] CAMERA: Wide shot of the cabin as Alexander stands stiff as iron, stunned by the looming death sentence.
[00:41.20-00:42.50] ALEXANDER (Guttural, Demanding): "When?"
```
</details>

### 9. P009 · 85/100 · 27.2s · Medium · review: recommended

- **Cut:** E3 00:58.30–01:25.50
- **Hook:** Matriarch shouts imperiously: 'Guards! Remove her!' followed by guards forcefully grabbing Juliana.  
  `NOBLE MATRIARCH: "Guards! Remove her!"`
- **Cliffhanger:** The mysterious stranger floors the guard with a bone-rattling punch.  
  `SFX: A heavy, bone-rattling punch followed by the clatter and thud of the guard collapsing onto the stone floor.`
- **Why it works:** Classic 'mysterious savior' trope executed with high physical stakes and a solid punch.
- **Rank:** Uses the 'mysterious savior' trope on an early episode, ensuring high conversion with low spoiler risk.
- Scores: hook 20/25 · clarity 15/20 · cliff 22/25 · emotion 14/15 · coherence 9/10 · duration 5/5
- Critic notes a new viewer may not understand: Who the man in the trench coat is.; Why the guards are removing her.

<details><summary>Clip as the viewer sees it</summary>

```
--- CUT 1: episode 3 (source 00:58.30-01:25.50) ---
[00:00.00-00:01.70] NOBLE MATRIARCH (Shouting, Imperious): "Guards! Remove her!"
[00:01.70-00:03.70] CAMERA: Medium shot as two royal guards in red uniforms and bearskin caps step in behind Juliana and seize her arms.
[00:02.20-00:04.20] ACTION: The guards forcefully grab Juliana by both shoulders and drag her backwards.
[00:02.30-00:04.00] LADY JULIANA (Screaming, Resisting): "Let me go!"
[00:03.70-00:04.90] CAMERA: Close-up of Juliana's hand frantically grabbing the wooden rim of a pew, knuckles white with strain.
[00:04.10-00:05.20] LADY JULIANA (Desperate, Begging): "Please! Someone!"
[00:04.70-00:06.20] ACTION: The guards tear her grip away from the pew.
[00:04.70-00:06.20] SFX: Muffled scuffle, rustle of heavy silk and frantic gasps echoing off cathedral stone.
[00:06.20-00:07.70] CAMERA: High wide shot down the vaulted cathedral aisle showing the entire congregation watching in stunned silence as the guards drag Juliana.
[00:07.70-00:09.80] CAMERA: Wide eye-level shot looking down the petal-strewn marble aisle. A tall, rugged man in a worn dark trench coat—The Bearded Stranger—emerges into the center of the nave.
[00:07.70-00:09.80] ACTION: The Bearded Stranger steps deliberately into the aisle, his heavy boots echoing.
[00:09.80-00:12.20] CAMERA: Close-up on the Noble Matriarch freezing in utter shock and outrage.
[00:11.60-00:13.80] THE BEARDED STRANGER (Low, Thunderous, Imposing): "Take your hands off her."
[00:12.20-00:14.50] CAMERA: Medium tracking shot front-on as The Bearded Stranger marches down the flower-strewn aisle with resolute purpose.
[00:14.50-00:16.80] CAMERA: Medium shot on the Noble Matriarch stepping forward on the altar steps, furiously pointing a finger at him.
[00:14.70-00:18.50] NOBLE MATRIARCH (Indignant, Screeching): "And who are you to give orders in my family's chapel?!"
[00:16.80-00:18.70] CAMERA: High wide shot of the magnificent vaulted hall as The Bearded Stranger walks steadily forward, dwarfing the aisle.
[00:18.70-00:20.70] CAMERA: Medium shot on the lead royal guard squaring his shoulders, barring the stranger's advance while Juliana stands behind him.
[00:18.90-00:20.60] ROYAL GUARD (Aggressive, Threatening): "Stand aside, stranger!"
[00:20.70-00:22.70] CAMERA: Medium close-up profile on The Bearded Stranger, eyes burning with quiet, lethal resolve.
[00:21.00-00:22.60] THE BEARDED STRANGER (Quiet, Deadly): "I said..."
[00:22.70-00:25.70] CAMERA: Close-up on The Bearded Stranger's intense, scarred face.
[00:23.50-00:25.60] THE BEARDED STRANGER (Dangerous, Uncompromising): "...let her go."
[00:25.70-00:27.20] CAMERA: Medium action shot as the guard charges toward The Bearded Stranger.
[00:25.70-00:27.20] ACTION: The Bearded Stranger effortlessly blocks the guard's strike and drives a devastating strike into him, dropping the armed guard instantly to the floor.
[00:26.20-00:27.10] SFX: A heavy, bone-rattling punch followed by the clatter and thud of the guard collapsing onto the stone floor.
```
</details>

### 10. P010 · 84/100 · 23.3s · Medium · review: recommended

- **Cut:** E22 01:45.50–02:08.80
- **Hook:** Juliana sneaks into the forbidden shadowy bedchamber of the gasping Dowager Duchess.  
  `CAMERA: Slow tracking shot into the cavernous, shadowy bedchamber. In the center stands an ornate four-poster canopy bed draped in pale silk where a frail, silv`
- **Cliffhanger:** "Who has been treating you?"  
  `LADY JULIANA: "Who has been treating you?"`
- **Why it works:** It uses classic suspense tropes effectively to build curiosity about a medical mystery.
- **Rank:** Effective medical mystery tropes offer a change of pace from the revenge-heavy lineup.
- Scores: hook 20/25 · clarity 15/20 · cliff 22/25 · emotion 13/15 · coherence 10/10 · duration 4/5
- Critic notes a new viewer may not understand: Juliana's relationship to the Duchess.

<details><summary>Clip as the viewer sees it</summary>

```
--- CUT 1: episode 22 (source 01:45.50-02:08.80) ---
[00:00.00-00:03.00] ACTION: Lady Juliana reaches out with a trembling hand and quietly turns the ornate brass and glass door knob.
[00:00.00-00:03.00] CAMERA: Close-up of Lady Juliana's hand twisting the latch handle.
[00:01.00-00:03.00] SFX: Faint, muffled click of the heavy door lock turning.
[00:03.00-00:08.30] CAMERA: Slow tracking shot into the cavernous, shadowy bedchamber. In the center stands an ornate four-poster canopy bed draped in pale silk where a frail, silver-haired figure lies motionless.
[00:03.50-00:08.50] SFX: Labored, raspy, shallow breathing echoing in the quiet room.
[00:08.30-00:10.50] ACTION: Lady Juliana hurries inside, sets the wooden bucket onto the floor, and rushes to the bedside.
[00:08.50-00:10.00] LADY JULIANA (Gentle, Concerned): "Your Grace?"
[00:10.00-00:12.70] CAMERA: Close-up of the Dowager Duchess lying propped on pillows, her face gaunt, ashen, and drenched in cold sweat, her eyes half-fluttering.
[00:12.70-00:15.30] CAMERA: Medium close-up of Lady Juliana taking the Duchess's fragile, cold hands into her own.
[00:12.70-00:14.30] LADY JULIANA (Soft, Comforting): "Do not speak."
[00:15.30-00:20.00] CAMERA: Close-up of Lady Juliana checking the Duchess's pulse and gently pressing her fingertips against the Duchess's chest and neck, her herbalist instincts taking over.
[00:17.50-00:20.30] ACTION: Lady Juliana's eyes widen with sudden, horrifying realization.
[00:18.00-00:20.30] LADY JULIANA (Shocked, Murmuring): "This isn't ordinary fever."
[00:20.30-00:21.50] ACTION: The Dowager Duchess suddenly gasps violently for breath, convulsing weakly as her eyes snap open in agony.
[00:20.30-00:21.50] CAMERA: Close-up of the Duchess gasping in sudden spasms.
[00:21.50-00:23.30] CAMERA: Intense two-shot as Lady Juliana leans in close, gripping the Duchess's shoulder with urgent desperation.
[00:21.70-00:23.30] LADY JULIANA (Urgent, Alarmed): "Who has been treating you?"
```
</details>

### 11. P011 · 84/100 · 36.8s · Low · review: needs_review

- **Cut:** E11 00:16.80–00:53.60
- **Hook:** Gerald snarls that Alexander stole his gold pocket watch.  
  `GERALD: "Your husband stole my gold pocket watch!"`
- **Cliffhanger:** Alexander coldly permits the search despite Juliana's frantic defense, leaving the outcome unresolved.  
  `ALEXANDER: "Search it."`
- **Why it works:** Clear conflict, clear stakes (prison/theft), and a surprising reaction from the hero.
- **Rank:** Clear stakes and a surprising hero reaction offer high clarity for users with shorter attention spans.
- Scores: hook 18/25 · clarity 18/20 · cliff 21/25 · emotion 12/15 · coherence 10/10 · duration 5/5
- Critic notes a new viewer may not understand: Why Alexander is so calm if he's being framed.

<details><summary>Clip as the viewer sees it</summary>

```
--- CUT 1: episode 11 (source 00:16.80-00:53.60) ---
[00:00.00-00:01.70] CAMERA: Medium close-up of Gerald pointing an accusatory finger, his composure snapping into hostile anger.
[00:00.00-00:01.90] GERALD (Aggressive, Snarl): "Your husband stole my gold pocket watch!"
[00:01.70-00:03.20] CAMERA: Close-up of Juliana recoiling in utter disbelief.
[00:02.20-00:03.20] JULIANA (Incredulous, Gasping): "What? When?"
[00:03.20-00:05.20] CAMERA: Close-up of Gerald narrowing his eyes vindictively.
[00:04.10-00:05.50] GERALD (Cold, Certain): "The last time I came here."
[00:05.20-00:07.80] CAMERA: Medium shot of Juliana scoffing, stepping forward as Alexander stands motionless behind her.
[00:06.20-00:08.00] JULIANA (Contemptuous, Outraged): "You never even entered the cottage!"
[00:07.80-00:10.10] CAMERA: Close-up of Gerald smirking with condescending amusement.
[00:08.40-00:10.20] GERALD (Smug, Threatening): "Then you should have nothing to fear from a search."
[00:10.10-00:12.10] CAMERA: Three-shot of Alexander, Juliana, and Gerald in the bleak drizzle.
[00:10.50-00:12.20] JULIANA (Adamant, Protective): "Alexander would never steal from you."
[00:12.10-00:15.60] CAMERA: Low-angle shot of Gerald throwing his head back in arrogant, mocking laughter.
[00:12.50-00:16.00] GERALD (Mocking, Spiteful): "Of course you would defend him. You married a beggar!"
[00:15.60-00:18.10] CAMERA: Medium close-up of Alexander stepping past Juliana, his gaze murderous and jaw rigid.
[00:16.20-00:18.10] ALEXANDER (Low, Menacing): "Choose your next words carefully."
[00:18.10-00:20.20] CAMERA: Medium shot of Gerald pointing back toward the approaching Constable, feigning alarm.
[00:18.30-00:20.30] GERALD (Shouting, Dramatic): "You hear that? He threatens me again!"
[00:20.20-00:22.30] CAMERA: Medium shot of the Constable marching into frame between them, holding his truncheon horizontally.
[00:20.60-00:22.40] CONSTABLE (Authoritative, Stern): "I have received a complaint of theft."
[00:22.30-00:24.20] CAMERA: Extreme close-up of Juliana, defiant and resolute.
[00:22.90-00:24.30] JULIANA (Fierce): "A complaint is not proof."
[00:24.20-00:26.50] CAMERA: Close-up of the Constable gesturing with his truncheon toward the cottage door.
[00:24.60-00:26.50] CONSTABLE (Cold, Procedural): "Then a search will settle the matter."
[00:26.50-00:29.20] CAMERA: Medium shot of Juliana backing up to the doorway, spreading her arms wide to block the entrance.
[00:26.70-00:29.50] JULIANA (Desperate, Shouting): "You cannot simply invade our home because this man makes an accusation!"
[00:29.20-00:31.00] CAMERA: Medium close-up of Gerald crossing his arms smugly.
[00:30.00-00:31.50] GERALD (Taunting): "If he has nothing to hide..."
[00:31.00-00:34.00] CAMERA: Extreme close-up push-in on Alexander's scarred face, his eyes smoldering with lethal restraint.
[00:31.60-00:33.20] GERALD (O.S.) (Smug): "...let the constable search."
[00:33.30-00:34.20] ALEXANDER (Dark, Grated): "Search it."
[00:34.00-00:36.80] CAMERA: Medium two-shot of Juliana looking up at Alexander in panicked confusion.
[00:36.00-00:36.80] ALEXANDER (Resigned, Calm): "Let them."
```
</details>

### 12. P012 · 83/100 · 35.2s · Low · review: recommended

- **Cut:** E12 00:00.00–00:35.20
- **Hook:** The constable declares Alexander under arrest for grand theft.  
  `CONSTABLE: "Put out your hands, veteran. You are under arrest for theft."`
- **Cliffhanger:** Juliana steps up and sternly demands Clarissa name her price.  
  `JULIANA: "Name your price, Clarissa. I know you."`
- **Why it works:** Fast-paced and clearly defines the antagonists' conspiracy against the heroes.
- **Rank:** Fast-paced conspiracy building that sets up a different kind of long-term narrative tension.
- Scores: hook 21/25 · clarity 18/20 · cliff 16/25 · emotion 13/15 · coherence 10/10 · duration 5/5
- Critic notes a new viewer may not understand: None; the setup is very clear.

<details><summary>Clip as the viewer sees it</summary>

```
--- CUT 1: episode 12 (source 00:00.00-00:35.20) ---
[00:00.00-00:04.60] CAMERA: Medium shot of the Constable raising a set of heavy iron handcuffs, addressing Alexander sternly in front of the stone hearth.
[00:00.50-00:04.50] CONSTABLE (Authoritative, Stern): "Put out your hands, veteran. You are under arrest for theft."
[00:04.60-00:09.10] CAMERA: Medium shot of Juliana swiftly moving in front of Alexander, placing herself defiantly between him and the Constable's outstretched handcuffs.
[00:04.80-00:06.00] ACTION: Juliana steps firmly forward, shielding Alexander with her body.
[00:05.70-00:08.80] JULIANA (Furious, Defiant): "No! That watch was not in his coat!"
[00:09.10-00:11.80] CAMERA: Close-up of the Constable narrowing his eyes coldly at Juliana.
[00:10.00-00:11.70] CONSTABLE (Blunt, Unyielding): "I found it there myself."
[00:11.80-00:13.90] CAMERA: Close-up of Juliana glaring back with unwavering conviction.
[00:12.30-00:13.90] JULIANA (Passionate, Accusatory): "Then someone put it there!"
[00:13.90-00:20.80] CAMERA: Medium full shot of Gerald framed in the open cottage doorway holding his riding crop, stepping inside with a patronizing, gloating grin.
[00:14.30-00:20.60] GERALD (Smug, Condescending): "The proof is in his coat, Juliana. A valuable pocket watch doesn't just walk into a beggar's pocket."
[00:20.80-00:23.70] CAMERA: Close-up of Alexander, his scarred brow furrowed in dark, quiet defiance.
[00:21.60-00:23.60] ALEXANDER (Low, Steady, Dangerous): "I have never touched your property."
[00:23.70-00:26.90] CAMERA: Medium shot of Gerald pointing his riding crop toward them, with Clarissa hovering behind him in her violet silk gown.
[00:23.70-00:26.80] GERALD (Mocking, Malicious): "Then perhaps your wife should explain why it was found in your coat."
[00:26.80-00:28.00] ACTION: Juliana lunges a step forward, jabbing an accusing finger toward Gerald.
[00:26.80-00:27.90] JULIANA (Enraged, Shouting): "You planted it!"
[00:28.00-00:29.80] CAMERA: Medium shot of Clarissa gliding past Gerald, a venomous, amused smile playing upon her lips.
[00:28.10-00:30.00] CLARISSA (Purring, Taunting): "Oh, dear sister..."
[00:29.80-00:31.00] CAMERA: Tight shot of Alexander's hand clenching into a tight, trembling fist against the glow of the roaring fireplace.
[00:30.00-00:32.40] CLARISSA (O.S.) (Continuing taunt): "...still defending your broken scrap of a man?"
[00:31.00-00:32.40] CAMERA: Close-up of Alexander glaring daggers at Clarissa.
[00:32.40-00:35.20] CAMERA: Medium close-up of Juliana, her eyes narrowing with sharp perception.
[00:32.40-00:35.20] JULIANA (Steely, Resolute): "Name your price, Clarissa. I know you."
```
</details>

### 13. P013 · 82/100 · 29.9s · Low · review: recommended

- **Cut:** E39 01:08.50–01:38.41
- **Hook:** Alexander steps through barn doors into the snow dressed in full navy-and-gold ducal regalia.  
  `ACTION: Alexander emerges in full ducal splendor—dressed in an immaculate navy tailcoat lined with gold embroidery, double-breasted brass buttons, and a crisp w`
- **Cliffhanger:** Alexander marches through the snow, vowing: 'And I am bringing my wife home.'  
  `ALEXANDER: "And I am bringing my wife home."`
- **Why it works:** It feels like the start of a major action set-piece; the 'No more hiding' line is very effective.
- **Rank:** A high-episode action set-piece that functions as a 'big event' promo for current users.
- Scores: hook 18/25 · clarity 15/20 · cliff 21/25 · emotion 13/15 · coherence 10/10 · duration 5/5
- Critic notes a new viewer may not understand: How he got a loyalist soldier to just be waiting there in the snow.

<details><summary>Clip as the viewer sees it</summary>

```
--- CUT 1: episode 39 (source 01:08.50-01:38.41) ---
[00:00.00-00:03.30] CAMERA: Wide tracking shot through double wooden barn doors opening outward onto a vast, snow-covered landscape as Alexander steps forward into the light.
[00:00.00-00:03.30] ACTION: Alexander emerges in full ducal splendor—dressed in an immaculate navy tailcoat lined with gold embroidery, double-breasted brass buttons, and a crisp white cravat.
[00:03.30-00:06.30] CAMERA: Extreme close-up of Alexander's hand adjusting the ornate golden lion crest pinned at his cravat.
[00:06.30-00:09.30] CAMERA: Medium low-angle shot as a loyalist soldier drops down onto one knee before him in the snow.
[00:07.30-00:08.70] LOYALIST (Reverent, Submissive): "Your Grace."
[00:09.30-00:14.00] CAMERA: Close-up profile of Alexander, his breath pluming in the winter cold, his eyes hardened like steel.
[00:12.00-00:13.70] ALEXANDER (Authoritative, Command): "Secure the chapel."
[00:14.00-00:16.70] CAMERA: Medium close-up of the soldier rising and snapping a crisp military salute.
[00:15.30-00:16.70] LOYALIST (Resolute): "Yes, Your Grace."
[00:16.70-00:26.50] CAMERA: Slow dramatic tracking shot moving backward in front of Alexander as he strides purposefully through the deep snow, the wooden chapel looming in the distance behind him.
[00:17.00-00:18.70] ALEXANDER (Powerful, Roaring Defiance): "No more hiding."
[00:19.00-00:21.70] ALEXANDER (Fierce, Unyielding): "I am taking back my house."
[00:21.70-00:26.50] ACTION: Alexander marches forward unstoppably, his long coat fluttering in the winter wind as his icy gaze locks forward.
[00:26.50-00:29.91] CAMERA: Dramatic push-in close-up directly onto Alexander's scarred, fierce face as he speaks with absolute conviction.
[00:26.50-00:29.50] ALEXANDER (Passionate, Unstoppable Vow): "And I am bringing my wife home."
[00:29.30-00:29.91] ACTION: Alexander's eyes burn with furious determination as the screen cuts sharply to black.
```
</details>

### 14. P014 · 82/100 · 43.7s · Low · review: recommended

- **Cut:** E42 00:33.80–01:17.50
- **Hook:** Alexander coldly confronts his rival: 'Here I stand. That is the lie you built your life upon.'  
  `ALEXANDER: "And yet, here I stand. That is the lie you built your life upon."`
- **Cliffhanger:** Alexander's mother proclaims him the rightful Duke before he vows cold retribution on Rupert.  
  `ALEXANDER: "And now, Rupert... we settle what you stole."`
- **Why it works:** The emotional reunion with the mother provides heart, while the 'rightful heir' trope provides a clear, satisfying conflict.
- **Rank:** Emotional heart and the 'rightful heir' trope provide a necessary tonal shift toward satisfying drama.
- Scores: hook 18/25 · clarity 15/20 · cliff 20/25 · emotion 14/15 · coherence 10/10 · duration 5/5
- Critic notes a new viewer may not understand: How the church was ruined (no explosion shown here).; The exact nature of what Rupert 'stole' beyond the title.

<details><summary>Clip as the viewer sees it</summary>

```
--- CUT 1: episode 42 (source 00:33.80-01:17.50) ---
[00:00.00-00:06.10] CAMERA: Wide tracking shot behind Alexander as he advances down the center aisle, silhouetted against the ruins of the cathedral nave.
[00:00.20-00:06.00] ALEXANDER (Cold, Commanding): "And yet, here I stand. That is the lie you built your life upon."
[00:06.10-00:11.00] CAMERA: Medium shot of an elderly silver-haired woman in simple ivory robes stepping into the aisle, her hands outstretched in trembling awe.
[00:06.40-00:08.70] ALEXANDER'S MOTHER (Choked with Tears): "Alexander..."
[00:11.00-00:14.20] ACTION: Alexander halts his march as his mother reaches him, placing her frail hands gently upon his chest.
[00:14.20-00:15.20] ALEXANDER (Soft, Reverent): "Mother."
[00:15.20-00:20.20] ACTION: His mother gently cradles Alexander's scarred cheek, tears streaming down her face as guests in the background watch in stunned silence.
[00:15.40-00:20.00] ALEXANDER'S MOTHER (Overcome, Loving): "Look at you... my beautiful boy."
[00:20.20-00:29.70] CAMERA: Medium two-shot framed down the ruined nave between Alexander and his mother.
[00:20.20-00:28.00] ALEXANDER'S MOTHER (Tearful, Proud): "I saw you again... but seeing you like this... I see my son as he was always meant to be."
[00:28.20-00:30.20] ALEXANDER (Tender, Resolute): "I have come home, Mother."
[00:30.20-00:38.70] ACTION: Alexander's mother turns toward the gathered nobility and guards, raising her chin and pointing proudly toward Alexander.
[00:30.40-00:38.60] ALEXANDER'S MOTHER (Ringing, Authoritative): "Let everyone hear me! This is my son... Alexander Ashburn. The rightful Duke of Ashburn!"
[00:38.70-00:40.00] CAMERA: Medium shot of Rupert cowering on the altar steps beside Catherine and her father, utterly defeated.
[00:40.00-00:43.70] CAMERA: Tight close-up on Alexander, his hand resting on the hilt of his sabre as his eyes burn with fierce, cold retribution.
[00:40.00-00:43.70] ALEXANDER (Grim, Vengeful): "And now, Rupert... we settle what you stole."
```
</details>

### 15. P015 · 81/100 · 43.7s · Low · review: needs_review

- **Cut:** E43 01:08.80–01:52.50
- **Hook:** Alexander roars 'You sold my men to the enemy!' at the coward noble.  
  `ALEXANDER: "You sold my men to the enemy."`
- **Cliffhanger:** "Going somewhere, Lord Sterling?"  
  `POLICE CONSTABLE: "Going somewhere, Lord Sterling?"`
- **Why it works:** It's a highly satisfying 'justice' clip where the villains finally lose.
- **Rank:** A high-satisfaction 'justice' clip that provides emotional payoff, though it risks spoiling villain arcs.
- Scores: hook 22/25 · clarity 16/20 · cliff 15/25 · emotion 13/15 · coherence 10/10 · duration 5/5
- Critic warnings (flag raised, but the matching score is still acceptable): critic flagged predictable/resolved ending but scored cliffhanger_strength 15/25
- Critic notes a new viewer may not understand: The specific legal mechanics of the 'death register'.

<details><summary>Clip as the viewer sees it</summary>

```
--- CUT 1: episode 43 (source 01:08.80-01:52.50) ---
[00:00.00-00:02.40] CAMERA: Low-angle shot on Alexander towering over the fallen Rupert.
[00:00.20-00:02.50] ALEXANDER (Furious, Thunderous): "You sold my men to the enemy."
[00:02.40-00:03.90] CAMERA: Close-up on Rupert waving his hands defensively, hyperventilating.
[00:02.60-00:03.90] BLOND NOBLEMAN (Desperate, Denying): "I didn't!"
[00:03.90-00:06.00] CAMERA: Low-angle tracking push-in on Alexander raising the red-ribboned war document toward the cathedral arches.
[00:04.00-00:06.40] ALEXANDER (Resonant, Accusatory): "And when you believed I was dead..."
[00:06.00-00:07.20] CAMERA: Quick reaction shot on Rupert gasping on the steps.
[00:07.20-00:09.00] CAMERA: Tight close-up on Alexander's scarred, furious face.
[00:07.30-00:08.80] ALEXANDER (Venomous): "You took my title."
[00:09.00-00:12.20] CAMERA: Extreme close-up on the Crown Official's gloved thumb cracking the red wax seal open.
[00:09.20-00:10.60] SFX: Brittle snap of breaking sealing wax.
[00:12.20-00:16.20] CAMERA: Full shot of the Crown Official standing amidst church debris reading the death register.
[00:12.70-00:17.00] CROWN OFFICIAL (Grave, Official): "Official death confirmation was filed three months after the ambush."
[00:16.20-00:19.20] CAMERA: Two-shot of the Crown Official in the background and Alexander's dark silhouette in the foreground.
[00:17.20-00:19.70] CROWN OFFICIAL (Continuing): "Duke Alexander Ashburn was declared dead."
[00:19.20-00:24.40] CAMERA: Wide majestic shot capturing the entire nave, the rows of horrified guests, and the ruined cathedral windows.
[00:19.80-00:24.20] CROWN OFFICIAL (Loud, Authoritative): "His estate and title were subsequently transferred under false authority."
[00:24.40-00:27.70] CAMERA: Medium close-up on Rupert clutching his chest as if choking on his own lies.
[00:24.60-00:27.60] BLOND NOBLEMAN (Screaming, Desperate): "I was told he was dead!"
[00:27.70-00:31.00] CAMERA: Low shot following Alexander's heavy boots stepping steadily up the stone steps toward the altar.
[00:28.00-00:31.00] ALEXANDER (Cold, Penetrating): "You were told exactly what you needed to hear."
[00:31.00-00:33.40] CAMERA: Medium shot on Rupert whirling around in a frenzy, pointing his finger toward Lord Sterling.
[00:31.20-00:33.40] BLOND NOBLEMAN (Frantic, Betraying): "Sterling handled the report!"
[00:33.40-00:34.60] CAMERA: Alexander turns his head sharply toward the side pews.
[00:34.60-00:36.00] CAMERA: Medium shot of Lord Henry Sterling silently slipping out of his seat and making a break toward the side exit.
[00:36.00-00:37.70] CAMERA: Close-up on Catherine peering out from under her bridal veil in shock.
[00:36.00-00:37.40] CATHERINE (Shocked, Murmuring): "My Lord?"
[00:37.70-00:41.00] CAMERA: Medium shot of Lord Sterling frantically unlatching the heavy oak church door and pulling it open.
[00:38.20-00:40.20] SFX: Heavy iron latch clicking open and wooden door creaking.
[00:41.00-00:43.70] CAMERA: Reverse angle from inside the doorway showing a stern British Police Constable standing directly outside, blocking the passage.
[00:41.60-00:43.70] POLICE CONSTABLE (Firm, Sardonic): "Going somewhere, Lord Sterling?"
```
</details>

### 16. P016 · 81/100 · 25.2s · Low · review: recommended

- **Cut:** E27 02:02.80–02:28.00
- **Hook:** Lady Catherine maliciously twists Juliana's words, falsely claiming she confessed to poisoning the Duchess.  
  `LADY CATHERINE: "She admits she has been giving the Duchess poison in secret!"`
- **Cliffhanger:** The guard twists Juliana around and drags her forcibly toward the doorway as she struggles against his grip.  
  `ACTION: The guard twists Juliana around and drags her forcibly toward the doorway as she struggles against his grip.`
- **Why it works:** The 'frame-up' trope is executed with enough speed to make the viewer feel frustrated for the hero.
- **Rank:** Fast-paced frustration-hook that triggers a strong emotional urge to see the hero's name cleared.
- Scores: hook 16/25 · clarity 16/20 · cliff 20/25 · emotion 14/15 · coherence 10/10 · duration 5/5
- Critic notes a new viewer may not understand: Who the 'Blond Nobleman' is.

<details><summary>Clip as the viewer sees it</summary>

```
--- CUT 1: episode 27 (source 02:02.80-02:28.00) ---
[00:00.00-00:01.80] CAMERA: Medium shot of Lady Catherine turning abruptly to the guard stationed by the open door, pointing with feigned outrage.
[00:00.30-00:01.70] LADY CATHERINE (Shrieking, Feigning Horror): "You hear that?!"
[00:01.80-00:05.70] CAMERA: Close-up of Lady Catherine twisting Juliana's words with malicious glee.
[00:02.00-00:05.60] LADY CATHERINE (Venomous, Accusing): "She admits she has been giving the Duchess poison in secret!"
[00:05.70-00:08.20] CAMERA: Close-up of Juliana recoiling in shock at the blatant lie.
[00:05.90-00:08.00] JULIANA (Desperate, Outraged): "That is not what I said!"
[00:08.20-00:11.20] CAMERA: Medium close-up of the Blond Nobleman raising his black-gloved hand, silencing the room.
[00:08.40-00:09.80] BLOND NOBLEMAN (Authoritative, Icy): "Enough."
[00:11.20-00:16.60] CAMERA: Medium two-shot as the Blond Nobleman steps into Juliana's personal space and plucks the glass dropper vial from her hand.
[00:12.00-00:15.70] ACTION: The Blond Nobleman takes the medicine vial from Juliana's grasp, inspecting it under the candlelight.
[00:13.40-00:16.50] BLOND NOBLEMAN (Cold, Calculating): "An unknown servant enters a restricted chamber."
[00:16.60-00:21.40] CAMERA: Tight close-up of the Blond Nobleman holding the vial beside his temple, his blue eyes cold and triumphant.
[00:16.80-00:21.00] BLOND NOBLEMAN (Condemning, Vindictive): "She secretly administers an unidentified substance to a helpless woman."
[00:21.20-00:22.10] BLOND NOBLEMAN (To Guard, Stern): "Take her."
[00:21.40-00:24.70] CAMERA: Wide shot as the armed guard storms forward, seizing Juliana roughly by both arms.
[00:22.20-00:25.20] ACTION: The guard twists Juliana around and drags her forcibly toward the doorway as she struggles against his grip.
```
</details>

### 17. P017 · 80/100 · 39.4s · Low · review: recommended

- **Cut:** E48 00:34.00–01:13.40
- **Hook:** Catherine hissed: 'Everyone in that chapel saw me humiliated today. Good.'  
  `CATHERINE: "Everyone in that chapel saw me humiliated today."`
- **Cliffhanger:** "And make sure no one sees him arrive."  
  `CATHERINE: "And make sure no one sees him arrive."`
- **Why it works:** It signals that the show isn't over yet and the villain is still dangerous.
- **Rank:** Signals narrative longevity for a nearly-finished series, keeping users locked into the ecosystem.
- Scores: hook 17/25 · clarity 15/20 · cliff 20/25 · emotion 13/15 · coherence 10/10 · duration 5/5
- Critic notes a new viewer may not understand: Who Father Thomas is and what a priest can do for her.

<details><summary>Clip as the viewer sees it</summary>

```
--- CUT 1: episode 48 (source 00:34.00-01:13.40) ---
[00:00.00-00:09.00] CAMERA: Two-shot profile of Catherine towering over Agnes in the candlelight.
[00:00.20-00:03.10] CATHERINE (Fierce, Hissing): "Everyone in that chapel saw me humiliated today."
[00:03.30-00:05.00] CATHERINE (Spiteful, calculating): "Good. Let them remember it."
[00:05.20-00:09.00] CATHERINE (Sinister, Predatory): "Grief makes people careless, and carelessness is exactly what I need from that household right now."
[00:09.00-00:12.80] CAMERA: Over-the-shoulder close-up on Agnes, her brow furrowed in anxious alarm.
[00:09.30-00:12.80] AGNES (Anxious, Whispering): "My lady... the Duke has bailiffs watching every road out of the county."
[00:12.80-00:17.50] CAMERA: Close-up on Catherine, a smug, venomous smile spreading across her painted lips.
[00:13.00-00:17.30] CATHERINE (Confident, Devious): "I'm not leaving the county, Agnes. I'm going back into that house."
[00:17.50-00:24.20] CAMERA: Medium tracking shot following Catherine as she releases Agnes and stalks across the room toward the window sill.
[00:18.00-00:21.00] CATHERINE (Pleased, Scheming): "Father Thomas did his part beautifully today."
[00:21.20-00:24.20] CATHERINE (Calculated, Demanding): "Now I need him to do a little more before that hearing convenes."
[00:24.20-00:27.00] CAMERA: Medium close-up of Agnes glancing nervously over her shoulder.
[00:24.50-00:26.60] AGNES (Apprehensive): "If someone sees him come to you..."
[00:27.00-00:32.90] CAMERA: Close-up on Catherine spinning around from the window, her jaw set in terrifying firmness.
[00:27.80-00:30.00] CATHERINE (Stern, Threatening): "Then no one sees him."
[00:30.30-00:32.90] CATHERINE (Authoritative): "That is precisely your job tonight."
[00:32.90-00:39.40] CAMERA: Medium shot as Catherine picks up a heavy velvet coin purse and places it firmly into Agnes's awaiting open palms.
[00:33.50-00:35.00] SFX: Dull clinking of heavy gold coins inside a leather pouch.
[00:33.80-00:36.50] CATHERINE (Hushed, Commanding): "Send for the priest. Tonight."
[00:36.80-00:39.40] CATHERINE (Firm, Final): "And make sure no one sees him arrive."
```
</details>

### 18. P018 · 80/100 · 54.8s · Low · review: recommended

- **Cut:** E12 00:32.40–01:27.21
- **Hook:** Juliana demands Clarissa name her price to save her husband.  
  `JULIANA: "Name your price, Clarissa. I know you."`
- **Cliffhanger:** Juliana accepts the sadistic challenge to dig bare-handed through razor thorns, asking where the garden is.  
  `JULIANA: "Tell me where the garden is."`
- **Why it works:** The 'sacrificial bride' trope and the specific, visceral threat of the thorns are very effective.
- **Rank:** Visceral imagery and classic tropes make it more compelling than the more generic clips below it.
- Scores: hook 15/25 · clarity 14/20 · cliff 22/25 · emotion 15/15 · coherence 10/10 · duration 4/5
- Critic notes a new viewer may not understand: The logistics of why the Constable is just standing there for a private blackmail deal.

<details><summary>Clip as the viewer sees it</summary>

```
--- CUT 1: episode 12 (source 00:32.40-01:27.21) ---
[00:00.00-00:02.80] JULIANA (Steely, Resolute): "Name your price, Clarissa. I know you."
[00:02.90-00:07.60] CAMERA: Medium close-up of Clarissa smiling with vicious delight.
[00:03.00-00:07.60] CLARISSA (Smooth, Derisive): "You always were clever, Juliana. Always searching for some way to escape."
[00:07.60-00:09.40] CAMERA: Tight shot of Clarissa smoothing her long purple evening glove along her wrist.
[00:07.70-00:09.10] CLARISSA (Scheming): "Perhaps I can give you one."
[00:09.40-00:11.30] CAMERA: Close-up of Juliana watching her with cautious skepticism.
[00:09.80-00:11.10] JULIANA (Guarded, Cold): "What do you want?"
[00:11.30-00:14.20] CAMERA: Medium two-shot of Clarissa in the foreground, turning slowly to face Juliana.
[00:11.60-00:14.00] CLARISSA (Cruel, Savoring): "I want to see you crawl, sister."
[00:14.20-00:20.00] CAMERA: Medium close-up profile tracking shot of Clarissa pacing slowly as she spins her sadistic tale.
[00:14.30-00:19.90] CLARISSA (Theatrical, Vindictive): "My emerald signet ring fell deep into the frozen blackthorn briars at Ashworth Manor. The thorns have grown over it..."
[00:20.00-00:24.40] CAMERA: Close-up of Clarissa flexing her gloved fingers theatrically in front of her face.
[00:20.00-00:24.30] CLARISSA (Chilling, Sarcastic): "...sharp as steel. The ground is frozen, like pure ice."
[00:24.40-00:25.60] ACTION: Gerald bursts into a loud, mocking laugh beside the stony Constable.
[00:24.40-00:28.40] CAMERA: Medium two-shot of Clarissa stepping closer to Juliana, peering down into her eyes with a predatory smile.
[00:24.90-00:28.20] CLARISSA (Demanding, Brutal): "You will retrieve it with your bare hands before the magistrate arrives."
[00:28.40-00:30.80] CAMERA: Medium shot of Gerald tapping his whip against his palm and laughing heartily beside the Constable.
[00:28.40-00:30.70] GERALD (Gleeful, Derisive): "A lady's hands will be shredded to ribbons!"
[00:30.80-00:32.80] CAMERA: Medium three-shot of Clarissa stepping behind Juliana, as Alexander watches helplessly with dark fury.
[00:30.90-00:32.70] CLARISSA (Cold, Transactional): "Do it, and we withdraw the charges."
[00:32.80-00:37.10] CAMERA: Extreme close-up of Clarissa's mouth leaning directly into Juliana's ear, whispering venomously.
[00:33.00-00:36.80] CLARISSA (Whispering, Menacing): "Fail, or refuse, and your husband hangs from the gallows."
[00:37.10-00:41.60] CAMERA: Medium close-up of Alexander stepping up beside Juliana, tenderly placing his large hand on her shoulder.
[00:37.20-00:38.80] ACTION: Alexander rests his scarred hand reassuringly on Juliana's shoulder, leaning in toward her.
[00:37.40-00:41.40] ALEXANDER (Desperate, Protective, Urgent): "Juliana, no. Do not let them hurt you. I can handle the law."
[00:41.60-00:49.40] CAMERA: Close-up of Juliana, her eyes glistening with unshed tears, her hand gripping the fabric over her heart in agony and resolve.
[00:41.80-00:43.60] ACTION: Juliana clutches the front of her rustic grey dress, her breathing trembling.
[00:42.90-00:45.80] JULIANA (Fierce, Emotional, Sacrificial): "I am not letting them take you."
[00:49.10-00:50.60] ACTION: Juliana turns her head sharply back toward Clarissa, her expression hardening with fierce resolution.
[00:49.40-00:54.81] CAMERA: Over-the-shoulder shot past Clarissa onto Juliana's determined face, holding on her fierce, defiant stare as the tension peaks.
[00:50.40-00:52.30] JULIANA (Steely, Resolute): "Tell me where the garden is."
[00:52.30-00:54.81] ACTION: Juliana locks eyes with Clarissa without flinching as the scene freezes on her brave, sacrificial defiance.
```
</details>

### 19. P019 · 80/100 · 42.0s · Low · review: recommended

- **Cut:** E46 01:41.80–02:23.80
- **Hook:** Alexander challenges the priest: a Duke's marriage is judged by the Crown, not parish seals.  
  `ALEXANDER: "A Duke's marriage is judged by the Crown's peerage court, not by a parish priest's seal."`
- **Cliffhanger:** Alexander demands a ten-day trial while Catherine whispers that ten days is plenty of time to destroy them.  
  `CATHERINE: "Ten days is plenty of time."`
- **Why it works:** The ticking clock and the villain's direct address to the camera create a strong sense of impending doom.
- **Rank:** A ticking clock and direct address provide a unique 'breaking the fourth wall' hook style.
- Scores: hook 14/25 · clarity 16/20 · cliff 22/25 · emotion 13/15 · coherence 10/10 · duration 5/5
- Critic notes a new viewer may not understand: What a 'parish priest's seal' signifies in this world's law.

<details><summary>Clip as the viewer sees it</summary>

```
--- CUT 1: episode 46 (source 01:41.80-02:23.80) ---
[00:00.00-00:05.00] CAMERA: Profile medium shot of Alexander confronting the High Priest face-to-face at the foot of the altar.
[00:00.00-00:04.70] ALEXANDER (Cold, Resolute): "A Duke's marriage is judged by the Crown's peerage court, not by a parish priest's seal."
[00:05.00-00:10.00] CAMERA: Low-angle two-shot of the High Priest staring up into Alexander's imposing frame.
[00:05.20-00:09.70] HIGH PRIEST (Stern, Unflinching): "The High Religious Council rules on matters of holy matrimony. That includes yours."
[00:10.00-00:16.70] CAMERA: Medium close-up of Alexander glaring with icy authority.
[00:10.20-00:16.40] ALEXANDER (Defiant, Commanding): "Then let it prove that in ten days, before witnesses. Not with six halberds pointed at me in my own chapel."
[00:16.70-00:22.20] CAMERA: Wide profile two-shot of the High Priest and Alexander locked in an intense standoff before the altar.
[00:17.00-00:21.80] HIGH PRIEST (Chilling, Victorious): "Ten days. And if the council rules against you, this county watches you lose her twice."
[00:22.20-00:24.70] ALEXANDER (Steely, Unfazed): "I'll take that wager over your decree."
[00:24.70-00:25.40] CAMERA: Quick reaction shot of the elderly woman in the pew gripping her beads in distress.
[00:25.40-00:31.70] CAMERA: Wide shot from behind the guards as they surround Alexander and Juliana, halberds and swords pointed inches from Alexander's chest.
[00:25.40-00:31.40] ALEXANDER (Thunderous, Imposing): "Lower them! Or explain to the Crown why its own bailiffs raised iron on the Duke it just confirmed!"
[00:31.70-00:37.00] CAMERA: Medium shot of the High Priest extending his hand toward the guards, commanding them to stand down.
[00:32.20-00:34.20] ACTION: The guards slowly lower their weapon points away from the Duke.
[00:32.40-00:36.70] HIGH PRIEST (Ominous, Warning): "Ten days, Duke. Choose your witnesses well."
[00:37.00-00:38.70] CAMERA: The High Priest turns sharply on his heel and strides past the guards toward the church exit.
[00:37.20-00:40.20] SFX: Shuffling boots and clattering armor as the royal guards turn and retreat down the ruined aisle.
[00:38.70-00:42.00] CAMERA: Slow pan to Catherine standing in her bridal gown beside the sunlit aisle, watching the priest depart before turning to camera with a wicked, predatory smile.
[00:39.40-00:42.00] CATHERINE (Whispering, Malicious): "Ten days is plenty of time."
```
</details>

### 20. P020 · 79/100 · 59.8s · Low · review: needs_review

- **Cut:** E50 00:18.80–01:18.60
- **Hook:** A corrupt priest demands tax collection rights in exchange for his silence in bed.  
  `FATHER THOMAS: "The west territory. Tax collection, all of it. Routed through my office."`
- **Cliffhanger:** Sharp, terrified gasp catching in Agnes's throat.  
  `SFX: Sharp, terrified gasp catching in Agnes's throat.`
- **Why it works:** It balances political stakes (the bribe) with personal stakes (the affair) and ends at the exact moment the secret is compromised.
- **Rank:** Balances complex political and personal stakes for a more sophisticated viewer segment.
- Scores: hook 18/25 · clarity 14/20 · cliff 22/25 · emotion 13/15 · coherence 9/10 · duration 3/5
- Critic notes a new viewer may not understand: Agnes's relationship to the couple (servant, rival, or family).; What 'the hearing' refers to.

<details><summary>Clip as the viewer sees it</summary>

```
--- CUT 1: episode 50 (source 00:18.80-01:18.60) ---
[00:00.00-00:07.70] CAMERA: Medium profile close-up on Father Thomas sitting up tall and bare-chested, Catherine resting her hand firmly over his heart.
[00:00.60-00:06.20] FATHER THOMAS (Calculated, Demanding): "The west territory. Tax collection, all of it. Routed through my office."
[00:07.70-00:11.70] CAMERA: Slight pull back as Catherine pulls her hand back slightly, staring at him in disbelief.
[00:08.40-00:11.40] CATHERINE (Scoffing, Incredulous): "That's not absolution, Thomas. That's a fortune."
[00:11.70-00:17.00] CAMERA: Two-shot centering on Father Thomas leaning toward her, his expression resolute and uncompromising.
[00:12.20-00:16.20] FATHER THOMAS (Steady, Cold): "Absolution is free. Discretion has a price."
[00:17.00-00:21.00] CAMERA: Tight profile close-up between their faces, golden candlelight illuminating Catherine's jaw as she raises her hand to touch his cheek.
[00:17.70-00:20.60] CATHERINE (Soft, Calculating): "Unsupervised. In your hands alone."
[00:21.00-00:24.20] CAMERA: Tight close-up as Father Thomas reaches up and firmly clasps Catherine's hand at his neck.
[00:21.60-00:23.70] FATHER THOMAS (Grave): "For as long as it holds."
[00:24.20-00:29.70] CAMERA: Medium close-up as Catherine breaks into a knowing, seductive smile and taps his chest with her index finger.
[00:24.40-00:29.20] CATHERINE (Softly, Teasing): "Done. You told yourself this ends when the hearing does."
[00:29.70-00:35.70] CAMERA: Close-up on Father Thomas letting out a soft, self-deprecating chuckle before meeting her eyes with smoldering hunger.
[00:31.00-00:35.20] FATHER THOMAS (Chuckle, Resigned): "I've told myself that since the dawn in your bedchamber, and here we are again."
[00:35.70-00:41.00] CAMERA: Extreme close-up of their lips almost grazing, warm candlelight catching the edges of their profiles.
[00:36.00-00:37.70] CATHERINE (Murmuring): "In another room no one uses?"
[00:38.00-00:40.40] FATHER THOMAS (Whispering): "Perhaps I like rooms no one uses."
[00:41.00-00:46.70] CAMERA: Close-up profile as Catherine slides both hands into the dark hair at the back of his neck, pulling him closer.
[00:41.50-00:46.00] CATHERINE (Low, Carnal): "Or perhaps discretion isn't the only thing you've developed a taste for."
[00:46.70-00:51.70] CAMERA: Medium two-shot as Father Thomas pulls Catherine into a fierce, suffocating embrace, burying his face in her neck while she clings to his broad shoulders.
[00:47.00-00:51.70] ACTION: Catherine closes her eyes in surrender as Father Thomas holds her tight against his naked chest, lost in their forbidden entanglement.
[00:51.70-00:54.70] CAMERA: Medium tracking shot following Agnes as she walks cautiously down the dimly lit stone corridor, holding a black iron lantern.
[00:52.00-00:54.70] ACTION: Agnes scans the desolate hallway nervously, her lantern casting elongated shadows against the wall.
[00:54.70-00:57.70] CAMERA: Over-the-shoulder shot behind Agnes as she stops dead in front of an open doorway, peering inside.
[00:55.20-00:57.70] ACTION: Through the crack of the door, Agnes sees Catherine and the shirtless priest locked in an intimate, passionate embrace upon the bed.
[00:57.70-00:59.70] CAMERA: Tight close-up on Agnes's face, drained of all color, her eyes bulging in pure terror.
[00:58.00-00:59.70] ACTION: Agnes's jaw drops open in shock as she stifles a cry.
[00:58.40-00:59.80] SFX: Sharp, terrified gasp catching in Agnes's throat.
```
</details>

### 21. P021 · 78/100 · 37.0s · Low · review: needs_review

- **Cut:** E25 01:17.40–01:54.40
- **Hook:** Juliana reveals to Alexander that the Dowager Duchess is being poisoned with arsenic.  
  `JULIANA: "Poison."`
- **Cliffhanger:** Alexander asks with protective anxiety if she intends to return to the house of poisoners.  
  `ALEXANDER: "Will you be going there again?"`
- **Why it works:** It establishes a high-stakes conspiracy and a secret alliance between the leads.
- **Rank:** Establishes a long-term alliance that hooks viewers into a multi-episode conspiracy arc.
- Scores: hook 19/25 · clarity 14/20 · cliff 18/25 · emotion 12/15 · coherence 10/10 · duration 5/5
- Critic warnings (flag raised, but the matching score is still acceptable): critic flagged missing context but scored standalone_clarity 14/20
- Critic notes a new viewer may not understand: Who Alexander is and his relationship to the victim.; Who Prudence is.

<details><summary>Clip as the viewer sees it</summary>

```
--- CUT 1: episode 25 (source 01:17.40-01:54.40) ---
[00:00.00-00:01.50] ALEXANDER (Grim, Low): "What did you find?"
[00:02.10-00:05.10] CAMERA: Tight close-up on Juliana's trembling lips.
[00:02.80-00:04.40] JULIANA (Hushed, Horrified): "Poison."
[00:05.10-00:08.80] CAMERA: Slightly wider close-up as Juliana's eyes well with distress.
[00:06.10-00:07.60] JULIANA (Sober): "Arsenic."
[00:08.80-00:12.60] ACTION: Alexander's hand drops to his side and clenches into a white-knuckled fist, the thick scar across his hand tightening with intense restraint.
[00:08.80-00:12.80] CAMERA: Close-up on Alexander's fist clenching tightly in fury.
[00:12.80-00:20.40] CAMERA: Medium close-up of Juliana, her voice filled with mounting dread.
[00:12.80-00:20.00] JULIANA (Pained, Troubled): "Someone has been giving it to her again and again. Small amounts. Enough to make her weaker without killing her quickly."
[00:20.40-00:22.80] CAMERA: Close-up of Alexander processing the sinister calculation behind the poisoning.
[00:22.80-00:27.80] CAMERA: Two-shot as Juliana looks up at him with quiet hope.
[00:23.00-00:27.40] JULIANA (Sincere, Earnest): "I made her medicine. She was still barely conscious, but her breathing became easier."
[00:27.80-00:30.40] CAMERA: Close-up of Alexander's startled gaze.
[00:28.20-00:29.60] ALEXANDER (Incredulous): "You treated her?"
[00:29.80-00:30.60] JULIANA (Firm): "Yes."
[00:30.40-00:34.40] CAMERA: Close-up profile of the two facing each other.
[00:31.00-00:32.00] ALEXANDER (Tense): "Alone?"
[00:32.40-00:33.80] JULIANA (Soft): "With Prudence."
[00:34.40-00:37.00] CAMERA: Close-up of Alexander, his brow furrowed with deep protective worry.
[00:34.80-00:37.00] ALEXANDER (Anxious): "Will you be going there again?"
```
</details>

### 22. P022 · 78/100 · 32.5s · Low · review: needs_review

- **Cut:** E28 00:37.70–01:10.20
- **Hook:** The bedridden Duchess sits up and publicly accuses Rupert and Catherine of poisoning her.  
  `DOWAGER DUCHESS: "I was poisoned!"`
- **Cliffhanger:** Rupert chillingly claims the poison ruined his mother's mind and orders the guards to lock Juliana away.  
  `BLOND NOBLEMAN: "Take her away before she poisons the rest of this house."`
- **Why it works:** The gaslighting element adds a layer of psychological horror to the period drama.
- **Rank:** Psychological horror elements provide a niche but high-impact hook for variety.
- Scores: hook 18/25 · clarity 14/20 · cliff 18/25 · emotion 13/15 · coherence 10/10 · duration 5/5
- Critic warnings (flag raised, but the matching score is still acceptable): critic flagged missing context but scored standalone_clarity 14/20
- Critic notes a new viewer may not understand: Who Rupert is.; The relationship between the three accusers.

<details><summary>Clip as the viewer sees it</summary>

```
--- CUT 1: episode 28 (source 00:37.70-01:10.20) ---
[00:00.00-00:05.30] CAMERA: Medium low-angle shot past the Duchess pointing directly at Rupert, who stands rigid and expressionless.
[00:00.50-00:02.30] DOWAGER DUCHESS (Fierce, Condemning): "I was poisoned!"
[00:02.60-00:04.50] DOWAGER DUCHESS (Accusing): "And you... you knew!"
[00:05.30-00:09.70] CAMERA: Medium shot of the Duchess lunging forward from the pillows, gasping for breath as she points toward Catherine.
[00:05.90-00:07.60] DOWAGER DUCHESS (Choking, Weakening): "Catherine knew!"
[00:07.90-00:09.30] DOWAGER DUCHESS (Gasping): "They have been—"
[00:09.10-00:10.30] ACTION: The Duchess collapses back onto the pillows, coughing violently and clutching her chest.
[00:09.70-00:14.50] CAMERA: Wide shot as Juliana lunges across the room toward the bed, but the armed guard seizes her from behind and drags her back.
[00:10.50-00:12.00] JULIANA (Panicked, Screaming): "Let me help her!"
[00:11.80-00:14.40] JULIANA (Desperate): "She's still weak, you cannot leave her like this!"
[00:14.50-00:19.10] CAMERA: Medium close-up of Rupert smoothing down his black leather gloves, a chilling smile forming on his lips.
[00:15.10-00:15.90] BLOND NOBLEMAN (Smooth, Feigning Concern): "You see?"
[00:16.30-00:18.90] BLOND NOBLEMAN (Sinister): "The poison has clearly damaged her mind."
[00:19.10-00:23.60] CAMERA: Over-the-shoulder shot of Rupert leaning menacingly over the gasping Duchess in bed.
[00:19.30-00:21.00] DOWAGER DUCHESS (Hoarse, Straining): "I am not delusional!"
[00:20.90-00:22.30] BLOND NOBLEMAN (Condescending, Whispering): "Of course you are not."
[00:22.40-00:23.50] BLOND NOBLEMAN (Dismissive): "You are merely confused."
[00:23.60-00:29.10] CAMERA: Medium profile tracking shot of Catherine walking deliberately toward Juliana, speaking with airy cynicism.
[00:23.90-00:27.10] CATHERINE (Amused, Mocking): "How convenient that the only person who can prove the poison exists..."
[00:27.20-00:29.10] CATHERINE (Smug): "...is the maid who claims to have discovered it."
[00:29.10-00:32.50] CAMERA: Low-angle medium shot of Rupert turning sharply toward the guard, his eyes icy and authoritative.
[00:29.50-00:32.50] BLOND NOBLEMAN (Commanding, Resolute): "Take her away before she poisons the rest of this house."
```
</details>

### 23. P023 · 78/100 · 41.4s · Low · review: recommended

- **Cut:** E18 00:02.10–00:43.50
- **Hook:** Juliana wakes up gasping and coughing violently as fire licks beneath her bedroom door.  
  `CAMERA: Close-up overhead shot of Juliana asleep on her pillow as her eyelids flutter open, gasping and coughing violently from the choking smoke.`
- **Cliffhanger:** Flames completely seal their exit, leaving them trapped in the burning hallway.  
  `JULIANA: "We cannot get through!"`
- **Why it works:** Classic high-stakes survival drama with clear character roles and an escalating physical threat.
- **Rank:** Classic survival drama with clear roles ensures it remains more accessible than the more confusing lower-tier clips.
- Scores: hook 18/25 · clarity 15/20 · cliff 18/25 · emotion 12/15 · coherence 10/10 · duration 5/5
- Critic notes a new viewer may not understand: Why Alexander looks like a 'guardian' or 'Duke' while they are in a modest room.

<details><summary>Clip as the viewer sees it</summary>

```
--- CUT 1: episode 18 (source 00:02.10-00:43.50) ---
[00:00.00-00:03.70] CAMERA: Close-up overhead shot of Juliana asleep on her pillow as her eyelids flutter open, gasping and coughing violently from the choking smoke.
[00:01.40-00:03.90] ACTION: Juliana coughs, her eyes widening in immediate alarm as the smell of burning wood fills her lungs.
[00:03.90-00:07.40] ACTION: Juliana bolts upright in bed, tossing off the woolen quilt as she sees the orange glow under the door.
[00:04.40-00:06.40] JULIANA (Screaming, Terrified): "Alexander!"
[00:07.40-00:10.70] CAMERA: Medium shot as Juliana swings her bare legs out of bed onto the floor, trembling with panic.
[00:08.40-00:10.20] JULIANA (Desperate, Shouting): "Alexander!"
[00:10.70-00:14.10] CAMERA: Low-angle close shot of the bedroom door glowing intensely, fire licking the wooden floorboards as smoke pours inward.
[00:14.10-00:18.00] ACTION: Juliana sits huddled at the edge of the bed, pressing her bandaged hands against her mouth, coughing and sobbing in fear.
[00:15.70-00:17.70] JULIANA (Muffled, Weeping): "Alexander..."
[00:17.40-00:18.90] SFX: A violent crash as the bedroom door is kicked open.
[00:18.00-00:20.70] CAMERA: Framed in the doorway engulfed by blazing orange light, Alexander bursts in, his dark hair flying, looking like an imposing guardian amid the smoke.
[00:18.70-00:20.40] ALEXANDER (Authoritative, Urgency): "Juliana! Get up!"
[00:20.70-00:23.90] CAMERA: Wide tracking shot as Alexander rushes across the burning, smoke-choked room toward her bed.
[00:22.40-00:26.80] ACTION: Alexander reaches the bed, hoisting Juliana up by her arms into a standing embrace.
[00:24.40-00:25.90] JULIANA (Breathless, Distressed): "What happened?"
[00:26.00-00:26.80] ALEXANDER (Grim, Urgent): "Fire."
[00:26.80-00:28.70] CAMERA: Over-the-shoulder shot past Alexander toward the blazing threshold of the main room, beams collapsing across the doorway.
[00:28.70-00:30.90] CAMERA: Medium close-up of Alexander wrapping a heavy coat tightly around Juliana's shoulders.
[00:30.40-00:34.40] ACTION: Alexander clutches Juliana against his chest with one strong arm, shielding her face from the sparks.
[00:31.10-00:33.10] ALEXANDER (Firm, Protective): "Stay close to me."
[00:34.40-00:36.90] CAMERA: Reverse shot from behind them facing the burning door frame as wall-high flames roar, completely sealing their exit.
[00:35.90-00:39.40] ACTION: Juliana recoils from the heat, clutching Alexander's coat tightly.
[00:37.40-00:39.70] JULIANA (Panic-Stricken, Choked): "We cannot get through!"
[00:39.90-00:41.40] ALEXANDER (Resolute, Calm Under Pressure): "Then we go another way."
```
</details>

### 24. P024 · 78/100 · 33.7s · Low · review: recommended

- **Cut:** E24 00:57.80–01:31.50
- **Hook:** The noblewoman threatens Juliana to scrub every stone until her hands are black so she remembers her place.  
  `NOBLEWOMAN: "Every stone. Perhaps when your hands are black enough, you will finally remember what you are."`
- **Cliffhanger:** Juliana touches her hidden antidote vial and vows that the noblewoman cannot stop the healer.  
  `LADY JULIANA: "I will return. You cannot stop the healer."`
- **Why it works:** Underdog resilience story beat with an empowering secret motive.
- **Rank:** Empowering underdog motive offers an optimistic 'beat' in an otherwise dark publishing sequence.
- Scores: hook 15/25 · clarity 15/20 · cliff 19/25 · emotion 14/15 · coherence 10/10 · duration 5/5
- Critic notes a new viewer may not understand: The specific 'punishment' for Prudence.

<details><summary>Clip as the viewer sees it</summary>

```
--- CUT 1: episode 24 (source 00:57.80-01:31.50) ---
[00:00.00-00:06.00] CAMERA: Extreme close-up two-shot as the noblewoman steps unnervingly close to Juliana's face, whispering with sadistic relish.
[00:00.00-00:05.70] NOBLEWOMAN (Intimate, Venomous): "Every stone. Perhaps when your hands are black enough, you will finally remember what you are."
[00:06.00-00:08.20] ACTION: Juliana slowly drops to her knees on the cold flagstones before the soot-filled fireplace.
[00:06.00-00:08.40] CAMERA: Medium shot of Juliana sinking to her knees, her face grim and composed.
[00:08.20-00:09.70] ACTION: Prudence steps toward the noblewoman in distress, her hands clasped tightly.
[00:08.40-00:10.00] CAMERA: Close-up of Prudence's anxious, trembling face.
[00:08.40-00:09.70] PRUDENCE (Desperate, Pleading): "My lady—"
[00:09.70-00:11.70] ACTION: The noblewoman whips around sharply, thrusting the tip of her riding crop directly into Prudence's face.
[00:10.00-00:12.70] CAMERA: Medium close-up of the noblewoman baring her teeth in rage, aiming the crop threateningly.
[00:10.20-00:12.70] NOBLEWOMAN (Furious, Threatening): "Do you want the same punishment?"
[00:12.70-00:15.00] CAMERA: Close-up of Prudence flinching in terror, lowering her eyes immediately.
[00:12.80-00:14.60] PRUDENCE (Terrified, Murmuring): "No, my lady."
[00:14.70-00:16.70] ACTION: Juliana grips a coarse scrubbing brush with both hands and begins vigorously scraping the thick black ash across the hearthstones.
[00:15.00-00:17.00] CAMERA: Close-up shot of Juliana's soot-covered hands fiercely scrubbing the black ash along the stone floor.
[00:15.20-00:23.20] SFX: Rhythmic, harsh rasping sound of bristles scraping against stone.
[00:17.00-00:20.70] CAMERA: Medium shot of the noblewoman leaning casually against the wooden doorframe, watching Juliana toil with smug condescension.
[00:17.20-00:20.20] NOBLEWOMAN (Smug, Gleeful): "That is where clever little servants belong."
[00:20.70-00:23.40] CAMERA: Medium profile shot of Juliana kneeling by the hearth in the dim window light, scrubbing steadily.
[00:20.80-00:23.20] LADY JULIANA (V.O.) (Cold, Resolute): "Let her think I am only a maid."
[00:23.40-00:27.20] ACTION: Juliana pauses scrubbing. Her soot-caked fingers reach into the deep pocket of her apron, carefully feeling the worn leather cover of her mother's remedy journal and the glass dropper bottle securely concealed within.
[00:23.40-00:27.40] CAMERA: Close-up of Juliana's soot-stained hand touching the hidden remedy book and the antidote vial inside her apron pocket.
[00:23.70-00:27.00] LADY JULIANA (V.O.) (Determined, Defiant): "Let her believe I am ignorant."
[00:27.40-00:33.70] ACTION: Juliana raises her head. Smudges of dark soot stain her fair cheek, but her piercing blue eyes burn with unwavering defiance and unyielding resolve as she stares toward the hallway.
[00:27.40-00:33.70] CAMERA: Tight close-up of Juliana's soot-streaked face turning slowly toward the chamber exit, her jaw set firm as dramatic music builds to a powerful crescendo.
[00:27.80-00:32.00] LADY JULIANA (V.O.) (Steely, Unstoppable): "I will return. You cannot stop the healer."
```
</details>

### 25. P025 · 77/100 · 22.6s · Low · review: needs_review

- **Cut:** E42 00:11.20–00:33.80
- **Hook:** A terrified noble screams 'Who are you?' as an imposing figure strides through smoke.  
  `BLOND NOBLEMAN: "Who are you?"`
- **Cliffhanger:** The guards refuse to arrest Alexander, leaving Rupert trembling in terror as he insists Alexander is dead.  
  `BLOND NOBLEMAN: "You cannot be him. Alexander died!"`
- **Why it works:** The 'refusal of the guards' to follow orders is a very satisfying power-shift moment.
- **Rank:** A satisfying power-shift moment that works well as a mid-scroll 'win' for the protagonist.
- Scores: hook 19/25 · clarity 13/20 · cliff 17/25 · emotion 14/15 · coherence 10/10 · duration 4/5
- Critic warnings (flag raised, but the matching score is still acceptable): critic flagged missing context but scored standalone_clarity 13/20
- Critic notes a new viewer may not understand: Why everyone thought he was dead.; Who the 'Blond Nobleman' is marrying.

<details><summary>Clip as the viewer sees it</summary>

```
--- CUT 1: episode 42 (source 00:11.20-00:33.80) ---
[00:00.00-00:01.40] BLOND NOBLEMAN (Shocked, Trembling): "Who are you?"
[00:01.60-00:03.40] ALEXANDER (Low, Resonant): "You already know."
[00:03.40-00:05.40] CAMERA: Close-up on Juliana, her manacled hands clutching at her smock as tears well in her eyes.
[00:03.80-00:05.20] JULIANA (Breathless, Tearful Whisper): "Alexander..."
[00:05.40-00:06.70] CAMERA: Close-up on Alexander, his gaze softening momentarily toward her.
[00:05.60-00:06.70] ALEXANDER (Gentle, Reassuring): "Juliana."
[00:06.70-00:10.30] CAMERA: Medium shot of Rupert descending the altar steps, furiously pointing toward Alexander.
[00:06.80-00:10.00] BLOND NOBLEMAN (Furious, Hysterical): "Guards! Arrest this imposter!"
[00:10.30-00:12.20] CAMERA: Medium shot of the royal guardsman standing rigidly in red uniform and bearskin cap, resting his white-gloved hand on his sabre.
[00:10.80-00:12.20] ROYAL GUARD (Stoic, Defiant): "We will not."
[00:12.20-00:15.30] CAMERA: Close-up on Rupert, veins bulging in his neck as his composure shatters.
[00:12.30-00:14.00] BLOND NOBLEMAN (Screaming, Outraged): "I said arrest him!"
[00:14.30-00:15.30] BLOND NOBLEMAN (Desperate, Unhinged): "Why?!"
[00:15.30-00:17.60] CAMERA: Close-up on the Royal Guard holding his upright blade with unwavering conviction.
[00:15.50-00:17.60] ROYAL GUARD (Firm, Reverent): "Because we know who he is."
[00:17.60-00:19.20] CAMERA: Medium shot of Catherine clutching her father's arm, her bridal bouquet drooping as panic seizes her face.
[00:17.80-00:19.10] CATHERINE (Trembling, Apprehensive): "Rupert..."
[00:19.20-00:22.60] CAMERA: Medium close-up of Rupert gripping the edge of a pew for balance, his eyes wild with terror.
[00:19.30-00:22.60] BLOND NOBLEMAN (Denial, Shaken): "You cannot be him. Alexander died!"
```
</details>

### 26. P026 · 77/100 · 56.7s · Low · review: recommended

- **Cut:** E30 01:34.50–02:31.21
- **Hook:** The Elder Nobleman orders them to manufacture evidence and let the State hang Juliana.  
  `ELDER NOBLEMAN: "Do not hide the evidence, manufacture it. Drag her before the magistrate tomorrow, frame the trial, buy the jury, and let the State hang her."`
- **Cliffhanger:** Juliana shivers in wet rags inside the flooded dungeon cell as the conspirators seal her doom.  
  `ACTION: Juliana clutches a rough burlap rag to her trembling chest, her tear-stained face lifting upward in dread and fragile hope as the frame holds, cutting a`
- **Why it works:** It clearly establishes a high-stakes conspiracy with a visible victim, creating immediate empathy and dread.
- **Rank:** Immediate empathy for a visible victim creates a strong, albeit lower-scoring, emotional hook.
- Scores: hook 18/25 · clarity 18/20 · cliff 15/25 · emotion 13/15 · coherence 10/10 · duration 3/5
- Critic notes a new viewer may not understand: Who exactly is Rupert in relation to the others?

<details><summary>Clip as the viewer sees it</summary>

```
--- CUT 1: episode 30 (source 01:34.50-02:31.21) ---
[00:00.00-00:07.40] CAMERA: Medium three-shot framing Rupert, the Elder Nobleman between them, and Catherine listening closely.
[00:00.10-00:07.30] ELDER NOBLEMAN (Authoritative, Command): "Do not hide the evidence, manufacture it. Drag her before the magistrate tomorrow, frame the trial, buy the jury, and let the State hang her."
[00:07.40-00:09.90] CAMERA: Close-up of Catherine smiling with malicious satisfaction, fluttering her fan.
[00:07.70-00:09.40] CATHERINE (Scheming): "Her botanical ledger..."
[00:09.90-00:12.10] CAMERA: Close-up of the Elder Nobleman nodding slowly.
[00:10.30-00:11.50] ELDER NOBLEMAN (Confirming): "Exactly."
[00:12.10-00:14.50] CAMERA: Close-up of Catherine leaning slightly forward.
[00:12.80-00:14.30] CATHERINE (Inquiring): "And the Dowager?"
[00:14.50-00:22.30] CAMERA: Medium shot of the Elder Nobleman gesturing dismissively with one gloved hand.
[00:15.00-00:22.00] ELDER NOBLEMAN (Dismissive): "She is weak, confused. No magistrate will trust a dying woman's accusations against a respected household."
[00:22.30-00:27.40] CAMERA: Medium close-up of Rupert exhaling deeply, processing the horrifying certainty of their conspiracy.
[00:25.50-00:27.00] RUPERT (Hesitant): "And Juliana?"
[00:27.40-00:30.60] CAMERA: Medium close-up of the Elder Nobleman staring sternly across the desk.
[00:27.90-00:30.40] ELDER NOBLEMAN (Cold, Resolute): "She goes before the magistrate tomorrow."
[00:30.60-00:39.00] CAMERA: Close-up of Catherine beaming with venomous glee, spreading her red fan wide.
[00:31.00-00:38.50] CATHERINE (Cruel, Exultant): "She will hang. A perfect solution. The town will cheer as the witch's disgraced daughter faces the noose."
[00:39.00-00:42.30] CAMERA: Medium shot of Rupert pulling out the desk chair and seating himself with dark resolve.
[00:39.60-00:41.70] RUPERT (Resolute, Vengeful): "I will write the arrest warrant myself."
[00:42.30-00:50.00] CAMERA: Extreme close-up of the Elder Nobleman's weathered face, his eyes cold and predatory in the firelight.
[00:43.00-00:49.00] ELDER NOBLEMAN (Chilling, Decisive): "Tomorrow, she stops being a prisoner. She becomes a witch."
[00:50.00-00:54.00] CAMERA: High-angle shot peering down through the heavy iron dungeon grate into the flooded, pitch-black subterranean wet cells where water drips continuously.
[00:50.00-00:56.71] SFX: Echoing, hollow water droplets splashing into dark pools beneath stone vaults, accompanied by a somber orchestral swell.
[00:54.00-00:56.71] CAMERA: Low-angle medium shot pushing in on Juliana huddled against the wet stone wall, chained by the wrists, shivering in wet rags as faint moonlight filters down through the grate above.
[00:54.00-00:56.71] ACTION: Juliana clutches a rough burlap rag to her trembling chest, her tear-stained face lifting upward in dread and fragile hope as the frame holds, cutting abruptly to black.
```
</details>

### 27. P027 · 77/100 · 57.6s · Low · review: needs_review

- **Cut:** E41 00:17.50–01:00.50 → E42 00:00.00–00:14.60
- **Hook:** Juliana is dragged into the cathedral in heavy chains and prison garb before high society.  
  `ACTION: Juliana, dressed in a coarse drab prison dress with a numbered identification badge, is marched forward by two armed constables holding her by the arms.`
- **Cliffhanger:** Alexander emerges in full ducal regalia through shattered doors and confronts the groom with 'You already know.'  
  `ALEXANDER: "You already know."`
- **Why it works:** The contrast between the lavish cathedral and the brutalized prisoner creates immediate intrigue and investment.
- **Rank:** Visual contrast and intrigue make it more cinematic than the dialogue-heavy clips following it.
- Scores: hook 18/25 · clarity 15/20 · cliff 20/25 · emotion 13/15 · coherence 8/10 · duration 3/5
- Critic notes a new viewer may not understand: The relationship between the woman and the man who enters at the end.; Why she went from 'bride' to 'prisoner'.

<details><summary>Clip as the viewer sees it</summary>

```
--- CUT 1: episode 41 (source 00:17.50-01:00.50) ---
[00:00.00-00:02.50] ACTION: Juliana, dressed in a coarse drab prison dress with a numbered identification badge, is marched forward by two armed constables holding her by the arms.
[00:02.50-00:05.30] CAMERA: Extreme close-up of Juliana's scarred, dirtied wrists bound tight in heavy iron shackles.
[00:05.30-00:08.50] CAMERA: Intense close-up of Juliana's bruised, dirt-streaked face. Her piercing blue eyes burn with fierce dignity despite her captive state.
[00:08.50-00:11.30] CAMERA: Medium shot of Catherine standing beside the altar, watching Juliana's entrance with gloating satisfaction.
[00:09.30-00:10.90] CATHERINE (Smug, Taunting): "There she is."
[00:11.30-00:12.50] CAMERA: Medium tracking shot of Juliana marching between the stern constables down the central aisle toward the altar.
[00:12.50-00:16.50] CAMERA: Medium shot of a seated aristocratic couple in the pews, whispering and sneering behind an ivory lace fan.
[00:13.00-00:14.10] NOBLEWOMAN (Gleeful, Whispering): "Look at her."
[00:14.20-00:16.30] NOBLEMAN (Mocking, Chuckling): "She actually came back to the chapel."
[00:16.50-00:19.30] CAMERA: Close-up of the noblewoman giggling with hand over mouth, glancing spitefully at the disgraced bride.
[00:17.30-00:19.30] NOBLEWOMAN (Scornful, Smug): "Not as a bride this time."
[00:19.30-00:22.30] CAMERA: Medium shot of two senior aristocrats in the carved choir stalls, resting on their canes and nodding in smug agreement.
[00:22.30-00:26.30] CAMERA: Close profile of Juliana as she halts in the center aisle, lifting her chin proudly to face the sneering onlookers.
[00:23.50-00:26.70] CATHERINE (O.S.) (Derisive, Projecting): "Lady Juliana Ashcroft. Look around."
[00:26.30-00:31.00] CAMERA: High-angle wide shot showing Juliana flanked by guards in the center of the lavishly decorated nave, dwarfed by the grand cathedral.
[00:27.50-00:30.50] CATHERINE (V.O.) (Mocking, Resonant): "This is the world you thought you belonged to."
[00:31.00-00:35.30] CAMERA: Low-angle medium shot of Catherine gesturing broadly from the altar steps, looking down upon Juliana like an empress.
[00:31.10-00:34.90] CATHERINE (Spiteful, Boastful): "And now they can all see what you truly are."
[00:35.30-00:40.30] CAMERA: Medium shot of Juliana standing firmly between the guards, calmly meeting Catherine's venomous gaze.
[00:37.30-00:40.00] ACTION: Juliana looks around the cathedral at the sea of pompous faces, then raises her eyes straight back to Catherine with utter disdain.
[00:40.30-00:43.00] CAMERA: Tight close-up on Juliana's bruised, unshaken face.
[00:40.50-00:43.00] JULIANA (Defiant, Unbowed): "You needed an entire chapel to feel powerful over one chained woman?"
--- CUT 2: episode 42 (source 00:00.00-00:14.60) ---
[00:43.00-00:53.50] CAMERA: Low-angle shot through drifting smoke and rubble across the stone floor, tilting up as polished boots step over splintered wood, revealing an imposing nobleman in a gold-embroidered navy coat.
[00:44.00-00:53.50] ACTION: Alexander strides deliberately through the pulverized cathedral doorway. Dressed in the regal ducal coat with gold braided cuffs and a lion crest, his scarred face is set with cold, unyielding authority.
[00:54.20-00:55.60] BLOND NOBLEMAN (Shocked, Trembling): "Who are you?"
[00:55.80-00:57.60] ALEXANDER (Low, Resonant): "You already know."
```
</details>

### 28. P028 · 77/100 · 38.8s · Low · review: needs_review

- **Cut:** E24 00:04.00–00:42.80
- **Hook:** A haughty noblewoman armed with a riding crop confronts Juliana inside the Duchess's room.  
  `NOBLEWOMAN: "Who are you?"`
- **Cliffhanger:** After striking Juliana violently across the torso with a whip, the noblewoman coldly declares she is not a woman whose opinion matters.  
  `NOBLEWOMAN: "And certainly not a woman whose opinion matters."`
- **Why it works:** The extreme cruelty of the 'Let her suffer' line creates instant hatred for the villain.
- **Rank:** Instant villain-heat through extreme cruelty, though it requires more emotional investment than the clips above.
- Scores: hook 15/25 · clarity 17/20 · cliff 15/25 · emotion 15/15 · coherence 10/10 · duration 5/5
- Critic notes a new viewer may not understand: Why the Noblewoman wants the Duchess to suffer.

<details><summary>Clip as the viewer sees it</summary>

```
--- CUT 1: episode 24 (source 00:04.00-00:42.80) ---
[00:00.00-00:02.50] ACTION: The noblewoman halts in the center of the chamber, tapping her riding crop against her gloved palm as her cold gaze sweeps across the two maids.
[00:02.00-00:04.50] CAMERA: Medium shot of the noblewoman holding the riding crop upright, regarding Juliana with disdainful authority.
[00:02.80-00:04.40] NOBLEWOMAN (Sharp, Demanding): "Who are you?"
[00:04.50-00:08.20] CAMERA: Medium close-up of Juliana, her gaze lowered deferentially beside the carved wooden bedpost.
[00:04.50-00:08.00] LADY JULIANA (Humble, Measured): "Juliana, my lady. I was hired for the winter cleaning."
[00:08.20-00:12.80] CAMERA: Medium shot of the noblewoman, her chin tilted up in icy condescension.
[00:09.00-00:12.40] NOBLEWOMAN (Accusatory, Strict): "And who gave you permission to enter this chamber?"
[00:12.80-00:14.80] CAMERA: Close-up of the frail Dowager Duchess lying pale and unconscious against the white pillows, gasping weakly for air.
[00:14.80-00:16.50] ACTION: Behind her grey skirt, Juliana quickly slips the small glass remedy vial into her apron pocket with her charcoal-dusted fingers.
[00:14.80-00:16.80] CAMERA: Close-up on Juliana's hand swiftly concealing the medicine bottle.
[00:16.80-00:18.50] CAMERA: Medium shot of Juliana facing the noblewoman, maintaining a calm, protective facade.
[00:16.80-00:18.20] LADY JULIANA (Softly Defiant): "I heard her. I thought Her Grace needed help."
[00:18.50-00:22.80] CAMERA: Two-shot framing the noblewoman looking down at Juliana, bursting into mocking laughter.
[00:18.50-00:22.50] NOBLEWOMAN (Scoffing, Cruel): "You thought? A new maid thinks she knows better than the physicians?"
[00:22.80-00:24.80] CAMERA: Close-up of Juliana's resolute expression, her eyes flashing with righteous urgency.
[00:23.00-00:24.60] LADY JULIANA (Emphatic, Defiant): "She is suffering."
[00:24.80-00:26.80] CAMERA: Tight close-up of the noblewoman's face twisting into a malicious sneer.
[00:25.00-00:26.80] NOBLEWOMAN (Vicious, Venomous): "Then let her suffer."
[00:26.80-00:28.80] CAMERA: Close-up of Juliana recoiling slightly in shock at the blatant cruelty.
[00:27.00-00:28.50] LADY JULIANA (Steely, Steadfast): "I cannot do that."
[00:28.50-00:30.50] ACTION: The noblewoman suddenly rears back her riding crop and strikes Juliana violently across the torso.
[00:28.80-00:29.80] SFX: A sharp, stinging whip crack as the riding crop makes harsh contact.
[00:29.80-00:32.50] ACTION: Juliana gasps in pain, clutching her stomach and bending over as she absorbs the brutal strike.
[00:29.80-00:32.80] CAMERA: Medium shot of Juliana hunched over in pain, clutching her abdomen.
[00:31.00-00:32.80] NOBLEWOMAN (Cold, Threatening): "You are a maid."
[00:32.80-00:34.80] CAMERA: Low-angle shot looking past the bedpost toward the Duchess, whose trembling hand reaches out limply.
[00:33.00-00:34.80] NOBLEWOMAN (Cold, Continuing): "Not a physician. Not a lady."
[00:34.80-00:38.80] CAMERA: Dramatic low-angle wide shot of the noblewoman standing imperiously over the doubled-over Juliana.
[00:35.00-00:38.80] NOBLEWOMAN (Disdainful, Final): "And certainly not a woman whose opinion matters."
```
</details>

### 29. P029 · 77/100 · 54.4s · Low · review: needs_review

- **Cut:** E40 00:23.00–01:17.40
- **Hook:** Lady Harrington taunts: 'Imagine Juliana seeing this,' as Lord Harrington responds: 'She won't be seeing anything for long.'  
  `LADY HARRINGTON: "Imagine Juliana seeing this."`
- **Cliffhanger:** An elder conspirator smiles sinisterly: 'By sunset, Ashburgh will have its new Duke... And its witch will be dead.'  
  `ELDER NOBLEMAN: "And its witch will be dead."`
- **Why it works:** It does a great job of setting the stage for a 'triumph of evil' that the viewer desperately wants to see thwarted.
- **Rank:** Sets a 'triumph of evil' stage that necessitates a 'must-watch' follow-up to see the thwarting.
- Scores: hook 15/25 · clarity 17/20 · cliff 18/25 · emotion 13/15 · coherence 10/10 · duration 4/5
- Critic notes a new viewer may not understand: Who the Blond Nobleman is marrying.

<details><summary>Clip as the viewer sees it</summary>

```
--- CUT 1: episode 40 (source 00:23.00-01:17.40) ---
[00:00.00-00:03.20] CAMERA: Tight close-up profile of Lady Harrington, her eyes glistening with cruel satisfaction in the soft sunlight.
[00:00.20-00:03.00] LADY HARRINGTON (Malicious, Taunting): "Imagine Juliana seeing this."
[00:03.20-00:07.00] CAMERA: Tight close-up of Lord Harrington looking down at her, his expression cold and ruthless.
[00:03.20-00:05.90] LORD HARRINGTON (Sinister, Dismissive): "She won't be seeing anything for long."
[00:06.00-00:06.90] LADY HARRINGTON (Pleased, Cold): "Good."
[00:07.10-00:10.20] LORD HARRINGTON (Chuckling, Scornful): "This place has always been unlucky for Juliana."
[00:09.80-00:11.20] ACTION: Lady Harrington lets out a soft, amused laugh as they reach the heavy wooden cathedral doors.
[00:11.20-00:17.50] CAMERA: Dramatic tracking shot following Lord and Lady Harrington from behind as they stride down the candlelit aisle of the cathedral toward their reserved pew.
[00:11.40-00:16.00] LADY HARRINGTON (Vindictive, Pious): "She stands beneath God's watch and still gets exactly what she deserves."
[00:17.50-00:19.20] ACTION: Lord and Lady Harrington slide gracefully into the polished wooden pew, smoothing their garments.
[00:17.50-00:22.20] CAMERA: Medium profile shot of the couple seated in the pew, looking toward the grand altar.
[00:19.00-00:21.00] LADY HARRINGTON (Anticipatory, Eager): "We have an excellent view."
[00:21.10-00:22.20] LORD HARRINGTON (Inquiring, Subdued): "Of the wedding?"
[00:22.20-00:26.80] CAMERA: Close-up two-shot as Lady Harrington turns her head toward Lord Harrington with a dark, knowing smirk.
[00:22.30-00:25.30] LADY HARRINGTON (Chilling, Sarcastic): "And everything that comes after it."
[00:26.80-00:32.80] CAMERA: Medium shot of Rupert, the Blond Nobleman, standing before the altar draped in floral garlands. He wears an ornate silver-embroidered black formal coat and nervously adjusts his pristine white gloves.
[00:27.80-00:30.20] BLOND NOBLEMAN (Nervous, Determined): "Everything must go perfectly."
[00:30.20-00:32.80] ACTION: Rupert smooths the lapels of his coat, checking his posture as he waits for the bride.
[00:32.80-00:35.20] CAMERA: Medium shot up on the stone balcony overlooking the nave, where an elder conspirator nobleman in black gloves stands gripping a cane.
[00:35.20-00:40.80] CAMERA: High-angle wide shot looking down from the balcony across the entire cathedral filled with guests, candles lining the central aisle, and royal guards standing at attention.
[00:40.80-00:46.50] CAMERA: Medium shot on the balcony as a Royal Guard in red uniform and tall bearskin hat steps up and bows respectfully to the elder nobleman.
[00:42.00-00:43.80] ELDER NOBLEMAN (Stern, Scheming): "All entrances are covered?"
[00:43.90-00:45.20] ROYAL GUARD (Obedient, Firm): "Every one, my Lord."
[00:45.30-00:46.30] ELDER NOBLEMAN (Calculating): "Good."
[00:46.50-00:51.50] CAMERA: Over-the-shoulder shot from behind the elder nobleman, his gloved hand resting on the stone balustrade, looking down upon the altar and seated aristocrats.
[00:46.80-00:51.20] ELDER NOBLEMAN (Ruthless, Victorious): "By sunset, Ashburgh will have its new Duke and Duchess."
[00:51.50-00:54.40] CAMERA: Tight, menacing close-up on the elder nobleman's face as a cold, sinister smile spreads across his lips.
[00:51.80-00:54.40] ELDER NOBLEMAN (Deadly, Uncompromising): "And its witch will be dead."
```
</details>

### 30. P030 · 77/100 · 59.7s · Low · review: needs_review

- **Cut:** E26 00:55.80–01:55.50
- **Hook:** The Duchess tearfully realizes her own family members, Rupert and Catherine, are poisoning her.  
  `DOWAGER DUCHESS: "Rupert and Catherine want me dead. They are poisoning me in my own bed, aren't they?"`
- **Cliffhanger:** The Duchess frantically grabs Juliana's hand, demanding to know where she got the signet ring on her finger.  
  `DOWAGER DUCHESS: "Where... where... Where did you get this ring? Speak to me!"`
- **Why it works:** The 'secret princess/noble' trope is perfectly executed through a visual prop (the ring).
- **Rank:** Uses a visual prop for a classic trope reveal, making it more 'glance-able' than the more complex narratives.
- Scores: hook 15/25 · clarity 13/20 · cliff 22/25 · emotion 14/15 · coherence 10/10 · duration 3/5
- Critic notes a new viewer may not understand: How a maid would 'unwittingly' wear a signet ring if she's trying to hide her identity.

<details><summary>Clip as the viewer sees it</summary>

```
--- CUT 1: episode 26 (source 00:55.80-01:55.50) ---
[00:00.00-00:06.70] CAMERA: Medium close-up of the Duchess looking upward toward Juliana, her voice trembling with tragic certainty.
[00:00.20-00:06.20] DOWAGER DUCHESS (Trembling, Heartbroken): "Rupert and Catherine want me dead. They are poisoning me in my own bed, aren't they?"
[00:06.70-00:11.20] CAMERA: Medium shot of Juliana leaning over the edge of the mattress, nodding earnestly to soothe her fears.
[00:06.80-00:10.90] JULIANA (Reassuring, Steadfast): "Yes. But the charcoal is fighting the poison. You are safe now."
[00:11.20-00:16.00] CAMERA: Close-up of the small amber dropper bottle sitting atop the polished wooden bedside table in the dim glow of the lamp.
[00:16.00-00:23.80] CAMERA: Medium shot of the Dowager Duchess looking intently at Juliana from her pillows, studying her bearing.
[00:18.00-00:23.60] DOWAGER DUCHESS (Curious, Searching): "Then tell me... why is a girl of such noble spirit working as a common maid?"
[00:23.80-00:30.70] CAMERA: Close-up of Juliana, her chin lifting with dignified sorrow and quiet defiance.
[00:24.20-00:30.00] JULIANA (Painful, Proud): "Because my family cast me out to rot. I have nothing left in this world but my honor."
[00:30.70-00:35.00] CAMERA: Medium tracking down Juliana's apron to her hand as she rests it against the bed linens, revealing a distinctive engraved signet ring on her finger.
[00:31.20-00:34.70] ACTION: Juliana rests her right hand against the edge of the bedcover, unwittingly placing the unique ring directly within the Duchess's line of sight.
[00:34.40-00:36.20] SFX: A sharp, stunned gasp.
[00:35.00-00:39.20] CAMERA: Extreme close-up of the Dowager Duchess gasping sharply, her eyes widening in profound shock as all color drains from her face.
[00:35.00-00:39.20] ACTION: The Duchess's mouth hangs open in pure disbelief as she stares fixedly at Juliana's hand.
[00:39.20-00:44.20] CAMERA: Medium shot of the Duchess pushing herself up against the headboard, trembling as she stretches out her frail hand.
[00:40.20-00:44.00] DOWAGER DUCHESS (Breathless, Shaken): "Your hand... Let me see your hand."
[00:44.20-00:49.70] CAMERA: Close-up of Juliana reacting with confusion and growing concern at the elder woman's sudden frenzy.
[00:44.70-00:49.20] JULIANA (Confused, Alarmed): "Your Grace? What is wrong? You look as though you've seen a ghost."
[00:49.70-00:53.20] CAMERA: Close-up shot of the Duchess's withered, shaking hand reaching across the blanket toward Juliana's arm.
[00:50.20-00:53.20] ACTION: The Duchess reaches outward with trembling fingers, grasping frantically for Juliana.
[00:53.00-00:54.20] SFX: A sudden sharp rustle of fabric as her fingers snap tight.
[00:53.20-00:55.00] CAMERA: Tight shot of the Duchess's frail hand clamping down with fierce, unexpected strength onto Juliana's dark sleeve.
[00:53.40-00:54.80] DOWAGER DUCHESS (Stern, Desperate): "Do not move!"
[00:55.00-00:59.70] CAMERA: Close-up of the Dowager Duchess looking up at Juliana with overwhelming urgency and tears brimming in her wide eyes.
[00:55.20-00:59.70] DOWAGER DUCHESS (Intense, Demanding): "Where... where... Where did you get this ring? Speak to me!"
```
</details>

### 31. P031 · 77/100 · 38.2s · Low · review: recommended

- **Cut:** E15 00:44.20–01:22.40
- **Hook:** A thug snarls in Juliana's face and violently shoves her to the wet stones.  
  `THUG WITH CAP: "Get out of the way!"`
- **Cliffhanger:** The thug challenges Alexander to a fight as tension peaks on a knife's edge.  
  `THUG WITH CAP: "What? You want to fight us, veteran?"`
- **Why it works:** The 'protector' trope is well-utilized here, with a clear underdog to root for.
- **Rank:** A standard protector trope that is safe but less impactful than the high-stakes reversals above.
- Scores: hook 14/25 · clarity 16/20 · cliff 19/25 · emotion 13/15 · coherence 10/10 · duration 5/5
- Critic notes a new viewer may not understand: Why these thugs are targeting a garden specifically.

<details><summary>Clip as the viewer sees it</summary>

```
--- CUT 1: episode 15 (source 00:44.20-01:22.40) ---
[00:00.00-00:02.30] CAMERA: Tight close-up of the Thug with Cap stepping aggressively into Juliana's personal space, snarling with venom.
[00:00.60-00:02.20] THUG WITH CAP (Menacing Snarl): "Get out of the way!"
[00:02.30-00:03.80] CAMERA: Extreme close-up on Juliana's piercing blue eyes and set jaw, unflinching.
[00:02.30-00:03.10] JULIANA (Steely, Fearless): "No."
[00:03.20-00:05.30] ACTION: The Thug with Cap violently shoves Juliana back with both hands; she cries out as she loses her balance and crashes hard onto the wet stone path.
[00:03.60-00:04.80] JULIANA (Gasping Cry): "Ah!"
[00:05.30-00:09.30] CAMERA: Close-up tracking down to Juliana's hand hitting the mud next to the crushed chamomile flowers.
[00:05.80-00:09.30] ACTION: Juliana crawls forward on her elbows; fresh crimson blood seeps profusely through her white gauze bandages as she reaches for the ruined blossoms.
[00:09.30-00:12.30] CAMERA: Tight close-up on Juliana's mud-streaked, tear-stained face trembling in heartbreaking agony.
[00:09.30-00:11.50] JULIANA (Broken, Sobbing): "My mother's plants..."
[00:12.30-00:15.80] CAMERA: Low-angle wide shot of the three thugs pointing and laughing hysterically at her kneeling form.
[00:13.10-00:15.60] BALD THUG (Cruel, Laughing): "Look at her! Crying over weeds!"
[00:15.80-00:17.80] ACTION: The Tall Thug hoists his heavy wooden club above his head to crush the remaining herbs right before Juliana.
[00:15.80-00:16.80] JULIANA (Screaming): "Stop!"
[00:17.80-00:19.00] CAMERA: Medium close-up of the Thug with Cap suddenly stiffening, his smug smile dropping as footsteps pound in the darkness.
[00:19.00-00:23.30] CAMERA: Medium tracking shot as Alexander charges past the corner of the cottage into the misty moonlight, his dark coat billowing behind him.
[00:19.30-00:23.30] ACTION: Alexander storms forward with lethal intensity, dark hair flying, breath misting in the cold, radiating untamed rage.
[00:23.30-00:29.30] CAMERA: Close-up of Juliana looking up through wet lashes, trembling as shock transforms into overwhelming relief.
[00:26.30-00:28.40] JULIANA (Whispered Breath, Stunned): "Alexander..."
[00:29.30-00:31.30] CAMERA: Wide shot of the three thugs wheeling around to face the dark figure approaching from the mist.
[00:31.30-00:34.30] CAMERA: Low-angle tracking shot from behind Alexander's broad shoulders as he steadily steps past the fallen Juliana, towering over the intruders.
[00:31.80-00:34.30] ACTION: Alexander places himself directly between Juliana and the three thugs, staring them down with cold, deadly intent.
[00:34.30-00:38.20] CAMERA: Medium shot of the three thugs regrouping, the Thug with Cap feigning swagger as he grips his club.
[00:34.80-00:38.20] THUG WITH CAP (Challenging, Arrogant): "What? You want to fight us, veteran?"
```
</details>

### 32. P032 · 75/100 · 39.0s · Low · review: needs_review

- **Cut:** E44 00:24.40–01:03.40
- **Hook:** A bride in full white steps away from her arrested groom to weep before her long-lost love.  
  `CATHERINE: "Alexander... I thought you had died."`
- **Cliffhanger:** Alexander coldly rejects Catherine's romantic claims, leaving her rendered speechless.  
  `ALEXANDER: "Did you?"`
- **Why it works:** The 'returned from the dead' trope mixed with a cold rejection of a former lover is high-tier melodrama.
- **Rank:** High-tier melodrama that works well for late-stage retargeting of users who enjoy soap-opera tropes.
- Scores: hook 14/25 · clarity 18/20 · cliff 15/25 · emotion 13/15 · coherence 10/10 · duration 5/5
- Critic notes a new viewer may not understand: Why Alexander is scarred and why he is wearing a 'ducal coat' if Catherine didn't know he was alive.

<details><summary>Clip as the viewer sees it</summary>

```
--- CUT 1: episode 44 (source 00:24.40-01:03.40) ---
[00:00.00-00:03.40] CAMERA: Wide shot as Catherine gathers her heavy train and steps away from Rupert, walking toward Alexander who stands watching her stoically.
[00:00.80-00:03.60] CATHERINE (Shaken, Tearful): "Alexander... I thought you had died."
[00:03.40-00:06.80] CAMERA: Close-up on Catherine's face, tears glistening in her eyes as grief breaks through her composure.
[00:04.00-00:06.60] CATHERINE (Choked, Weeping): "Do you know what this did to me?"
[00:06.80-00:08.00] CAMERA: Medium shot on Alexander standing tall in his ducal coat, his gaze utterly detached.
[00:06.80-00:08.00] CATHERINE (O.S.) (Pleading): "I mourned you."
[00:08.00-00:09.60] CAMERA: Profile close-up of Catherine as a tear slips down her cheek.
[00:08.00-00:09.60] CATHERINE (Vulnerable, Trembling): "I waited for you."
[00:09.60-00:11.40] CAMERA: Medium shot of Catherine standing in the center of the aisle before the seated congregation.
[00:09.80-00:14.40] CATHERINE (Heartbroken): "For three years, I believed the man I loved was buried somewhere across the sea."
[00:11.40-00:14.40] CAMERA: Tracking two-shot over Alexander's shoulder as Catherine approaches him pleadingly.
[00:14.40-00:16.80] CAMERA: Close profile two-shot as Catherine gently reaches her gloved hand up to Alexander's bearded cheek.
[00:14.50-00:16.80] CATHERINE (Whispering, Longing): "I never stopped loving you."
[00:16.80-00:18.40] ACTION: Alexander abruptly pulls his face back, refusing her touch and leaving her hand suspended in mid-air.
[00:16.80-00:18.40] CAMERA: Close-up on Catherine's empty gloved hand trembling in the empty space between them.
[00:18.40-00:22.00] CAMERA: Close-up on Catherine lowering her hand, stunned and deeply hurt by his rejection.
[00:19.80-00:22.00] CATHERINE (Breathless, Hurt): "You don't remember?"
[00:22.00-00:24.60] CAMERA: High-angle shot looking down at Catherine in the foreground, with Rupert held under guard in the background.
[00:22.20-00:24.40] CATHERINE (Desperate, Demanding): "I was supposed to be your Duchess!"
[00:24.60-00:26.60] CAMERA: Medium two-shot of Catherine and Alexander confronting each other.
[00:24.80-00:26.60] ALEXANDER (Cold, Implacable): "You were never my Duchess."
[00:26.60-00:28.60] CAMERA: Extreme close-up on Catherine's tearful face.
[00:26.70-00:28.40] CATHERINE (Sobbing, Pleading): "But I loved you!"
[00:28.60-00:31.20] CAMERA: Medium close-up on Alexander, his scarred jaw set firm.
[00:28.60-00:31.10] ALEXANDER (Scornful, Biting): "You loved the Duke you thought you would marry."
[00:31.20-00:34.60] CAMERA: Close-up on Catherine, gasping in protest.
[00:31.80-00:33.80] CATHERINE (Defiant, Pained): "No!"
[00:34.60-00:38.00] CAMERA: Medium shot as Catherine clutches her chest, pouring her heart out.
[00:35.40-00:38.00] CATHERINE (Passionate, Crying): "I loved you before all this!"
[00:38.00-00:39.00] CAMERA: Close-up on Alexander tilting his head slightly, his gaze piercing through her.
[00:38.10-00:39.00] ALEXANDER (Skeptical, Cutting): "Did you?"
```
</details>

### 33. P033 · 75/100 · 52.5s · Low · review: needs_review

- **Cut:** E33 00:59.00–01:51.50
- **Hook:** A dark lord threatens a young maid: 'Your brother is still a pauper. One word from me, and the county gaol will take him before sunrise.'  
  `LORD: "Think carefully."`
- **Cliffhanger:** The Lord sinisterly traps the weeping maid into twisting a prayer into a witchcraft chant.  
  `LORD: "Praying... or chanting?"`
- **Why it works:** The 'insidious villain' archetype is very effective here, showing exactly how the trap is built.
- **Rank:** Slow-burn villainous trap building that appeals to users looking for more complex storytelling.
- Scores: hook 14/25 · clarity 15/20 · cliff 18/25 · emotion 14/15 · coherence 10/10 · duration 4/5
- Critic notes a new viewer may not understand: What the maid's brother actually did to be a 'pauper' or in trouble.

<details><summary>Clip as the viewer sees it</summary>

```
--- CUT 1: episode 33 (source 00:59.00-01:51.50) ---
[00:00.00-00:05.20] CAMERA: Profile medium two-shot as the Lord looms inches from the maid's face.
[00:00.00-00:02.00] LORD (Low, Menacing): "Think carefully."
[00:02.20-00:04.50] LORD (Ruthless): "Your brother is still a pauper."
[00:05.20-00:09.80] CAMERA: Extreme close-up of the Lord's cold eyes and hawkish profile speaking with chilling finality.
[00:05.40-00:09.50] LORD (Threatening): "One word from me, and the county gaol will take him before sunrise."
[00:09.50-00:11.00] ACTION: The maid gasps in sheer terror, her chest heaving as tears stream.
[00:09.80-00:14.20] CAMERA: Close-up of the maid clutching her chest with trembling hands, crying desperately.
[00:10.50-00:14.00] MAID (Begging, Heartbroken): "Please, my Lord... he is only seven!"
[00:14.20-00:16.50] CAMERA: Close-up of the Lord staring down without an ounce of pity.
[00:14.20-00:16.00] LORD (Cold, Unwavering): "Then help him."
[00:16.50-00:20.50] CAMERA: Close-up of the maid weeping profusely, cornered and helpless.
[00:17.80-00:20.00] MAID (Crying, Shattered): "What do you want me to say?!"
[00:20.50-00:25.80] CAMERA: Wide shot of the study as the Lord stands calmly before the trembling servant.
[00:20.60-00:21.50] LORD (Deceptive): "The truth."
[00:22.00-00:25.50] LORD (Leading, Deliberate): "She drew something around the bed, did she not?"
[00:25.80-00:30.00] CAMERA: Close-up of the maid stammering through her tears.
[00:26.50-00:29.80] MAID (Trembling, Reluctant): "She... placed dried herbs around him."
[00:30.00-00:35.80] CAMERA: Medium close-up of the Lord standing right beside her shoulder, whispering in her ear like an insidious specter.
[00:30.00-00:31.50] LORD (Hypnotic, Coercive): "Around him."
[00:32.00-00:33.50] LORD (Coercive): "Like a circle?"
[00:34.00-00:35.50] MAID (Faint, Defeated): "Yes."
[00:35.80-00:39.50] CAMERA: Close-up from behind the maid as the Lord leans close to her ear.
[00:36.00-00:39.00] LORD (Whispering, Trap Snapping): "And she opened her mother's book..."
[00:39.50-00:41.80] CAMERA: Extreme close-up of the maid's tear-drenched eyes and quivering lips.
[00:39.50-00:41.00] MAID (Sobbing): "Yes."
[00:41.80-00:45.20] CAMERA: Close-up of the Lord delivering the final trap.
[00:42.00-00:45.00] LORD (Sinister): "...and spoke words you could not understand."
[00:45.20-00:48.50] CAMERA: Close-up of the maid gasping out in desperate agony.
[00:45.50-00:47.50] MAID (Desperately Defending): "She was praying!"
[00:48.50-00:52.50] CAMERA: Close-up of the Lord grinning with sinister triumph.
[00:49.00-00:52.50] LORD (Taunting): "Praying... or chanting?"
```
</details>

### 34. P034 · 74/100 · 34.5s · Low · review: needs_review

- **Cut:** E39 00:32.40–01:06.90
- **Hook:** A driver suddenly lunges off a cart, violently tackling a royal sentry against a carriage wheel.  
  `CAMERA: Fast dynamic medium shot as the cart driver suddenly lunges off the wooden bench.`
- **Cliffhanger:** Alexander looks at his groomed face in the mirror, stating: 'Today, he comes home.'  
  `ALEXANDER: "Today, he comes home."`
- **Why it works:** The 'hero grooming himself for a transformation' montage is a very satisfying trope that promises a big payoff.
- **Rank:** A transformation montage that promises payoff, though its low clarity places it near the bottom.
- Scores: hook 23/25 · clarity 12/20 · cliff 14/25 · emotion 11/15 · coherence 9/10 · duration 5/5
- Critic warnings (flag raised, but the matching score is still acceptable): critic flagged missing context but scored standalone_clarity 12/20
- Critic notes a new viewer may not understand: Who the 'Duke' is and why he was hiding for three years.

<details><summary>Clip as the viewer sees it</summary>

```
--- CUT 1: episode 39 (source 00:32.40-01:06.90) ---
[00:00.00-00:04.10] CAMERA: Fast dynamic medium shot as the cart driver suddenly lunges off the wooden bench.
[00:00.40-00:04.10] ACTION: The driver leaps off the cart, striking the sentry across the chest, seizing his neck, and tackling him violently against the wooden carriage wheel.
[00:00.70-00:03.60] SFX: Dull physical thuds and scuffling boots on wet stone as the guard groans in surprise.
[00:04.10-00:10.40] CAMERA: Medium close-up as a second loyalist emerges from behind the doorway, wrapping his arms around the remaining royal guard's throat from behind.
[00:04.60-00:10.10] ACTION: The loyalist locks the sentry into a tight sleeper hold, clamping a hand firmly over his mouth until his eyes roll back and he goes limp.
[00:08.60-00:09.80] LOYALIST FIGHTER (Whispering, Cold): "Sleep."
[00:10.40-00:14.40] CAMERA: Wide high-angle shot overlooking the stone cathedral steps where both royal guards lie unconscious on the fallen autumn leaves while more men slip inside the opened doors.
[00:14.40-00:17.60] CAMERA: Medium low-angle shot of the two loyalist fighters looking up into the overcast sky outside the stone sanctuary.
[00:14.60-00:15.70] CART DRIVER (Relieved, Firm): "The road is clear."
[00:15.80-00:16.80] LOYALIST FIGHTER (Resolute): "Tell the Duke."
[00:17.60-00:20.40] CAMERA: Close-up framed into a cracked wooden wall mirror reflecting Alexander with long unkempt hair, a thick beard, and combat scars across his cheek.
[00:17.60-00:20.40] ACTION: Alexander stares solemnly at his rugged reflection, his expression dark and resolute.
[00:20.40-00:23.40] CAMERA: Tilt-down medium close-up over a wooden table displaying a pristine navy-and-gold embroidered ducal uniform, ornate lion crest brooch, white cravat, razor, and scissors.
[00:23.40-00:27.40] CAMERA: Medium profile shot of Alexander lifting the metal shears beside the window light, raising them toward his hair.
[00:24.10-00:27.40] ACTION: Alexander snips through his overgrown locks, shedding the years of exile and camouflage.
[00:24.80-00:28.40] SFX: Rhythmic, metallic snips of heavy shears cutting through thick hair.
[00:27.40-00:28.80] CAMERA: Medium shot as Alexander trims his beard at the jawline.
[00:28.80-00:34.20] CAMERA: Medium shot framed in the mirror of Alexander now handsomely groomed, his trimmed beard framing his fierce, scarred features.
[00:29.60-00:34.20] ACTION: Alexander lightly traces the jagged combat scar across his cheek, eyes burning with reclaimed power.
[00:29.60-00:30.40] ALEXANDER (Deep, Steely Resolve): "Enough hiding."
[00:30.60-00:33.10] ALEXANDER (Dark, Unforgiving): "They buried Alexander Ashwin three years ago."
[00:33.20-00:34.50] ALEXANDER (Fierce, Commanding): "Today, he comes home."
[00:34.20-00:34.50] CAMERA: Medium shot of Alexander lifting his royal navy-blue embroidered ducal coat from the wooden bench.
```
</details>

### 35. P035 · 73/100 · 30.0s · Low · review: needs_review

- **Cut:** E1 01:47.50–02:17.50
- **Hook:** Vicious insult: 'You are the daughter people tolerate because they have to.'  
  `LADY IN GOLD GOWN: "You are the daughter people tolerate because they have to."`
- **Cliffhanger:** Solemn low-pitched string drone swells as Juliana's expression hardens from grief to cold, resolute defiance.  
  `SFX: Solemn low-pitched string drone swells to an ominous cliffhanger peak.`
- **Why it works:** The 'underdog' transformation at the end makes the viewer want to see the protagonist strike back.
- **Rank:** An episode 1 promo with a clear underdog transformation that builds foundational brand affinity better than mid-story clips.
- Scores: hook 15/25 · clarity 14/20 · cliff 16/25 · emotion 13/15 · coherence 10/10 · duration 5/5
- Critic notes a new viewer may not understand: Who the 'Matriarch' is in relation to the family.; The 'county' setting context.

<details><summary>Clip as the viewer sees it</summary>

```
--- CUT 1: episode 1 (source 01:47.50-02:17.50) ---
[00:00.00-00:03.30] LADY IN GOLD GOWN (Viciously Calm): "You are the daughter people tolerate because they have to."
[00:02.50-00:05.50] CAMERA: Close-up on Juliana absorbing the venomous words, her breathing shallow.
[00:03.60-00:05.50] LADY IN GOLD GOWN (Gloating): "I am the daughter they choose."
[00:05.50-00:07.70] CAMERA: Medium shot of the Lady in Gold Gown smiling warmly at Gerald beside the altar candles.
[00:05.80-00:08.20] MATRIARCH (O.S.) (Firm): "Clarissa is the jewel of this family."
[00:07.70-00:09.50] CAMERA: Close two-shot of the Matriarch and Juliana standing side by side in profile.
[00:09.50-00:12.00] CAMERA: Medium shot framing Juliana looking directly at Gerald, who towers over her coldly.
[00:09.50-00:11.50] LADY JULIANA (Trembling, Dignified): "So that is what I was worth to you?"
[00:12.00-00:15.00] CAMERA: Close-up on Gerald's sharp jawline as he looks down at her without an ounce of remorse.
[00:12.30-00:14.80] THE FORMER GROOM (Scornful, Hard): "You have nothing to offer me anymore."
[00:15.00-00:16.70] CAMERA: Extreme close-up on Juliana's eye as a single tear rolls down her cheek.
[00:16.70-00:21.00] CAMERA: Full shot tracking Gerald as he turns his back on Juliana and walks back toward Clarissa and the altar.
[00:16.70-00:20.00] THE FORMER GROOM (Arrogant, Dismissive): "I cannot marry a woman of such plainness and low value..."
[00:21.00-00:23.80] CAMERA: Close-up on Clarissa's radiant, conceited smile basking in Gerald's words.
[00:21.00-00:23.70] THE FORMER GROOM (Reverent toward Clarissa): "...when Clarissa is the true jewel of the county."
[00:23.80-00:26.30] ACTION: Juliana's hand clenches fiercely into the folds of her mother's silk bridal gown, knuckles whitening with suppressed fury.
[00:23.80-00:26.30] CAMERA: Tight insert on Juliana's white-knuckled hand clutching the gown fabric.
[00:26.30-00:29.50] CAMERA: Push-in close-up on Juliana's tearful face. Her trembling mouth straightens, her tear-filled blue eyes hardening from sheer devastation into cold, resolute defiance.
[00:26.30-00:29.50] ACTION: Juliana breathes through the agony, refusing to break down further in front of the congregation.
[00:27.50-00:30.00] SFX: Solemn low-pitched string drone swells to an ominous cliffhanger peak.
```
</details>

### 36. P036 · 73/100 · 36.5s · Low · review: needs_review

- **Cut:** E35 01:53.50–02:30.00
- **Hook:** A scarred warrior reveals: 'I crawled away from the battlefield, half dead, alone. I survived because the men who came looking for me believed I was already dead.'  
  `ALEXANDER: "I crawled away from the battlefield, half dead, alone."`
- **Cliffhanger:** Alexander chillingly reveals: 'The men behind it... are the same men ruling Ashwood now,' leaving his mother in soundless dread.  
  `ALEXANDER: "The men behind it... are the same men ruling Ashwood now."`
- **Why it works:** It promises a 'count of monte cristo' style revenge arc.
- **Rank:** A classic revenge arc promise that, while low-scoring, provides a familiar narrative structure.
- Scores: hook 14/25 · clarity 13/20 · cliff 19/25 · emotion 12/15 · coherence 10/10 · duration 5/5
- Critic warnings (flag raised, but the matching score is still acceptable): critic flagged missing context but scored standalone_clarity 13/20
- Critic notes a new viewer may not understand: Who is ruling Ashwood.; Where Alexander has been for three years.

<details><summary>Clip as the viewer sees it</summary>

```
--- CUT 1: episode 35 (source 01:53.50-02:30.00) ---
[00:00.00-00:04.50] CAMERA: Close-up on Alexander, his eyes dark with the harrowing memory.
[00:00.50-00:04.50] ALEXANDER (Somber, Low): "I crawled away from the battlefield, half dead, alone."
[00:04.70-00:08.50] ALEXANDER (Continuing): "I survived because the men who came looking for me believed I was already dead."
[00:08.50-00:12.00] CAMERA: Close-up on his mother as her expression shifts to profound bewilderment and outrage.
[00:08.50-00:12.00] ALEXANDER'S MOTHER (Aghast, Stunned): "Then why did they never tell us?"
[00:12.00-00:16.00] CAMERA: Close-up on Alexander's intense, piercing gaze.
[00:12.50-00:16.00] ALEXANDER (Ominous, Deliberate): "Because someone wanted you to believe I was dead."
[00:16.00-00:17.00] ALEXANDER'S MOTHER (Breathless): "Who?"
[00:17.00-00:20.50] ACTION: Alexander turns away toward the frosted window, staring out into the dark raging blizzard outside.
[00:17.50-00:20.50] ALEXANDER (Brooding): "I spent three years trying to find out."
[00:20.50-00:23.30] ACTION: Alexander abruptly pushes away from the window, storming back toward the table with burning rage.
[00:20.50-00:23.50] ALEXANDER (Fierce, Resolute): "The ambush was not an accident."
[00:23.50-00:30.50] ACTION: He leans heavily over the wooden table, looming close as his fury boils over.
[00:23.50-00:27.00] ALEXANDER (Vehement, Enraged): "Someone ordered my men to die."
[00:27.50-00:30.50] ALEXANDER (Darkly Intimating): "Someone wanted me erased."
[00:30.50-00:31.50] ALEXANDER'S MOTHER (Gasping, Terrified): "Who?"
[00:31.50-00:36.50] CAMERA: Tight close-up on Alexander's scarred, grim visage, his voice dropping to a deadly chill.
[00:32.00-00:36.50] ALEXANDER (Deadly, Chilling): "The men behind it... are the same men ruling Ashwood now."
```
</details>

### 37. P037 · 72/100 · 59.0s · Low · review: needs_review

- **Cut:** E18 00:56.50–01:55.50
- **Hook:** Juliana screams hysterically and breaks away toward a collapsing, burning desk.  
  `JULIANA: "No! No!"`
- **Cliffhanger:** Alexander dives through a burning glass window frame carrying Juliana into the dark night.  
  `ACTION: Alexander leaps forward, using his shoulder and back to shatter through the burning window frame, carrying Juliana safely in his arms out into the night`
- **Why it works:** Intense action, a heroic rescue, and a clear 'MacGuffin' (the ledger).
- **Rank:** Action-oriented with a clear MacGuffin, serving as a functional filler for high-volume days.
- Scores: hook 15/25 · clarity 15/20 · cliff 15/25 · emotion 14/15 · coherence 10/10 · duration 3/5
- Critic warnings (flag raised, but the matching score is still acceptable): critic flagged predictable/resolved ending but scored cliffhanger_strength 15/25
- Critic notes a new viewer may not understand: Why the ledger is so important that she'd risk death.

<details><summary>Clip as the viewer sees it</summary>

```
--- CUT 1: episode 18 (source 00:56.50-01:55.50) ---
[00:00.00-00:01.30] JULIANA (Frantic, Desperate): "The ledger!"
[00:01.30-00:03.50] ACTION: Alexander firmly grips her arm, pulling her back toward safety.
[00:01.50-00:02.70] ALEXANDER (Stern, Shouting): "Leave it!"
[00:02.80-00:06.00] JULIANA (Hysterical, Screaming): "No! No!"
[00:06.50-00:09.00] CAMERA: Low-angle shot pointing up at the ceiling beams overhead, engulfed in roaring fire and splitting down the center.
[00:09.00-00:11.50] ACTION: Alexander points upward with urgency, pulling her under his arm.
[00:09.30-00:11.50] ALEXANDER (Loud, Alarmed): "Juliana, the ceiling is coming down!"
[00:11.50-00:14.00] ACTION: Juliana wrests her hand from his grasp and charges straight toward the burning desk.
[00:14.00-00:17.00] CAMERA: Wide shot of the room as a massive burning crossbeam collapses into the floorboards with a fiery explosion.
[00:17.00-00:19.00] ALEXANDER (Roaring in Terror): "Juliana!"
[00:18.50-00:20.30] JULIANA (Defiant, Weeping): "It's my mother's!"
[00:20.30-00:25.00] ACTION: Juliana snatches the scorched leather ledger from the burning table, pulling it tightly against her chest with both bandaged hands.
[00:25.00-00:27.00] CAMERA: Close-up of the ceiling rafter splitting violently apart above her.
[00:27.00-00:30.00] CAMERA: Close-up of Juliana looking up in sheer terror, firelight dancing across her tearful face.
[00:27.50-00:29.70] JULIANA (Screaming, Blood-Curdling): "Alexander!"
[00:30.00-00:33.00] ACTION: Alexander lunges across the room, tackling her to the wooden floor and covering her body entirely with his own.
[00:30.00-00:31.00] ALEXANDER (Screaming Command): "Down!"
[00:31.30-00:33.50] SFX: Massive wooden beam crashes directly where Juliana had been standing, showering them in sparks.
[00:33.00-00:37.50] CAMERA: Ground-level shot of Alexander lying on top of Juliana, his chest shielding her, his face smeared with soot.
[00:35.00-00:41.50] ACTION: Alexander lifts his head slightly, checking her face and cradling her cheek tenderly.
[00:40.00-00:41.70] ALEXANDER (Panting, Reassuring): "I've got you."
[00:42.00-00:45.00] CAMERA: Wide shot of the walls collapsing in curtains of flame, cutting off all interior hallways.
[00:45.00-00:48.00] ACTION: Alexander scoops Juliana up in his arms, carrying her bridal-style as she clutches the ledger.
[00:47.00-00:49.00] ACTION: Juliana looks toward the side wall and points frantically at the parlor window.
[00:47.30-00:48.50] JULIANA (Urgent, Shouting): "The window!"
[00:48.70-00:50.30] ALEXANDER (Steely, Determined): "Hold on to me."
[00:50.30-00:53.00] CAMERA: Medium close-up of Alexander gritting his teeth, holding Juliana securely as she buries her face into his neck.
[00:53.00-00:57.50] CAMERA: Slow-motion shot as Alexander sprints through the burning room toward the framed glass window.
[00:55.00-00:59.00] ACTION: Alexander leaps forward, using his shoulder and back to shatter through the burning window frame, carrying Juliana safely in his arms out into the night.
```
</details>

### 38. P038 · 81/100 · 39.4s · Low · review: needs_review

- **Cut:** E1 00:39.10–01:18.50
- **Hook:** Lady in Gold Gown smugly gloats: 'Because he is marrying me.'  
  `LADY IN GOLD GOWN: "Because he is marrying me."`
- **Cliffhanger:** Sister delivers the ultimate cruel blow: 'Long enough to know he was never going to marry you.'  
  `LADY IN GOLD GOWN: "Long enough to know he was never going to marry you."`
- **Why it works:** Universal themes of betrayal and wedding-day disaster are highly clickable and emotionally resonant.
- **Rank:** Despite a lower total score, it focuses on episode 1 with universal betrayal themes, making it the ideal safe entry point to the platform.
- Scores: hook 22/25 · clarity 18/20 · cliff 12/25 · emotion 14/15 · coherence 10/10 · duration 5/5
- Critic notes a new viewer may not understand: The specific identity of the 'Lady in Gold Gown' as her sister is only implied by context clues like 'sister'.

<details><summary>Clip as the viewer sees it</summary>

```
--- CUT 1: episode 1 (source 00:39.10-01:18.50) ---
[00:00.00-00:02.10] LADY IN GOLD GOWN (Gloating, Smug): "Because he is marrying me."
[00:02.40-00:04.80] CAMERA: Close-up on Juliana as tears spill over her eyelashes.
[00:02.60-00:04.00] LADY JULIANA (Gasping, Devastated): "No..."
[00:04.80-00:07.70] CAMERA: Wide profile shot showing Juliana standing below the altar platform, looking up at Gerald and her sister.
[00:07.70-00:11.30] CAMERA: Close-up on Juliana clutching her chest, her sorrow turning into burning outrage.
[00:07.70-00:10.90] LADY JULIANA (Outraged, Accusing): "You knew this before I walked through those doors!"
[00:11.30-00:12.90] CAMERA: Medium shot of Gerald standing stoic and impassive next to the smug Lady in Gold Gown.
[00:12.90-00:15.50] CAMERA: Close-up on Juliana's hands desperately clenching fistfuls of her white dress fabric.
[00:13.70-00:15.50] LADY JULIANA (Choking on Tears): "You let me come here..."
[00:15.50-00:18.50] CAMERA: Close-up on Juliana's tear-streaked face as she shakes with grief.
[00:15.60-00:17.80] LADY JULIANA (Crushed, Shaking): "You let me dress in my mother's gown..."
[00:17.90-00:20.90] LADY JULIANA (Crying Out): "You let me believe I was walking toward my husband!"
[00:18.50-00:21.00] CAMERA: Medium shot on Gerald stepping forward, cold and indifferent, with the Lady in Gold Gown lingering in soft focus behind him.
[00:21.00-00:23.90] CAMERA: Tight close-up on Gerald's hardened profile as he glances down.
[00:21.00-00:22.70] THE FORMER GROOM (Cold, Callous): "I changed my mind."
[00:23.90-00:26.90] CAMERA: Extreme close-up on Juliana's furious, weeping face.
[00:24.30-00:26.50] LADY JULIANA (Betrayed, Piercing): "You swore you loved me!"
[00:26.90-00:29.70] CAMERA: Close-up on the Lady in Gold Gown smiling condescendingly.
[00:27.40-00:29.70] LADY IN GOLD GOWN (Mocking): "People change their minds, sister."
[00:29.70-00:33.30] CAMERA: Medium profile shot of the Lady in Gold Gown turning her head subtly toward Gerald with satisfied malice.
[00:30.00-00:31.30] LADY JULIANA (Horrified): "And you knew?"
[00:31.50-00:33.00] LADY IN GOLD GOWN (Unapologetic, Cheerful): "Of course I knew."
[00:33.30-00:35.50] CAMERA: Close-up on Juliana, stunned by the callous depth of the conspiracy.
[00:34.00-00:35.20] LADY JULIANA (Trembling): "How long?"
[00:35.50-00:39.40] CAMERA: Medium two-shot of the Lady in Gold Gown and Gerald looking together down at Juliana.
[00:35.90-00:39.40] LADY IN GOLD GOWN (Cruel, Poised): "Long enough to know he was never going to marry you."
```
</details>

### 39. P039 · 81/100 · 41.5s · Low · review: needs_review

- **Cut:** E28 01:35.20–02:16.70
- **Hook:** Catherine reads the stolen journal and triumphantly exposes Juliana's true noble identity.  
  `CATHERINE: "Lady Juliana Ashcroft."`
- **Cliffhanger:** Catherine promises to use the medicinal ledger to hang Juliana at the gallows.  
  `CATHERINE: "...before he sends you to the gallows."`
- **Why it works:** The 'secret identity' reveal combined with the threat of execution is a very effective hook for a serial.
- **Rank:** Strong secret identity reveal that rewards users who have already engaged with the platform's rhythm.
- Scores: hook 12/25 · clarity 16/20 · cliff 23/25 · emotion 15/15 · coherence 10/10 · duration 5/5
- Critic notes a new viewer may not understand: Why exactly she was disgraced previously.

<details><summary>Clip as the viewer sees it</summary>

```
--- CUT 1: episode 28 (source 01:35.20-02:16.70) ---
[00:00.00-00:01.80] ACTION: Juliana gasps in horror, realizing her secret identity has been laid bare.
[00:02.20-00:06.00] CAMERA: Close-up of Catherine raising her gaze slowly from the book, a wicked, triumphant grin spreading across her face.
[00:03.00-00:05.60] CATHERINE (Triumphant, Venomous): "Lady Juliana Ashcroft."
[00:06.00-00:12.60] CAMERA: Medium two-shot as Catherine steps deliberately up to Juliana, circling her like a predator savoring its prey.
[00:06.30-00:08.50] CATHERINE (Mocking, Reveling): "I knew I had seen those eyes before."
[00:09.00-00:10.40] CATHERINE (Cruel): "The disgraced daughter..."
[00:10.40-00:12.60] CATHERINE (Scornful): "...the girl thrown out of her own family home."
[00:12.60-00:17.80] CAMERA: Close-up two-shot of Catherine leaning inches from Juliana's face, whispering her humiliating past.
[00:12.90-00:15.80] CATHERINE (Taunting): "The bride who married a penniless war veteran..."
[00:15.90-00:17.80] CATHERINE (Vicious): "...because no respectable man would have her."
[00:17.80-00:21.20] CAMERA: Tight close-up of Juliana's eyes blazing with explosive fury and defensive loyalty.
[00:18.10-00:20.60] JULIANA (Screaming, Wildly Defiant): "Do not speak about my husband!"
[00:21.20-00:26.80] CAMERA: Medium two-shot as Catherine throws her head back in derisive laughter, brandishing the herbarium book.
[00:21.20-00:23.90] CATHERINE (Laughing, Scornful): "And look at you now. Scrubbing fireplaces in my house."
[00:24.00-00:26.60] CATHERINE (Mocking): "What a magnificent fall, Lady Juliana."
[00:26.80-00:29.70] CAMERA: Medium shot of Rupert gesturing toward the exit with an outstretched arm.
[00:26.80-00:29.50] BLOND NOBLEMAN (Harsh, Authoritative): "Drag her to the wet cells beneath the south tower."
[00:29.70-00:33.60] CAMERA: Close-up of Catherine fanning open the illustrated botanical pages of the herbarium with gloved fingers.
[00:29.80-00:30.50] CATHERINE (Smug): "And this?"
[00:30.70-00:33.50] CATHERINE (Gleeful): "This book of weeds will hang her before the magistrate."
[00:33.60-00:36.00] CAMERA: Medium shot of Juliana thrashing frantically against the guard's grip, her arm reaching out toward the book.
[00:33.90-00:35.80] JULIANA (Screaming, Desperate): "That book is my mother's life's work!"
[00:36.00-00:41.50] CAMERA: Medium close-up of Catherine smiling coldly, clutching the closed book against her bodice.
[00:36.20-00:39.00] CATHERINE (Icy, Threatening): "Then perhaps you can explain every page to the magistrate..."
[00:39.40-00:41.50] CATHERINE (Fateful, Vengeful): "...before he sends you to the gallows."
```
</details>

### 40. P040 · 78/100 · 36.9s · Low · review: needs_review

- **Cut:** E21 00:03.50–00:40.40
- **Hook:** Prudence slams open the barn doors, weeping desperately that Toby is dying.  
  `PRUDENCE: "Lady Juliana! Please! You have to help me, Toby is dying!"`
- **Cliffhanger:** Juliana firmly refuses to let Prudence kneel and takes command, taking her ledger to rush out into the emergency.  
  `LADY JULIANA: "Stand up. Sinking to your knees will not save him. Let me grab my ledger. We go now."`
- **Why it works:** High-stakes medical urgency combined with class conflict creates an immediate emotional hook.
- **Rank:** High clarity and a medical urgency hook provide a different emotional flavor (class conflict) compared to the preceding action clips.
- Scores: hook 20/25 · clarity 18/20 · cliff 12/25 · emotion 13/15 · coherence 10/10 · duration 5/5
- Critic notes a new viewer may not understand: Why Juliana's cottage was burned to 'ashes' previously.

<details><summary>Clip as the viewer sees it</summary>

```
--- CUT 1: episode 21 (source 00:03.50-00:40.40) ---
[00:00.00-00:01.30] SFX: A loud wooden slam as the heavy double barn doors violently fly open.
[00:00.10-00:05.00] CAMERA: Wide shot framing the open doorway against the overcast daylight as Prudence, a young village girl in an apron, rushes inside, frantic and weeping.
[00:00.70-00:04.50] PRUDENCE (Desperate, Panicked): "Lady Juliana! Please! You have to help me, Toby is dying!"
[00:04.70-00:07.00] ACTION: Lady Juliana hurries over, placing her bandaged hands reassuringly on Prudence's trembling shoulders.
[00:05.00-00:07.70] CAMERA: Medium close-up of Lady Juliana looking into Prudence's tearful face with compassionate urgency.
[00:05.00-00:07.50] LADY JULIANA (Gentle, Urgent): "Oh dear. Breathe. Tell me what has happened."
[00:07.70-00:11.60] CAMERA: Close-up of Prudence weeping, clutching her hands to her chest in agony.
[00:07.70-00:11.50] PRUDENCE (Sobbing, Breathless): "My little brother Toby... his chest is burning! He cannot breathe!"
[00:11.50-00:14.70] LADY JULIANA (Inquiring, Strained): "Tell me what the apothecary said. Did he not give you medicine?"
[00:11.60-00:14.70] CAMERA: Close-up of Lady Juliana, her brow furrowing with concern.
[00:14.70-00:18.30] CAMERA: Close-up of Prudence, her face twisted in bitter anguish as she gestures back toward the rain-soaked outdoors.
[00:14.70-00:18.20] PRUDENCE (Anguished, Resentful): "He shut the door in my face because we have no silver!"
[00:18.30-00:21.50] CAMERA: Wide shot of Lady Juliana and Prudence facing each other inside the wooden barn, dust motes drifting in the pale light.
[00:18.30-00:21.80] PRUDENCE (Bitter, Tearful): "The manor doctor laughed! He said village boys are not worth his time!"
[00:21.50-00:27.40] CAMERA: Medium profile shot of Lady Juliana looking down at her bandaged hands, holding Prudence's hand with somber heartache.
[00:21.60-00:23.90] LADY JULIANA (Sorrowful, Dejected): "We have no clinic now."
[00:24.00-00:27.30] LADY JULIANA (Despondent): "Our cottage is ashes. I have nothing left but this coltsfoot."
[00:27.50-00:29.50] ACTION: Prudence drops desperately to her knees onto the hay-strewn barn floor, clasping her hands in tearful supplication.
[00:27.50-00:32.30] PRUDENCE (Pleading, Desperate): "He is only seven! If you do not come, he will die! You are his only hope, Lady Juliana!"
[00:27.60-00:32.30] CAMERA: High-angle looking down at Prudence kneeling before Lady Juliana, pleading upward.
[00:32.30-00:36.00] ACTION: Lady Juliana immediately reaches down and pulls Prudence firmly back to her feet, then turns to snatch her heavy leather-bound herbal ledger from the wooden workbench.
[00:32.40-00:36.90] CAMERA: Medium shot framing the barn entrance as Lady Juliana lifts Prudence up, grabs her book, and leads the way out.
[00:32.40-00:36.90] LADY JULIANA (Resolute, Authoritative): "Stand up. Sinking to your knees will not save him. Let me grab my ledger. We go now."
```
</details>

### 41. P041 · 77/100 · 44.5s · Low · review: needs_review

- **Cut:** E13 01:07.50–01:52.00
- **Hook:** Macro shot of a massive thorn stabbing into Juliana's bleeding hand with a sickening crunch.  
  `SFX: Sickening crunch and scrape of thorns slicing through flesh.`
- **Cliffhanger:** Juliana reaches out her torn, bloodied hand and wraps her fingers tightly around the emerald ring.  
  `ACTION: Juliana reaches out her torn, bloodied hand and wraps her fingers tightly around the emerald ring.`
- **Why it works:** High physical stakes and emotional agony create a very intense, albeit confusing, scene.
- **Rank:** High physical stakes maintain interest despite lower clarity scores compared to the rest of the pack.
- Scores: hook 18/25 · clarity 11/20 · cliff 18/25 · emotion 15/15 · coherence 10/10 · duration 5/5
- Critic notes a new viewer may not understand: Why she is doing this to herself and why the guard is letting her be mutilated but holding the man back.

<details><summary>Clip as the viewer sees it</summary>

```
--- CUT 1: episode 13 (source 01:07.50-01:52.00) ---
[00:00.00-00:03.70] CAMERA: Macro close-up of a massive blackthorn needle stabbing deep into the back of Juliana's bleeding hand.
[00:01.00-00:02.70] SFX: Sickening crunch and scrape of thorns slicing through flesh.
[00:03.70-00:06.50] CAMERA: Close-up of Alexander struggling in agony, tears forming in his eyes.
[00:03.90-00:06.30] ALEXANDER (Desperate, Choked): "Please... enough!"
[00:06.50-00:10.50] CAMERA: Wide tunnel shot through the briars as Juliana crawls deeper into the dark, frozen tangle.
[00:07.00-00:10.50] ACTION: Juliana drags her body across the frozen, cracked soil beneath the dense roof of briars.
[00:10.50-00:13.00] CAMERA: Close-up of Juliana's hand getting snagged between two vicious thorns, tearing her sleeve and flesh.
[00:11.00-00:13.00] JULIANA (Screaming in Pain): "Ah!"
[00:13.00-00:15.50] ACTION: Alexander loses control, violently lunging past the Constable toward the briars.
[00:13.00-00:15.50] CAMERA: Medium tracking shot of Alexander breaking into a desperate charge.
[00:13.30-00:14.70] ALEXANDER (Furious, Booming): "Stop!"
[00:15.50-00:18.50] ACTION: Juliana continues clawing forward, branches lacerating her arm and cheek.
[00:15.50-00:18.50] CAMERA: Close-up of Juliana wincing in agony and screaming through clenched teeth.
[00:16.30-00:18.30] JULIANA (Agonized Scream): "Ahhh!"
[00:18.50-00:21.50] CAMERA: Medium shot of the Constable forcefully grappling Alexander by his coat collar, slamming him back against the gate.
[00:19.00-00:21.30] ALEXANDER (Roaring in Torment): "Juliana!"
[00:21.50-00:26.50] CAMERA: Ground-level shot of Juliana frantically digging and scraping at the frozen dirt and dried bramble pods with both bloody hands.
[00:21.70-00:26.50] ACTION: Juliana digs her torn fingers into the frost-hardened earth, turning over rocks and dead vegetation.
[00:26.50-00:29.50] CAMERA: Medium close-up of Alexander struggling against the Constable, his face twisted in grief and rage.
[00:27.30-00:28.90] ALEXANDER (Desperate Shout): "Juliana!"
[00:29.50-00:35.50] CAMERA: Close-up of Juliana lying on her stomach among the thorns, bleeding cuts running down her forehead, cheeks, and bare arms.
[00:30.70-00:35.00] JULIANA (Panting, Praying): "Please, ring... you have to be here."
[00:35.50-00:39.00] ACTION: Her blood-smeared index finger brushes against a solid metallic object half-buried in the frozen dirt beneath a thorny branch.
[00:35.50-00:39.50] CAMERA: Extreme close-up macro shot of an ornate antique gold ring set with a massive, radiant emerald resting in the frosted soil.
[00:39.50-00:41.50] CAMERA: Close-up of Juliana's wide, disbelieving blue eyes as breath catches in her throat.
[00:41.50-00:44.50] ACTION: Juliana reaches out her torn, bloodied hand and wraps her fingers tightly around the emerald ring.
```
</details>

### 42. P042 · 77/100 · 31.5s · Low · review: needs_review

- **Cut:** E27 00:16.80–00:48.30
- **Hook:** The Duchess reveals that Juliana's wedding ring bears her noble family's crest.  
  `DOWAGER DUCHESS: "That is no ordinary band. It bears the Ashbourne crest."`
- **Cliffhanger:** Loud, violent pounding echoes on the door just as the Duchess asks for her lost son's name.  
  `SFX: Loud, violent pounding echoes on the wooden double doors.`
- **Why it works:** Emotional climax interrupted by immediate danger.
- **Rank:** Emotional climax interrupted by danger provides a solid cliffhanger, though it relies on existing character investment.
- Scores: hook 11/25 · clarity 14/20 · cliff 22/25 · emotion 15/15 · coherence 10/10 · duration 5/5
- Critic notes a new viewer may not understand: How Juliana got the ring (if this is the first clip seen).

<details><summary>Clip as the viewer sees it</summary>

```
--- CUT 1: episode 27 (source 00:16.80-00:48.30) ---
[00:00.00-00:04.80] CAMERA: Medium two-shot as the Duchess leans forward slightly, staring at the ring between their joined hands.
[00:00.40-00:04.40] DOWAGER DUCHESS (Trembling, Revelatory): "That is no ordinary band. It bears the Ashbourne crest."
[00:04.80-00:09.30] CAMERA: Close-up on Juliana, shaking her head in disbelief and growing confusion.
[00:05.00-00:09.00] JULIANA (Confused, Gentle): "No. He lives in a barn. He has nothing but his word."
[00:09.30-00:15.00] CAMERA: Low-angle shot on the Duchess, tears welling in her eyes as grief and shock overtake her.
[00:09.80-00:14.60] DOWAGER DUCHESS (Emotionally Strained, Weeping): "My lost son wore that exact ring. He went to war..."
[00:15.00-00:18.10] CAMERA: Close-up of Juliana's eyes widening in stunned revelation.
[00:15.30-00:18.00] JULIANA (Shocked, Breathless): "Your son? He told me he was only a sergeant."
[00:18.10-00:20.60] CAMERA: Side-angle medium shot of the bed, the Duchess holding onto Juliana's forearm with fierce insistence.
[00:18.40-00:20.80] DOWAGER DUCHESS (Desperate, Clinging): "My lost son wore that ring!"
[00:20.60-00:23.60] CAMERA: Close-up of Juliana looking down with compassionate concern.
[00:21.00-00:23.40] DOWAGER DUCHESS (O.S.) (Pleading): "Did your husband serve beside him?"
[00:24.20-00:27.40] JULIANA (Soft, Reverent): "He never spoke of his officers. He only spoke of survival."
[00:27.40-00:29.60] CAMERA: Close-up of the Duchess gazing up at Juliana, her voice barely a whisper.
[00:27.70-00:29.60] DOWAGER DUCHESS (Hushed, Desperate): "What is your husband's name?"
[00:29.60-00:31.50] SFX: Loud, violent pounding echoes on the wooden double doors.
[00:29.70-00:31.50] CAMERA: Juliana gasps, snapping her head toward the entrance in alarm.
```
</details>

### 43. P043 · 76/100 · 21.3s · Low · review: needs_review

- **Cut:** E20 01:06.70–01:28.00
- **Hook:** Juliana fiercely declares that if she stops, the lung fever in the valley wins.  
  `JULIANA: "If I stop, Seamus, the lung fever in the valley wins."`
- **Cliffhanger:** Juliana proudly declares 'They have reduced me to myself. And I am not finished.'  
  `JULIANA: "They have reduced me to myself."`
- **Why it works:** The dialogue is sharp and establishes a very strong, noble protagonist immediately.
- **Rank:** Sharp dialogue and early-story noble character establishment provide a clean break from the darker previous promos.
- Scores: hook 18/25 · clarity 18/20 · cliff 12/25 · emotion 14/15 · coherence 10/10 · duration 4/5
- Critic notes a new viewer may not understand: Why she was 'reduced' to this status specifically (was it a choice or forced?).

<details><summary>Clip as the viewer sees it</summary>

```
--- CUT 1: episode 20 (source 01:06.70-01:28.00) ---
[00:00.00-00:02.40] JULIANA (Fierce, Resolute): "If I stop, Seamus, the lung fever in the valley wins."
[00:00.10-00:03.80] CAMERA: Close-up of Juliana looking up at Seamus, her smudged face fierce with unyielding determination as she holds firmly onto the basket.
[00:02.50-00:03.80] JULIANA (Defiant): "I do not yield to a cold draft."
[00:03.80-00:09.50] CAMERA: Close-up of Seamus, his face agonizingly strained with grief for her lost status.
[00:03.90-00:05.60] SEAMUS (Desperate, Grieving): "You are a viscount's daughter!"
[00:05.70-00:07.50] SEAMUS (Pleading): "Sleeping on straw, sorting weeds!"
[00:07.60-00:09.50] SEAMUS (Frustrated): "Let the village tend to itself for once!"
[00:09.50-00:14.30] CAMERA: Medium close-up of Juliana, her jaw set with unwavering moral strength.
[00:09.60-00:13.10] JULIANA (Passionate, Unflinching): "The chapel is gone, Seamus. I am the only healer these people have left."
[00:13.20-00:14.30] JULIANA (Unyielding): "I keep the basket."
[00:14.30-00:21.30] CAMERA: Medium two-shot of Juliana and Seamus standing facing each other in the barn, the lantern casting a warm amber glow between them.
[00:15.30-00:17.70] SEAMUS (Saddened, Heartbroken): "They have reduced you to a peasant."
[00:18.10-00:19.80] JULIANA (Proud, Indomitable): "They have reduced me to myself."
[00:19.90-00:21.30] JULIANA (Steely): "And I am not finished."
```
</details>

### 44. P044 · 76/100 · 40.6s · Low · review: needs_review

- **Cut:** E14 00:47.00–01:27.63
- **Hook:** Alexander looks at her bandaged hands in horror, stating she could have lost them.  
  `ALEXANDER: "You could have lost your hands."`
- **Cliffhanger:** Alexander's scarred fist tightly clenches beside a blood-soaked washbasin, promising vengeance.  
  `ACTION: Alexander's muscular arm drops into frame beside the bloody bucket; his scarred knuckles slowly and tightly clench into an iron fist of brewing vengeanc`
- **Why it works:** Tender emotional romance paired with brewing violent revenge.
- **Rank:** The romance/revenge duality targets two core audiences simultaneously, outperforming more singular-focus clips.
- Scores: hook 12/25 · clarity 14/20 · cliff 22/25 · emotion 13/15 · coherence 10/10 · duration 5/5
- Critic notes a new viewer may not understand: Who exactly 'they' are.; Why the wife had to 'take his place'.

<details><summary>Clip as the viewer sees it</summary>

```
--- CUT 1: episode 14 (source 00:47.00-01:27.63) ---
[00:00.00-00:03.50] CAMERA: Intimate over-the-shoulder close-up looking up into Juliana's face from Alexander's perspective.
[00:00.20-00:02.80] ALEXANDER (Hoarse, Stricken): "You could have lost your hands."
[00:03.50-00:08.50] CAMERA: Extreme close-up on Juliana's glistening eyes and trembling lips, firelight reflecting softly across her face.
[00:04.80-00:07.00] JULIANA (Whispered, Emotional): "But I didn't lose you."
[00:08.50-00:11.50] CAMERA: Close-up on Alexander's scarred, weathered fingers wrapping the cloth tightly yet gently around her lacerations.
[00:11.50-00:13.50] CAMERA: Close-up on Alexander looking up at her with profound remorse and affection.
[00:11.50-00:13.00] ALEXANDER (Quiet, Tender): "I'm sorry."
[00:13.50-00:16.50] CAMERA: Close-up on Juliana smiling faintly through her tears, shaking her head.
[00:13.50-00:15.50] JULIANA (Gentle, Reassuring): "You didn't hurt me."
[00:16.50-00:19.00] CAMERA: Side profile close-up of Alexander lowering his head solemnly in front of her.
[00:19.00-00:23.50] CAMERA: Medium two-shot as Alexander gently drapes a heavy warm woolen blanket across Juliana's lap and around her shoulders.
[00:19.00-00:20.40] JULIANA (Loving, Earnest): "You have taken my place today."
[00:20.50-00:22.80] JULIANA (Continuing): "And you are doing it better than me."
[00:23.50-00:29.00] CAMERA: Medium shot as Juliana rests her cheek against Alexander's chest; he embraces her tightly against him, cradling her head under his chin.
[00:24.00-00:29.00] ACTION: Juliana closes her eyes in exhausted relief, sinking into Alexander's warmth as his broad arm encloses her safely.
[00:29.00-00:36.50] CAMERA: Tight close-up of Alexander holding Juliana against his bearded cheek, kissing the crown of her head before gently cradling her jaw in his scarred hand.
[00:29.50-00:34.00] ALEXANDER (Dark, Solemn Vow): "No one will ever hurt you for protecting me again."
[00:34.20-00:36.50] ACTION: Alexander strokes her cheek with his thumb, his gaze hardening into deadly, protective conviction.
[00:36.50-00:40.63] CAMERA: Low-angle shot focusing down on two wooden buckets on the stone floor—one filled with dark, blood-soaked wash water reflecting the fireplace.
[00:37.00-00:40.00] ACTION: Alexander's muscular arm drops into frame beside the bloody bucket; his scarred knuckles slowly and tightly clench into an iron fist of brewing vengeance.
[00:37.50-00:40.63] SFX: Ominous, resonating low bass boom swelling into sudden silence as the screen cuts to black.
```
</details>

### 45. P045 · 76/100 · 46.4s · Low · review: needs_review

- **Cut:** E31 01:48.80–02:35.20
- **Hook:** Catherine holds up Juliana's late mother's botanical book.  
  `CAMERA: Tight shot of Catherine's gloved hands holding Juliana's mother's partially burned botanical volume, 'The Virtues of Plants & Herbs'.`
- **Cliffhanger:** Juliana recoils back against the hard dungeon wall, gasping for breath in raw terror as the searing iron stops inches from her eyes.  
  `ACTION: Juliana recoils back against the hard dungeon wall, gasping for breath in raw terror as the searing iron stops inches from her eyes.`
- **Why it works:** The visceral nature of the red-hot poker and the destruction of the sentimental object is high drama.
- **Rank:** Highly visceral imagery ensures it grabs attention even with a lower hook score.
- Scores: hook 10/25 · clarity 15/20 · cliff 21/25 · emotion 15/15 · coherence 10/10 · duration 5/5
- Critic notes a new viewer may not understand: How they got into the dungeon.

<details><summary>Clip as the viewer sees it</summary>

```
--- CUT 1: episode 31 (source 01:48.80-02:35.20) ---
[00:00.00-00:01.70] CAMERA: Tight shot of Catherine's gloved hands holding Juliana's mother's partially burned botanical volume, 'The Virtues of Plants & Herbs'.
[00:01.40-00:02.60] CATHERINE (Sneering, Derisive): "[scoffs] Peasants? People?"
[00:02.70-00:09.40] CAMERA: Medium shot of Catherine casually holding the ancient book while pacing slowly before Juliana.
[00:02.80-00:09.40] CATHERINE (Arrogant, Elitist): "That is why you were born in the wrong world. Women like me are meant to be admired. Women like you are meant to serve."
[00:09.40-00:13.70] CAMERA: Tight close-up of Juliana's face, tilting her head with an insightful, knowing smirk.
[00:09.60-00:13.20] JULIANA (Piercing, Provocative): "Then why are you so desperate to make me kneel?"
[00:13.20-00:15.20] ACTION: Catherine's smug expression freezes, her eyes widening in momentary shock and fury as the blow lands squarely.
[00:15.20-00:22.00] CAMERA: Low-angle medium shot of Juliana, her voice ringing clearly through the subterranean chamber.
[00:15.40-00:21.70] JULIANA (Accusatory, Commanding): "If you were truly powerful, Catherine, you wouldn't need me to bow."
[00:22.00-00:24.20] CAMERA: Close-up of Catherine completely losing control, her aristocratic facade shattering into sheer rage.
[00:22.20-00:24.00] CATHERINE (Enraged Scream): "Enough!"
[00:24.20-00:25.70] CAMERA: Close-up of the red-hot poker pressing directly down into the delicate open pages of the botanical book.
[00:24.40-00:25.70] SFX: Hiss of scorched parchment and curling white smoke rising as paper blackens under extreme heat.
[00:25.70-00:29.20] CAMERA: Medium two-shot. Catherine holds the smoldering book right before Juliana's face.
[00:25.70-00:29.20] CATHERINE (Hateful, Malicious): "This pathetic book is the only thing you still have from your mother."
[00:29.20-00:31.70] CAMERA: Extreme close-up of Juliana, her emotional composure breaking into pure grief and panic.
[00:29.20-00:31.70] ACTION: Tears spill rapidly down Juliana's cheeks as she reaches forward in vain, restrained by her heavy iron chains.
[00:29.60-00:31.60] JULIANA (Desperate, Weeping): "[gasping] Give it back!"
[00:31.70-00:35.00] CAMERA: Low-angle shot of Catherine grinning with sadistic triumph, looking down at Juliana's despair.
[00:31.90-00:35.00] CATHERINE (Gloating, Sadistic): "There. Finally. Something still hurts you."
[00:35.00-00:36.70] CAMERA: Close-up of Juliana screaming out in absolute anguish.
[00:35.20-00:36.70] JULIANA (Screaming, Agonized): "No!"
[00:36.70-00:42.40] CAMERA: Medium close-up of Catherine slowly driving the glowing branding tip into the spine of the open book, watching the embers consume the pages.
[00:36.80-00:42.40] CATHERINE (Vicious, Final): "One flame, and your mother's life's work becomes ash."
[00:42.40-00:46.40] CAMERA: Low-angle medium shot. Catherine lowers the charred book and suddenly swings the glowing orange iron tip straight up toward Juliana's face.
[00:42.70-00:46.40] ACTION: Juliana recoils back against the hard dungeon wall, gasping for breath in raw terror as the searing iron stops inches from her eyes.
```
</details>

### 46. P046 · 75/100 · 24.5s · Low · review: needs_review

- **Cut:** E4 01:50.00–02:14.50
- **Hook:** Priest booms: 'I now pronounce you husband and wife!' as ex-groom lunges forward shouting.  
  `THE PRIEST: "By the authority entrusted to me, I now pronounce you..."`
- **Cliffhanger:** "You are disowned!"  
  `LADY ASHCROFT: "You are disowned!"`
- **Why it works:** Clear conflict, clear hero, and clear villain. Very easy to digest as a standalone moment.
- **Rank:** A low-episode, high-clarity clip that is extremely easy for a scrolling user to digest quickly.
- Scores: hook 17/25 · clarity 17/20 · cliff 13/25 · emotion 14/15 · coherence 10/10 · duration 4/5
- Critic notes a new viewer may not understand: Who the man is that she married (he has no lines and just stands there).

<details><summary>Clip as the viewer sees it</summary>

```
--- CUT 1: episode 4 (source 01:50.00-02:14.50) ---
[00:00.00-00:03.00] THE PRIEST (Ceremonial): "By the authority entrusted to me, I now pronounce you..."
[00:02.80-00:04.80] CAMERA: High wide establishing shot looking down from the ceiling vaults of the cathedral onto the altar.
[00:03.00-00:04.80] THE PRIEST (Off-Screen, Booming): "...husband and wife!"
[00:04.00-00:05.20] SFX: Dramatic musical chord swelling.
[00:04.80-00:06.80] CAMERA: Medium close-up of Gerald lunging forward, pointing an enraged finger.
[00:05.00-00:06.80] GERALD (Furious, Shouting): "You have thrown yourself away!"
[00:06.80-00:09.00] CAMERA: Tight close-up of Gerald, face contorted in rage.
[00:07.00-00:09.00] GERALD (Livid): "For a penniless nobody!"
[00:09.00-00:12.80] CAMERA: Medium two-shot of Juliana standing tall before Gerald in the chapel aisle, her husband standing guard behind her.
[00:10.50-00:12.80] JULIANA (Calm, Cutting): "I would rather choose my own life..."
[00:12.80-00:15.80] CAMERA: Close-up of Juliana, her jaw set with unshakable pride.
[00:13.00-00:15.50] JULIANA (Firm, Final): "...than spend another moment begging for yours."
[00:15.80-00:17.40] CAMERA: Tight close-up of Gerald, eyes wide with speechless shock and wounded pride.
[00:16.00-00:17.40] ACTION: Gerald recoils slightly, mouth agape.
[00:17.40-00:21.50] CAMERA: Wide shot of Lady Ashcroft rising abruptly from the front pew, pointing an accusatory hand toward the doors.
[00:17.50-00:21.50] LADY ASHCROFT (Imperious, Shouting): "Do not bring this man anywhere near Ashcroft Manor!"
[00:21.50-00:24.50] CAMERA: Tight close-up of Lady Ashcroft, eyes blazing with cold malice.
[00:22.00-00:24.50] LADY ASHCROFT (Venomous): "You are disowned!"
```
</details>

### 47. P047 · 75/100 · 54.4s · Low · review: needs_review

- **Cut:** E30 00:33.40–01:27.80
- **Hook:** An elder nobleman pins Rupert against the wall with his cane, demanding he burn the prisoner.  
  `ELDER NOBLEMAN: "Then make certain she isn't! A peasant weed, Rupert! You do not store weeds in your cellar, you burn them!"`
- **Cliffhanger:** The Elder Nobleman chillingly orders them to fabricate a witchcraft charge to execute her.  
  `ELDER NOBLEMAN: "Then call it witchcraft."`
- **Why it works:** Pure villainous plotting that elevates the conspiracy stakes.
- **Rank:** Pure villainous plotting offers high clarity and sets a clear antagonist for the user to hate.
- Scores: hook 16/25 · clarity 20/20 · cliff 13/25 · emotion 12/15 · coherence 10/10 · duration 4/5
- Critic notes a new viewer may not understand: The specific relationship between the three villains.

<details><summary>Clip as the viewer sees it</summary>

```
--- CUT 1: episode 30 (source 00:33.40-01:27.80) ---
[00:00.00-00:06.40] CAMERA: Medium two-shot as the Elder Nobleman lunges forward aggressively, stepping into Rupert's personal space.
[00:00.00-00:01.80] ACTION: The Elder Nobleman thrusts the gold knob of his walking stick directly against Rupert's chest, pinning him against the wall.
[00:00.20-00:06.40] ELDER NOBLEMAN (Fierce, Venomous): "Then make certain she isn't! A peasant weed, Rupert! You do not store weeds in your cellar, you burn them!"
[00:06.40-00:10.40] CAMERA: Low-angle close-up of Rupert gasping softly, intimidated by the cane pressed firmly beneath his cravat.
[00:08.40-00:10.10] RUPERT (Faltering, Submissive): "What are you suggesting?"
[00:10.40-00:14.20] CAMERA: Medium shot as the Elder Nobleman withdraws his cane and turns sharply toward the library doors.
[00:11.40-00:13.90] ELDER NOBLEMAN (Calculated, Ominous): "We stop hiding the prisoner."
[00:14.20-00:17.60] CAMERA: Tracking shot from behind the Elder Nobleman as he pushes open the heavy double doors into the dark wood-paneled library.
[00:14.60-00:17.10] SFX: The heavy creak of massive mahogany doors gliding open on brass hinges.
[00:17.60-00:21.20] CAMERA: Front medium shot of the Elder Nobleman pausing inside the library doorway, Rupert following behind him.
[00:17.80-00:20.60] ELDER NOBLEMAN (Deadpan, Sinister): "We give them a reason to condemn her."
[00:21.20-00:25.40] CAMERA: Wide shot of Catherine standing regally before the roaring stone hearth, dressed in an ornate burgundy and gold brocade gown, slowly unfurling a red lace fan.
[00:23.60-00:25.40] CATHERINE (Inquiring, Sharp): "You have a solution?"
[00:25.40-00:29.40] CAMERA: Side profile close-up of the Elder Nobleman speaking with icy confidence.
[00:26.00-00:29.10] ELDER NOBLEMAN (Ruthless): "We use the law to destroy her."
[00:29.40-00:31.40] CAMERA: Close-up of Rupert looking bewildered.
[00:29.70-00:30.90] RUPERT (Confused): "The law?"
[00:31.40-00:40.10] CAMERA: Tracking medium shot as the Elder Nobleman paces slowly behind the massive mahogany desk lined with books and a glass of whiskey.
[00:31.90-00:39.40] ELDER NOBLEMAN (Pragmatic, Scheming): "A maid with herbs in her possession, a secret medicine, an unauthorized visit to the Duchess's chamber."
[00:37.40-00:39.80] ACTION: The Elder Nobleman leans both hands against the desk, leaning forward intently.
[00:40.10-00:41.40] CAMERA: Medium close-up of Catherine fluttering her fan beneath her chin, smirking approvingly.
[00:41.40-00:49.40] CAMERA: Medium shot framing the Elder Nobleman seated at the desk beside Catherine standing in the firelight.
[00:41.60-00:49.10] ELDER NOBLEMAN (Cold, Calculating): "Give those facts to a magistrate in the right order, and she becomes a poisoner."
[00:49.40-00:52.20] CAMERA: Medium close-up of Catherine gently moving her fan, raising an intrigued brow.
[00:49.80-00:52.00] CATHERINE (Curious, Conniving): "And if she claims she is a healer?"
[00:52.20-00:54.40] CAMERA: Tight close-up of the Elder Nobleman's face illuminated by warm firelight.
[00:52.40-00:54.40] ELDER NOBLEMAN (Sinister): "Then call it witchcraft."
```
</details>

### 48. P048 · 75/100 · 25.9s · Low · review: needs_review

- **Cut:** E3 01:59.80–02:25.75
- **Hook:** Shocking line: 'You came here to become a wife... I am offering it back.'  
  `THE BEARDED STRANGER: "You came here to become a wife."`
- **Cliffhanger:** Stranger proposes on one knee before the stunned cathedral; Juliana looks down tearfully as the cliffhanger score swells.  
  `ACTION: Juliana gazes down at her rugged savior, overcome with emotion as the swelling score holds on the cliffhanger.`
- **Why it works:** The ultimate 'revenge pivot'—marrying someone better (or at least bolder) on the spot.
- **Rank:** An early-story 'revenge pivot' that is highly relatable and serves as a strong bridge to mid-tier content.
- Scores: hook 12/25 · clarity 14/20 · cliff 19/25 · emotion 15/15 · coherence 10/10 · duration 5/5
- Critic notes a new viewer may not understand: Where the man got the silver ring so suddenly.; Why the congregation is just watching silently.

<details><summary>Clip as the viewer sees it</summary>

```
--- CUT 1: episode 3 (source 01:59.80-02:25.75) ---
[00:00.00-00:02.30] THE BEARDED STRANGER (O.S.) (Honorable, Earnest): "You came here to become a wife."
[00:01.20-00:03.40] CAMERA: Medium shot on The Bearded Stranger extending the ring toward Juliana.
[00:02.70-00:04.40] THE BEARDED STRANGER (Quiet, Resolute): "They took that from you."
[00:03.40-00:05.30] CAMERA: Over-the-shoulder medium shot past The Bearded Stranger onto Gerald standing petrified and humiliated in the aisle.
[00:05.30-00:07.60] CAMERA: Medium close-up on The Bearded Stranger presenting the ring directly to Juliana.
[00:05.50-00:07.50] THE BEARDED STRANGER (Earnest, Sincere): "I am offering it back."
[00:07.60-00:10.40] CAMERA: Close-up on Juliana glancing down at the ring, breathless and overwhelmed.
[00:07.90-00:10.10] LADY JULIANA (Soft, Hesitant): "You don't even know me."
[00:10.40-00:12.90] CAMERA: Close-up on The Bearded Stranger's warm, piercing gaze.
[00:10.60-00:12.20] THE BEARDED STRANGER (Quiet, Steady): "I know enough."
[00:12.90-00:15.70] CAMERA: Full wide profile shot as The Bearded Stranger slowly and respectfully drops onto one knee before Lady Juliana.
[00:13.40-00:15.70] ACTION: The Bearded Stranger sinks to one knee on the cathedral aisle, offering the silver ring up to Juliana.
[00:15.00-00:16.40] SFX: A collective, stunned gasp rippling across the entire congregation.
[00:15.70-00:17.50] CAMERA: Medium shot of the Noble Matriarch, Gerald, and the Lady in Gold Gown frozen in sheer, jaw-dropped bewilderment.
[00:17.50-00:20.70] CAMERA: Low-angle medium close-up of The Bearded Stranger on his knee, holding the silver ring high with steady dignity.
[00:17.70-00:20.50] THE BEARDED STRANGER (Solemn, Devoted): "Lady Juliana... accept my hand."
[00:20.70-00:25.95] CAMERA: Close-up on Juliana looking down at him, fresh tears trailing down her flushed cheeks as a soft, trembling smile of hope touches her lips into a slow fade.
[00:20.70-00:25.95] ACTION: Juliana gazes down at her rugged savior, overcome with emotion as the swelling score holds on the cliffhanger.
```
</details>

## Human review queue

Promos the tool is unsure about. Flag kinds: objective = computed from screenplay blocks; approximate = word overlap between a description and the clip (may misfire on paraphrases); subjective = the LLM critic's judgement. Nothing here is auto-rejected.

**#2 P002** (E23 01:28.00–02:11.20) · status `needs_review` · suggested action `inspect`
- hook_visual_only [objective]: hook is a CAMERA shot description; first line/action/SFX starts at 6.5s. Confirm in the rendered video that the opening shot hooks on its own.
    - `0.0-3.0s  E23#46 CAMERA: Medium shot as the Duchess chokes and spasms on the bed; Juliana whips around immediately.`
    - `6.5-9.0s  E23#49 PRUDENCE: "Can you save her?"`

**#3 P003** (E41 00:00.00–00:28.40 + E41 01:20.50–01:33.50) · status `needs_review` · suggested action `inspect`
- hook_description_unsupported [approximate]: only 11% of the hook description's key words appear in the first 3 s (text match, may be a paraphrase): "Catherine halts her wedding to demand everyone watch a chained woman brought in."
    - `0.0-1.8s  E41#0 CAMERA: Wide symmetrical shot looking down the candlelit, flower-strewn aisle toward the altar where Rupert, Catherine`
    - `1.8-4.5s  E41#1 ACTION: Catherine abruptly pulls away from Rupert and raises her white-gloved hand high, commanding silence from the c`
    - `1.8-2.8s  E41#2 CATHERINE: "Wait."`

**#5 P005** (E16 00:14.30–00:54.40) · status `needs_review` · suggested action `inspect`
- ends_mid_sentence [objective]: last line trails off into a sentence continued in the next block (may be deliberate)
    - `38.9-40.1s  E16#45 JULIANA: "Gerald..."`

**#7 P007** (E36 02:40.00–03:20.75) · status `needs_review` · suggested action `inspect`
- opens_mid_sentence [objective]: first line is the second half of a sentence split across blocks; consider starting one block earlier
    - `0.5-3.0s  E36#99 ALEXANDER: "...and killing my wife afterward."`
- missing_context [subjective]: critic flagged missing context but scored standalone_clarity 14/20

**#11 P011** (E11 00:16.80–00:53.60) · status `needs_review` · suggested action `inspect`
- cliffhanger_description_unsupported [approximate]: only 18% of the cliffhanger description's key words appear in the last 6 s (text match, may be a paraphrase): "Alexander coldly permits the search despite Juliana's frantic defense, leaving the outcome unresolved."
    - `29.2-31.0s  E11#40 CAMERA: Medium close-up of Gerald crossing his arms smugly.`
    - `30.0-31.5s  E11#41 GERALD: "If he has nothing to hide..."`
    - `31.0-34.0s  E11#42 CAMERA: Extreme close-up push-in on Alexander's scarred face, his eyes smoldering with lethal restraint.`

**#15 P015** (E43 01:08.80–01:52.50) · status `needs_review` · suggested action `inspect`
- critic_warning [subjective]: critic flagged predictable/resolved ending but scored cliffhanger_strength 15/25

**#20 P020** (E50 00:18.80–01:18.60) · status `needs_review` · suggested action `inspect`
- hook_description_unsupported [approximate]: only 14% of the hook description's key words appear in the first 3 s (text match, may be a paraphrase): "A corrupt priest demands tax collection rights in exchange for his silence in bed."
    - `0.0-7.7s  E50#11 CAMERA: Medium profile close-up on Father Thomas sitting up tall and bare-chested, Catherine resting her hand firmly o`
    - `0.6-6.2s  E50#12 FATHER THOMAS: "The west territory. Tax collection, all of it. Routed through my office."`
- scout_critic_disagreement [subjective]: scout rated 91, blind critic 76 on the same 5 dimensions

**#21 P021** (E25 01:17.40–01:54.40) · status `needs_review` · suggested action `inspect`
- hook_description_unsupported [approximate]: only 14% of the hook description's key words appear in the first 3 s (text match, may be a paraphrase): "Juliana reveals to Alexander that the Dowager Duchess is being poisoned with arsenic."
    - `0.0-1.5s  E25#46 ALEXANDER: "What did you find?"`
    - `2.1-5.1s  E25#47 CAMERA: Tight close-up on Juliana's trembling lips.`
    - `2.8-4.4s  E25#48 JULIANA: "Poison."`
- missing_context [subjective]: critic flagged missing context but scored standalone_clarity 14/20

**#22 P022** (E28 00:37.70–01:10.20) · status `needs_review` · suggested action `inspect`
- missing_context [subjective]: critic flagged missing context but scored standalone_clarity 14/20

**#25 P025** (E42 00:11.20–00:33.80) · status `needs_review` · suggested action `inspect`
- hook_description_unsupported [approximate]: only 0% of the hook description's key words appear in the first 3 s (text match, may be a paraphrase): "A terrified noble screams 'Who are you?' as an imposing figure strides through smoke."
    - `0.0-1.4s  E42#2 BLOND NOBLEMAN: "Who are you?"`
    - `1.6-3.4s  E42#3 ALEXANDER: "You already know."`
- missing_context [subjective]: critic flagged missing context but scored standalone_clarity 13/20

**#27 P027** (E41 00:17.50–01:00.50 + E42 00:00.00–00:14.60) · status `needs_review` · suggested action `inspect`
- cross_episode [objective]: combines episodes [41, 42]; check the cuts read as one story to a new viewer
- scout_critic_disagreement [subjective]: scout rated 91, blind critic 74 on the same 5 dimensions

**#28 P028** (E24 00:04.00–00:42.80) · status `needs_review` · suggested action `inspect`
- scout_critic_disagreement [subjective]: scout rated 89, blind critic 72 on the same 5 dimensions

**#29 P029** (E40 00:23.00–01:17.40) · status `needs_review` · suggested action `inspect`
- scout_critic_disagreement [subjective]: scout rated 88, blind critic 73 on the same 5 dimensions

**#30 P030** (E26 00:55.80–01:55.50) · status `needs_review` · suggested action `inspect`
- scout_critic_disagreement [subjective]: scout rated 89, blind critic 74 on the same 5 dimensions

**#32 P032** (E44 00:24.40–01:03.40) · status `needs_review` · suggested action `inspect`
- hook_description_unsupported [approximate]: only 18% of the hook description's key words appear in the first 3 s (text match, may be a paraphrase): "A bride in full white steps away from her arrested groom to weep before her long-lost love."
    - `0.0-3.4s  E44#16 CAMERA: Wide shot as Catherine gathers her heavy train and steps away from Rupert, walking toward Alexander who stands`
    - `0.8-3.6s  E44#17 CATHERINE: "Alexander... I thought you had died."`
- cliffhanger_description_unsupported [approximate]: only 11% of the cliffhanger description's key words appear in the last 6 s (text match, may be a paraphrase): "Alexander coldly rejects Catherine's romantic claims, leaving her rendered speechless."
    - `31.2-34.6s  E44#41 CAMERA: Close-up on Catherine, gasping in protest.`
    - `31.8-33.8s  E44#42 CATHERINE: "No!"`
    - `34.6-38.0s  E44#43 CAMERA: Medium shot as Catherine clutches her chest, pouring her heart out.`

**#33 P033** (E33 00:59.00–01:51.50) · status `needs_review` · suggested action `inspect`
- scout_critic_disagreement [subjective]: scout rated 88, blind critic 71 on the same 5 dimensions

**#34 P034** (E39 00:32.40–01:06.90) · status `needs_review` · suggested action `inspect`
- missing_context [subjective]: critic flagged missing context but scored standalone_clarity 12/20
- scout_critic_disagreement [subjective]: scout rated 88, blind critic 69 on the same 5 dimensions

**#35 P035** (E1 01:47.50–02:17.50) · status `needs_review` · suggested action `inspect`
- scout_critic_disagreement [subjective]: scout rated 87, blind critic 68 on the same 5 dimensions

**#36 P036** (E35 01:53.50–02:30.00) · status `needs_review` · suggested action `inspect`
- missing_context [subjective]: critic flagged missing context but scored standalone_clarity 13/20
- scout_critic_disagreement [subjective]: scout rated 87, blind critic 68 on the same 5 dimensions

**#37 P037** (E18 00:56.50–01:55.50) · status `needs_review` · suggested action `inspect`
- hook_description_unsupported [approximate]: only 11% of the hook description's key words appear in the first 3 s (text match, may be a paraphrase): "Juliana screams hysterically and breaks away toward a collapsing, burning desk."
    - `0.0-1.3s  E18#31 JULIANA: "The ledger!"`
    - `1.3-3.5s  E18#32 ACTION: Alexander firmly grips her arm, pulling her back toward safety.`
    - `1.5-2.7s  E18#33 ALEXANDER: "Leave it!"`
- critic_warning [subjective]: critic flagged predictable/resolved ending but scored cliffhanger_strength 15/25
- scout_critic_disagreement [subjective]: scout rated 86, blind critic 69 on the same 5 dimensions

**#38 P038** (E1 00:39.10–01:18.50) · status `needs_review` · suggested action `inspect`
- borderline_subjective [subjective]: kept for human review instead of rejected: critic: predictable/resolved ending (otherwise scores well, total 81)
- scout_critic_disagreement [subjective]: scout rated 94, blind critic 76 on the same 5 dimensions

**#39 P039** (E28 01:35.20–02:16.70) · status `needs_review` · suggested action `inspect`
- borderline_subjective [subjective]: kept for human review instead of rejected: critic: weak hook (otherwise scores well, total 81)
- scout_critic_disagreement [subjective]: scout rated 94, blind critic 76 on the same 5 dimensions

**#40 P040** (E21 00:03.50–00:40.40) · status `needs_review` · suggested action `inspect`
- borderline_subjective [subjective]: kept for human review instead of rejected: cliffhanger score 12/25 below 14 (otherwise scores well, total 78)

**#41 P041** (E13 01:07.50–01:52.00) · status `needs_review` · suggested action `inspect`
- borderline_subjective [subjective]: kept for human review instead of rejected: critic: missing context (otherwise scores well, total 77)

**#42 P042** (E27 00:16.80–00:48.30) · status `needs_review` · suggested action `inspect`
- borderline_subjective [subjective]: kept for human review instead of rejected: hook score 11/25 below 14 (otherwise scores well, total 77)

**#43 P043** (E20 01:06.70–01:28.00) · status `needs_review` · suggested action `inspect`
- borderline_subjective [subjective]: kept for human review instead of rejected: critic: predictable/resolved ending (otherwise scores well, total 76)

**#44 P044** (E14 00:47.00–01:27.63) · status `needs_review` · suggested action `inspect`
- borderline_subjective [subjective]: kept for human review instead of rejected: hook score 12/25 below 14 (otherwise scores well, total 76)

**#45 P045** (E31 01:48.80–02:35.20) · status `needs_review` · suggested action `inspect`
- borderline_subjective [subjective]: kept for human review instead of rejected: critic: weak hook (otherwise scores well, total 76)
- scout_critic_disagreement [subjective]: scout rated 90, blind critic 71 on the same 5 dimensions

**#46 P046** (E4 01:50.00–02:14.50) · status `needs_review` · suggested action `inspect`
- borderline_subjective [subjective]: kept for human review instead of rejected: critic: predictable/resolved ending (otherwise scores well, total 75)
- scout_critic_disagreement [subjective]: scout rated 88, blind critic 71 on the same 5 dimensions

**#47 P047** (E30 00:33.40–01:27.80) · status `needs_review` · suggested action `inspect`
- borderline_subjective [subjective]: kept for human review instead of rejected: cliffhanger score 13/25 below 14 (otherwise scores well, total 75)

**#48 P048** (E3 01:59.80–02:25.75) · status `needs_review` · suggested action `inspect`
- borderline_subjective [subjective]: kept for human review instead of rejected: hook score 12/25 below 14 (otherwise scores well, total 75)
- scout_critic_disagreement [subjective]: scout rated 95, blind critic 70 on the same 5 dimensions

## Quality control: where the tool made poor selections

| Failure type | Count | Examples |
|---|---|---|
| weak hook | 22 | R003, R006, R016, R019, R020, R022 |
| hook not in first 3 s (timestamp check) | 17 | R001, R002, R009, R012, R014, R015 |
| predictable ending | 16 | R003, R005, R006, R008, R011, R020 |
| ends after the cliffhanger (timestamp check) | 14 | R001, R004, R007, R010, R013, R021 |
| no curiosity | 9 | R003, R005, R006, R011, R020, R035 |
| weak on 2 dimensions (ending, hook) | 6 | R003, R006, R020, R034, R047, R061 |
| one weak dimension and total 68 below 75 | 3 | R005, R035, R040 |
| very weak cliffhanger_strength 5 | 3 | R011, R047, R061 |
| total 63 below 65 | 3 | R016, R052, R058 |
| one weak dimension and total 66 below 75 | 3 | R024, R039, R045 |
| total 55 below 65 | 3 | R047, R054, R061 |
| incorrect timestamps / block ids | 2 | R001, R033 |
| outside 20-60 s | 2 | R014, R051 |
| one weak dimension and total 74 below 75 | 2 | R019, R056 |
| one weak dimension and total 70 below 75 | 2 | R030, R032 |
| one weak dimension and total 69 below 75 | 2 | R036, R055 |
| one weak dimension and total 73 below 75 | 2 | R059, R060 |
| total 60 below 65 | 1 | R003 |
| one weak dimension and total 71 below 75 | 1 | R008 |
| total 51 below 65 | 1 | R020 |
| very weak cliffhanger_strength 6 | 1 | R020 |
| one weak dimension and total 72 below 75 | 1 | R029 |
| total 64 below 65 | 1 | R034 |
| one weak dimension and total 67 below 75 | 1 | R043 |
| missing context | 1 | R052 |
| weak on 2 dimensions (context, hook) | 1 | R052 |
| near-duplicate of a better promo | 1 | R053 |
| one weak dimension and total 65 below 75 | 1 | R057 |

**Scout over-confidence** (scout rated itself ≥15 points higher than the blind critic):

- R054: self 90 vs critic 51  (ep009)
- R052: self 92 vs critic 58  (arc03)
- R061: self 84 vs critic 50  (ep049)
- R047: self 81 vs critic 50  (ep046)
- R003: self 84 vs critic 55  (ep002)
- R016: self 87 vs critic 58  (ep019)
- R020: self 74 vs critic 46  (ep022)
- R045: self 89 vs critic 62  (ep044)
- R039: self 89 vs critic 63  (ep037)
- P048: self 95 vs critic 70  (ep003)
- R006: self 87 vs critic 62  (ep007)
- R024: self 85 vs critic 61  (ep025)

### Critic calibration probes

Known-good and known-bad clips sent to the same critic to check it catches each failure type.

| Probe | Expected | Critic flags | Score | Correct verdict? | Right reason? |
|---|---|---|---|---|---|
| PROBE-good-rescue | pass | predictable_ending, misleading_edit | 80 | yes | yes |
| PROBE-good-ring | pass | missing_context | 78 | yes | yes |
| PROBE-weak-hook | weak_hook | weak_hook, predictable_ending, low_curiosity | 45 | yes | yes |
| PROBE-resolved-ending | predictable_ending | predictable_ending, low_curiosity | 65 | yes | yes |
| PROBE-missing-context | missing_context | missing_context | 58 | yes | yes |
| PROBE-misleading-edit | misleading_edit | misleading_edit | 82 | yes | yes |

6/6 verdicts correct; 6/6 for the expected reason.


### Agreement with reference picks

13/17 reference promos are covered (≥50% time overlap) by a passing promo. Recall 76%.

- R01 (Stranger fights off guards, then kneels and proposes): matched by P009
- R02 (Duchess recognises the ring of her lost son; doors burst open): matched by P030
- R03 (Arrest, then Clarissa's thorn-briar ultimatum): matched by P018
- R04 (Wedding interrupted by an explosion): matched by P003
- R05 (Hot iron in the dungeon: 'Burn it.'): not found
- R06 ('You're the Duke?' then the marriage is declared invalid): matched by P006
- R07 (Jilted at the altar for her sister): matched by P038
- R08 ('Beggar's wife' insult, then a spy bows: 'Your Grace'): not found
- R09 (Wife condemned to die after the usurpers' wedding): not found
- R10 (Framed with a planted pocket watch): matched by P011
- R11 (Thugs wreck her garden; husband arrives): matched by P031
- R12 (Crawling bare-handed through thorns): matched by P001
- R13 (Priest's affair witnessed by a maid): matched by P020
- R14 (Catherine pleads with Alexander: 'Her?!'): matched by P032
- R15 (Arsenic discovered; someone at the door): matched by P002
- R16 (Runs back into the fire for her mother's ledger): matched by P037
- R17 (Maid coerced into false witchcraft testimony): not found

## Limitations

- Works from screenplay text only: performance, framing, music and pacing of the final video are not seen. Timestamps are the screenplay's; verify against the rendered episode before cutting.
- Segments start/end on screenplay block boundaries; CAMERA shots that overlap a cut are trimmed, dialogue/ACTION/SFX never are.
- Scores are model judgements (a blind 'first-time viewer' critic), not measured CTR/retention. Use publish results to recalibrate thresholds.
- Cross-episode promos are proposed from loglines/continuity notes, so long-range links the notes do not mention can be missed.
- Spoilers are not penalised by the score; the publishing plan weighs spoiler risk qualitatively.

## Run stats

```json
{
 "run_id": "gemini-batch-v3",
 "show_label": "data",
 "started_utc": "2026-11-07T21:07:21.208299Z",
 "seconds": 638.1,
 "model": "gemini:gemini-3.5-flash (effort=low)",
 "critic_model": "gemini:gemini-3-flash-preview (effort=low)",
 "batching": {
  "episodes_per_call": 10,
  "clips_per_critic_call": 15
 },
 "prompt_version": "2026-11-08.3",
 "episodes": 50,
 "candidates_scouted": 82,
 "failed_validation": 30,
 "repaired": 27,
 "auto_repaired_no_model": 27,
 "llm_repaired": 0,
 "critiques_reused_per_clip": 47,
 "critic_policy": "borderline",
 "borderline_kept_for_review": 11,
 "gap_pass": null,
 "sent_to_critic": 79,
 "passed_critic": 49,
 "final_promos": 48,
 "arc_ideas": 5,
 "live_model_calls": 3,
 "cache_hits": 7,
 "recorded_responses": 11,
 "counts_note": "live_model_calls + cache_hits are for THIS invocation only; seconds is its wall time. recorded_responses (files in raw/) is what a run with an empty cache would request.",
 "review_status_counts": {
  "recommended": 17,
  "needs_review": 31
 },
 "input_tokens": 31317,
 "output_tokens": 8741,
 "task_failures": [
  {
   "task": "repair_batch",
   "error": "timeout: The read operation timed out",
   "trace": "Traceback (most recent call last):\n  File \"/Users/apple/Projects/promo-finder/promo_finder/pipeline.py\", line 103, in _parallel\n    results[name] = fut.result()\n  File \"/Library/Developer/CommandLineTools/Library/Frameworks/Python3.framework/Versions/3.9/lib/python3.9/concurrent/futures/_base.py\", line 438, in result\n    return self.__get_result()\n  File \"/Library/Developer/CommandLineTools/Library/Frameworks/Python3.framework/Versions/3.9/lib/python3.9/concurrent/futures/_base.py\", line 390, in __get_result\n    raise self._exception\nsocket.timeout: The read operation timed out\n"
  }
 ],
 "scout_notes": [
  "episode 6: no candidate",
  "episode 8: no candidate",
  "arc idea 1 (Lady Juliana is recognized by the Dowager Duchess by her sig): not built",
  "arc idea 5 (Juliana learns the Dowager Duchess is dying, infiltrates Ash): not built"
 ],
 "parse_warnings": {}
}
```
