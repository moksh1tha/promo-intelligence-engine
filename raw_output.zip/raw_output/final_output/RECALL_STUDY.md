# Recall study: why reference promos were missed, and what v0.3 changed

Original run: `runs/gemini-batch` (unchanged; statuses from `runs/gemini-batch-audited`).
Improved run: `runs/gemini-batch-v3` (same scout replies and same models; see `comparison.md`).
Judgements below are by Claude Code (an AI assistant) reading the screenplay blocks. They are
**not editor judgements**, and the 17 reference picks are themselves subjective.

## 1. Where the 9 missed references were lost (original run)

Every one of the 9 was **proposed** by the scout; none was lost at generation.

| Ref | Moment | Lost at | Cause | Genuinely strong? |
|---|---|---|---|---|
| R02 | Ring recognition (eps 26–27) | validation | ran 5.4 s past its own cliffhanger; LLM repair returned the same range. The ep 27 continuation (doors burst) was never paired with it. | Yes |
| R07 | Altar betrayal (ep 1) | critic | one flag (predictable ending) on an 81/100 clip. The cut ends on *"never going to marry you"*, ~12 s before the father turns away. | Yes; the cut's ending could be stronger |
| R05 | Hot iron (ep 31) | critic | hook 12/25 on an 82/100 clip | Yes; overlaps P003 (same arc) |
| R13 | Priest's affair (ep 50) | validation | 61.8 s; LLM repair returned the same range | Yes |
| R16 | Fire, ledger (ep 18) | critic | after repair the clip ran on past the escape: resolved | Yes; overlaps P010 |
| R14 | "Her?!" (ep 44) | critic | cut ended on *"Did you?"*, 7 s before *"Her?!"*; two weak scores | Medium |
| R17 | Coerced testimony (ep 33) | critic | weak hook and cliffhanger (talky interrogation) | Debatable |
| R08 | Insult, then "Your Grace" (eps 5→19) | critic + arcs | ep 19 alone has a weak hook (8/25); the setup was never proposed | Debatable (my construction) |
| R09 | Condemned wife (ep 36) | evaluation | content split across P008 and P009 | Already covered |

**Systemic causes:** (1) LLM repair is unreliable for mechanical edge problems; (2) one weak
subjective score rejected otherwise strong clips; (3) cross-episode setup/payoff was planned from
loglines alone. Isolated causes: weak boundary choices by the scout (R07, R14).

## 2. What changed in the improved run (no new prompts for the scout)
- **Deterministic edge repair:** fixed 27 of 30 invalid candidates with **no model call**, keeping
  the model's hook and cliffhanger. The LLM repair of the last 3 timed out; they are lost.
- **Borderline policy:** one weak subjective score on a clip totalling ≥ 75 → kept with a
  human-review flag instead of rejected; 2+ weak dimensions, a very weak hook/ending, or a total
  under 75 still reject. 11 promos were kept this way.
- **Per-clip reuse of critic reviews:** 47 of 79 clips reused an earlier review of exactly the same
  blocks, so only 32 clips needed new reviews (3 critic requests). Total live requests: 3.

## 3. Results (same reference set, same ≥ 50 % overlap rule)

See `comparison.md`. Promos 31 → 48; recommended (no flag) 14 → 17; needs review 17 → 31.
Reference recall over all promos **8/17 (47 %) → 13/17 (76 %)**. Over *recommended only* it is
unchanged at **5/17**: every newly found reference arrives as "needs review".

## 4. Quality of the 19 promos new in v3 (AI read of the scripts)

| Verdict | Promos |
|---|---|
| **Good (9)** | P030 ep 26 ring recognition, *"Where did you get this ring?"* · P038 ep 1 altar betrayal · P042 ep 27 ring crest, then pounding on the doors · P020 ep 50 priest's bargain, the maid gasps · P014 ep 42 *"we settle what you stole"* · P019 ep 46 *"Ten days is plenty of time"* · P046 ep 4 vows, then *"You are disowned!"* · P047 ep 30 *"Then call it witchcraft"* · P048 ep 3 the proposal |
| Borderline (5) | P021 ep 25 (context thin) · P028 ep 24 · P036 ep 35 (expository) · P044 ep 14 · P045 ep 31 hot iron (weak opening; overlaps P003) |
| **Poor (5)** | P032 ep 44 (ends on *"Did you?"*, misses *"Her?!"*) · P037 ep 18 (ends on the escape, resolved) · P041 ep 13 (ends when the ring is found, resolved) · P040 ep 21 (decision made, resolved) · P043 ep 20 (talky, 21 s) |

So of the 5 newly matched references, **3 are good promos (R02, R07, R13)**. The R14 and R16
matches are overlap matches with poor endings. The quality-adjusted gain is about +3, not +5.
All 5 poor promos are in the review queue, not the recommended list.

## 5. Recommendation
Use the improved configuration. The recommended list did not get worse (14 → 17 clean promos),
and every added borderline or weak promo is labelled for an editor instead of hidden or auto-published.
Next step, after the free quota resets: arc planner v2 + `--gap-pass` (about 10 more requests;
dry-run counted). It targets the remaining causes: cross-episode setups (R08) and weak scout
endings.
