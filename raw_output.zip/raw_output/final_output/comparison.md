| Metric | gemini-batch-audited | gemini-batch-v3 |
|---|---|---|
| Promos | 31 | 48 |
| … recommended (no review flag) | 14 | 17 |
| … needs human review | 17 | 31 |
| … kept by the borderline policy | 0 | 11 |
| Episodes represented | 25 | 35 |
| Reference recall, all promos (of 17) | 8 (47%) | 13 (76%) |
| Reference recall, recommended only (of 17) | 5 (29%) | 5 (29%) |
| Covered only by several promos (not counted) | 1 | 2 |
| Critic probes correct | – | 6/6 |

| Reference | gemini-batch-audited | gemini-batch-v3 |
|---|---|---|
| R01 Stranger fights off guards, then kneels and p | P013 | P009 |
| R02 Duchess recognises the ring of her lost son;  | – | P030 (review) |
| R03 Arrest, then Clarissa's thorn-briar ultimatum | P020 | P018 |
| R04 Wedding interrupted by an explosion | P015 (review) | P003 (review) |
| R05 Hot iron in the dungeon: 'Burn it.' | – | split |
| R06 'You're the Duke?' then the marriage is decla | P005 | P006 |
| R07 Jilted at the altar for her sister | – | P038 (review) |
| R08 'Beggar's wife' insult, then a spy bows: 'You | – | – |
| R09 Wife condemned to die after the usurpers' wed | split | split |
| R10 Framed with a planted pocket watch | P016 (review) | P011 (review) |
| R11 Thugs wreck her garden; husband arrives | P019 | P031 |
| R12 Crawling bare-handed through thorns | P001 | P001 |
| R13 Priest's affair witnessed by a maid | – | P020 (review) |
| R14 Catherine pleads with Alexander: 'Her?!' | – | P032 (review) |
| R15 Arsenic discovered; someone at the door | P002 (review) | P002 (review) |
| R16 Runs back into the fire for her mother's ledg | – | P037 (review) |
| R17 Maid coerced into false witchcraft testimony | – | – |
